-- MySQL dump 10.13  Distrib 9.3.0, for macos15.2 (arm64)
--
-- Host: localhost    Database: sertifikatet
-- ------------------------------------------------------
-- Server version	9.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `achievements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `icon_filename` varchar(255) DEFAULT NULL,
  `points` int DEFAULT '10',
  `category` varchar(50) DEFAULT NULL,
  `requirement_type` varchar(50) DEFAULT NULL,
  `requirement_value` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `achievements`
--

LOCK TABLES `achievements` WRITE;
/*!40000 ALTER TABLE `achievements` DISABLE KEYS */;
INSERT INTO `achievements` VALUES (1,'Første Quiz','Fullført din første quiz','first_quiz.png',10,'quiz','quiz_count',1),(2,'Quiz Mester','Fullført 10 quiz','quiz_master.png',50,'quiz','quiz_count',10),(3,'Perfekt Score','Oppnådde 100% på en quiz','perfect_score.png',25,'quiz','perfect_score',1),(4,'Uke Streak','Tok quiz 7 dager på rad','week_streak.png',30,'streak','streak_days',7),(5,'Måned Streak','Tok quiz 30 dager på rad','month_streak.png',100,'streak','streak_days',30),(6,'Video Lærer','Så 5 instruksjonsvideoer','video_learner.png',20,'video','videos_watched',5),(7,'Spill Entusiast','Spilte 10 spill','game_enthusiast.png',40,'game','games_played',10),(8,'Kunnskapssøker','Besvarte 100 spørsmål','knowledge_seeker.png',60,'quiz','questions_answered',100),(9,'Ekspert','Besvarte 500 spørsmål','expert.png',200,'quiz','questions_answered',500),(10,'Trafikkskilt Mester','Fullført alle trafikkskilt kategorier','signs_master.png',75,'category','category_complete',1);
/*!40000 ALTER TABLE `achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adaptive_quiz_sessions`
--

DROP TABLE IF EXISTS `adaptive_quiz_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adaptive_quiz_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `quiz_session_id` int NOT NULL,
  `algorithm_version` varchar(50) DEFAULT NULL,
  `target_difficulty` float DEFAULT NULL,
  `adaptation_strength` float DEFAULT NULL,
  `initial_skill_estimate` float DEFAULT NULL,
  `final_skill_estimate` float DEFAULT NULL,
  `skill_improvement` float DEFAULT NULL,
  `questions_above_skill` int DEFAULT NULL,
  `questions_below_skill` int DEFAULT NULL,
  `questions_optimal` int DEFAULT NULL,
  `average_engagement_score` float DEFAULT NULL,
  `frustration_indicators` int DEFAULT NULL,
  `confidence_trend` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `quiz_session_id` (`quiz_session_id`),
  CONSTRAINT `adaptive_quiz_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `adaptive_quiz_sessions_ibfk_2` FOREIGN KEY (`quiz_session_id`) REFERENCES `quiz_sessions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adaptive_quiz_sessions`
--

LOCK TABLES `adaptive_quiz_sessions` WRITE;
/*!40000 ALTER TABLE `adaptive_quiz_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `adaptive_quiz_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_audit_log`
--

DROP TABLE IF EXISTS `admin_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_user_id` int NOT NULL,
  `admin_user_id` int DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `additional_info` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `target_user_id` (`target_user_id`),
  KEY `admin_user_id` (`admin_user_id`),
  CONSTRAINT `admin_audit_log_ibfk_1` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `admin_audit_log_ibfk_2` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_audit_log`
--

LOCK TABLES `admin_audit_log` WRITE;
/*!40000 ALTER TABLE `admin_audit_log` DISABLE KEYS */;
INSERT INTO `admin_audit_log` VALUES (1,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:43:28'),(2,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:45:36'),(3,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:33'),(4,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:36'),(5,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:41'),(6,1,1,'ml_system_activate','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','\"{\\\"success\\\": true}\"','2025-06-20 21:46:41'),(7,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:41'),(8,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:50'),(9,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:52'),(10,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:47:22'),(11,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:54:31'),(12,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:54:34'),(13,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 18:19:41'),(14,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 18:19:58'),(15,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 18:20:09'),(16,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 18:20:12'),(17,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 18:20:17'),(18,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 18:20:22'),(19,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 18:20:29'),(20,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 19:23:13'),(21,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 19:48:16'),(22,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 19:51:18'),(23,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 19:51:32'),(24,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 19:51:32'),(25,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:08:13'),(26,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:14:09'),(27,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:14:09'),(28,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:20:23'),(29,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:20:45'),(30,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:20:45'),(31,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:27:03'),(32,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:27:03'),(33,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:35:08'),(34,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 20:35:08'),(35,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 21:01:44'),(36,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 21:01:53'),(37,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 21:01:53'),(38,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 21:09:24'),(39,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 21:09:34'),(40,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 21:09:34'),(41,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 21:54:17'),(42,1,1,'questions_export','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','\"{\\\"question_count\\\": 9}\"','2025-06-22 21:54:17'),(43,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:04:23'),(44,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:04:23'),(45,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:04:41'),(46,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:10:42'),(47,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:10:49'),(48,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:10:53'),(49,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:11:14'),(50,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:11:14'),(51,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:11:46'),(52,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:16:52'),(53,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:18:15'),(54,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:18:15'),(55,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:20:38'),(56,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:20:38'),(57,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:21:54'),(58,1,1,'questions_import','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','\"{\\\"filename\\\": \\\"trafikkskilt_questions_omformulert.csv\\\", \\\"imported\\\": 315, \\\"updated\\\": 0, \\\"errors\\\": 0, \\\"overwrite_mode\\\": false, \\\"csv_delimiter\\\": \\\";\\\"}\"','2025-06-22 22:21:55'),(59,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:21:55'),(60,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:27:14'),(61,1,1,'questions_export','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','\"{\\\"question_count\\\": 324}\"','2025-06-22 22:27:14'),(62,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:36:57'),(63,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:39:37'),(64,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:39:50'),(65,1,1,'questions_export','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','\"{\\\"question_count\\\": 324}\"','2025-06-22 22:39:50'),(66,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:55:45'),(67,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 22:55:45'),(68,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:00:04'),(69,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:00:04'),(70,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:01:10'),(71,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:01:10'),(72,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:01:54'),(73,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:01:54'),(74,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:02:33'),(75,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:02:33'),(76,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:06:59'),(77,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:07:29'),(78,1,1,'questions_export','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','\"{\\\"question_count\\\": 324}\"','2025-06-22 23:07:30'),(79,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:13:05'),(80,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:16:30'),(81,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:19:10'),(82,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:19:10'),(83,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:19:53'),(84,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:19:53'),(85,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:20:52'),(86,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:20:52'),(87,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:21:51'),(88,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:21:51'),(89,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:22:13'),(90,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:22:13'),(91,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:23:38'),(92,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:23:38'),(93,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:24:12'),(94,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:24:12'),(95,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:24:38'),(96,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-22 23:24:38'),(97,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:21:44'),(98,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:24:47'),(99,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:24:50'),(100,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:39:22'),(101,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:43:59'),(102,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:44:32'),(103,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:44:33'),(104,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:46:33'),(105,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:48:11'),(106,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:48:58'),(107,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 12:52:01'),(108,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 13:10:16'),(109,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 13:28:20'),(110,1,1,'questions_export','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','\"{\\\"question_count\\\": 324}\"','2025-06-23 13:28:20'),(111,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 14:14:46'),(112,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 14:14:46'),(113,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 14:19:11'),(114,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 14:19:11'),(115,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 14:24:14'),(116,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 14:24:14'),(117,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 14:24:31'),(118,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 14:24:31'),(119,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 16:00:28'),(120,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-23 16:07:59');
/*!40000 ALTER TABLE `admin_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_reports`
--

DROP TABLE IF EXISTS `admin_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `report_type` varchar(50) NOT NULL,
  `priority` varchar(20) DEFAULT 'medium',
  `status` varchar(20) DEFAULT 'new',
  `title` varchar(255) NOT NULL,
  `description` text,
  `reported_by_user_id` int DEFAULT NULL,
  `affected_user_id` int DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `url` text,
  `error_message` text,
  `stack_trace` text,
  `metadata_json` text,
  `screenshot_filename` varchar(255) DEFAULT NULL,
  `assigned_to_user_id` int DEFAULT NULL,
  `resolved_by_user_id` int DEFAULT NULL,
  `resolution_notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `resolved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reported_by_user_id` (`reported_by_user_id`),
  KEY `affected_user_id` (`affected_user_id`),
  KEY `assigned_to_user_id` (`assigned_to_user_id`),
  KEY `resolved_by_user_id` (`resolved_by_user_id`),
  CONSTRAINT `admin_reports_ibfk_1` FOREIGN KEY (`reported_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `admin_reports_ibfk_2` FOREIGN KEY (`affected_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `admin_reports_ibfk_3` FOREIGN KEY (`assigned_to_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `admin_reports_ibfk_4` FOREIGN KEY (`resolved_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_reports`
--

LOCK TABLES `admin_reports` WRITE;
/*!40000 ALTER TABLE `admin_reports` DISABLE KEYS */;
INSERT INTO `admin_reports` VALUES (1,'unexpected_error','medium','new','Application Error: OperationalError','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','http://127.0.0.1:8000/api/leaderboard?type=weekly&category=overall&limit=20','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\npymysql.err.OperationalError: (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/api/routes.py\", line 212, in get_leaderboard\n    leaderboard = leaderboard_service.get_leaderboard(\n                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/services/leaderboard_service.py\", line 170, in get_leaderboard\n    ).limit(limit).all()\n                   ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2688, in all\n    return self._iter().all()  # type: ignore\n           ^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2842, in _iter\n    result: Union[ScalarResult[_T], Result[_T]] = self.session.execute(\n                                                  ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2262, in execute\n    return self._execute_internal(\n           ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2144, in _execute_internal\n    result: Result[Any] = compile_state_cls.orm_execute_statement(\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/context.py\", line 293, in orm_execute_statement\n    result = conn.execute(\n             ^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1412, in execute\n    return meth(\n           ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/sql/elements.py\", line 515, in _execute_on_connection\n    return connection._execute_clauseelement(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1635, in _execute_clauseelement\n    ret = self._execute_context(\n          ^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1844, in _execute_context\n    return self._exec_single_context(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1984, in _exec_single_context\n    self._handle_dbapi_exception(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 2339, in _handle_dbapi_exception\n    raise sqlalchemy_exception.with_traceback(exc_info[2]) from e\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\nsqlalchemy.exc.OperationalError: (pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 21:40:51','2025-06-20 21:40:51',NULL),(2,'unexpected_error','medium','new','Application Error: OperationalError','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at \nFROM leaderboard_entries \nWHERE leaderboard_entries.user_id = %(user_id_1)s AND leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s \n LIMIT %(param_1)s]\n[parameters: {\'user_id_1\': 1, \'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 1}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','http://127.0.0.1:8000/api/leaderboard/user-rank?type=weekly&category=overall','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at \nFROM leaderboard_entries \nWHERE leaderboard_entries.user_id = %(user_id_1)s AND leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s \n LIMIT %(param_1)s]\n[parameters: {\'user_id_1\': 1, \'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 1}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\npymysql.err.OperationalError: (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/api/routes.py\", line 245, in get_user_rank\n    user_rank = leaderboard_service.get_user_rank(\n                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/services/leaderboard_service.py\", line 196, in get_user_rank\n    ).first()\n      ^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2743, in first\n    return self.limit(1)._iter().first()  # type: ignore\n           ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2842, in _iter\n    result: Union[ScalarResult[_T], Result[_T]] = self.session.execute(\n                                                  ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2262, in execute\n    return self._execute_internal(\n           ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2144, in _execute_internal\n    result: Result[Any] = compile_state_cls.orm_execute_statement(\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/context.py\", line 293, in orm_execute_statement\n    result = conn.execute(\n             ^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1412, in execute\n    return meth(\n           ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/sql/elements.py\", line 515, in _execute_on_connection\n    return connection._execute_clauseelement(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1635, in _execute_clauseelement\n    ret = self._execute_context(\n          ^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1844, in _execute_context\n    return self._exec_single_context(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1984, in _exec_single_context\n    self._handle_dbapi_exception(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 2339, in _handle_dbapi_exception\n    raise sqlalchemy_exception.with_traceback(exc_info[2]) from e\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\nsqlalchemy.exc.OperationalError: (pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at \nFROM leaderboard_entries \nWHERE leaderboard_entries.user_id = %(user_id_1)s AND leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s \n LIMIT %(param_1)s]\n[parameters: {\'user_id_1\': 1, \'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 1}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 21:40:51','2025-06-20 21:40:51',NULL),(3,'unexpected_error','medium','new','Application Error: ImportError','cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/auth/register','cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/auth/routes.py\", line 76, in register\n    from app.models import Plan\nImportError: cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 22:56:23','2025-06-20 22:56:23',NULL),(4,'unexpected_error','medium','new','Application Error: ImportError','cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/auth/register','cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/auth/routes.py\", line 76, in register\n    from app.models import Plan\nImportError: cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 22:57:12','2025-06-20 22:57:12',NULL),(5,'unexpected_error','medium','new','Application Error: ImportError','cannot import name \'SubscriptionPlan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/auth/register','cannot import name \'SubscriptionPlan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/auth/routes.py\", line 76, in register\n    from ..models import SubscriptionPlan\nImportError: cannot import name \'SubscriptionPlan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 22:58:07','2025-06-20 22:58:07',NULL),(6,'unexpected_error','medium','new','Application Error: ImportError','cannot import name \'subscription_tier\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/auth/register','cannot import name \'subscription_tier\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/auth/routes.py\", line 76, in register\n    from ..models import subscription_tier\nImportError: cannot import name \'subscription_tier\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 23:01:36','2025-06-20 23:01:36',NULL),(7,'unexpected_error','medium','new','Application Error: OperationalError','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/api/leaderboard?type=weekly&category=overall&limit=20','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\npymysql.err.OperationalError: (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/api/routes.py\", line 212, in get_leaderboard\n    leaderboard = leaderboard_service.get_leaderboard(\n                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/services/leaderboard_service.py\", line 170, in get_leaderboard\n    ).limit(limit).all()\n                   ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2688, in all\n    return self._iter().all()  # type: ignore\n           ^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2842, in _iter\n    result: Union[ScalarResult[_T], Result[_T]] = self.session.execute(\n                                                  ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2262, in execute\n    return self._execute_internal(\n           ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2144, in _execute_internal\n    result: Result[Any] = compile_state_cls.orm_execute_statement(\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/context.py\", line 293, in orm_execute_statement\n    result = conn.execute(\n             ^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1412, in execute\n    return meth(\n           ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/sql/elements.py\", line 515, in _execute_on_connection\n    return connection._execute_clauseelement(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1635, in _execute_clauseelement\n    ret = self._execute_context(\n          ^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1844, in _execute_context\n    return self._exec_single_context(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1984, in _exec_single_context\n    self._handle_dbapi_exception(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 2339, in _handle_dbapi_exception\n    raise sqlalchemy_exception.with_traceback(exc_info[2]) from e\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\nsqlalchemy.exc.OperationalError: (pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 23:15:43','2025-06-20 23:15:43',NULL),(8,'unexpected_error','medium','new','Application Error: OperationalError','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','http://localhost:8000/api/leaderboard?type=weekly&category=overall&limit=20','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\npymysql.err.OperationalError: (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/api/routes.py\", line 212, in get_leaderboard\n    leaderboard = leaderboard_service.get_leaderboard(\n                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/services/leaderboard_service.py\", line 170, in get_leaderboard\n    ).limit(limit).all()\n                   ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2688, in all\n    return self._iter().all()  # type: ignore\n           ^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2842, in _iter\n    result: Union[ScalarResult[_T], Result[_T]] = self.session.execute(\n                                                  ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2262, in execute\n    return self._execute_internal(\n           ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2144, in _execute_internal\n    result: Result[Any] = compile_state_cls.orm_execute_statement(\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/context.py\", line 293, in orm_execute_statement\n    result = conn.execute(\n             ^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1412, in execute\n    return meth(\n           ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/sql/elements.py\", line 515, in _execute_on_connection\n    return connection._execute_clauseelement(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1635, in _execute_clauseelement\n    ret = self._execute_context(\n          ^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1844, in _execute_context\n    return self._exec_single_context(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1984, in _exec_single_context\n    self._handle_dbapi_exception(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 2339, in _handle_dbapi_exception\n    raise sqlalchemy_exception.with_traceback(exc_info[2]) from e\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\nsqlalchemy.exc.OperationalError: (pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-22 18:07:56','2025-06-22 18:07:56',NULL),(9,'unexpected_error','medium','new','Application Error: OperationalError','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','http://localhost:8000/api/leaderboard?type=weekly&category=overall&limit=20','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\npymysql.err.OperationalError: (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/api/routes.py\", line 212, in get_leaderboard\n    leaderboard = leaderboard_service.get_leaderboard(\n                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/services/leaderboard_service.py\", line 170, in get_leaderboard\n    ).limit(limit).all()\n                   ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2688, in all\n    return self._iter().all()  # type: ignore\n           ^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2842, in _iter\n    result: Union[ScalarResult[_T], Result[_T]] = self.session.execute(\n                                                  ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2262, in execute\n    return self._execute_internal(\n           ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2144, in _execute_internal\n    result: Result[Any] = compile_state_cls.orm_execute_statement(\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/context.py\", line 293, in orm_execute_statement\n    result = conn.execute(\n             ^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1412, in execute\n    return meth(\n           ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/sql/elements.py\", line 515, in _execute_on_connection\n    return connection._execute_clauseelement(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1635, in _execute_clauseelement\n    ret = self._execute_context(\n          ^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1844, in _execute_context\n    return self._exec_single_context(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1984, in _exec_single_context\n    self._handle_dbapi_exception(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 2339, in _handle_dbapi_exception\n    raise sqlalchemy_exception.with_traceback(exc_info[2]) from e\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\nsqlalchemy.exc.OperationalError: (pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-22 18:08:01','2025-06-22 18:08:01',NULL),(10,'unexpected_error','medium','new','Application Error: AttributeError','\'NoneType\' object has no attribute \'strip\'',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','http://localhost:8000/admin/dashboard','\'NoneType\' object has no attribute \'strip\'','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask_login/utils.py\", line 290, in decorated_view\n    return current_app.ensure_sync(func)(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/admin/routes.py\", line 35, in decorated_function\n    return f(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/admin/routes.py\", line 121, in admin_dashboard\n    validation_errors = validate_question(question_data, question_id)\n                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/admin/utils/validation.py\", line 18, in validate_question\n    if not data.get(field, \'\').strip():\n           ^^^^^^^^^^^^^^^^^^^^^^^^^\nAttributeError: \'NoneType\' object has no attribute \'strip\'\n',NULL,NULL,NULL,NULL,NULL,'2025-06-22 19:48:16','2025-06-22 19:48:16',NULL);
/*!40000 ALTER TABLE `admin_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badge_categories`
--

DROP TABLE IF EXISTS `badge_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `badge_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `icon` varchar(100) DEFAULT NULL,
  `order_index` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badge_categories`
--

LOCK TABLES `badge_categories` WRITE;
/*!40000 ALTER TABLE `badge_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `badge_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_addresses`
--

DROP TABLE IF EXISTS `billing_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_addresses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) DEFAULT NULL,
  `city` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `country` varchar(2) DEFAULT NULL,
  `organization_number` varchar(20) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_billing_user` (`user_id`),
  CONSTRAINT `billing_addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_addresses`
--

LOCK TABLES `billing_addresses` WRITE;
/*!40000 ALTER TABLE `billing_addresses` DISABLE KEYS */;
INSERT INTO `billing_addresses` VALUES (1,3,NULL,'test','test','','Oslo','0195','NO',NULL,1,1,'2025-06-21 00:15:17','2025-06-21 00:15:17');
/*!40000 ALTER TABLE `billing_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_challenges`
--

DROP TABLE IF EXISTS `daily_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_challenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text,
  `challenge_type` varchar(50) DEFAULT NULL,
  `requirement_value` int DEFAULT NULL,
  `xp_reward` int DEFAULT NULL,
  `bonus_reward` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_challenges`
--

LOCK TABLES `daily_challenges` WRITE;
/*!40000 ALTER TABLE `daily_challenges` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_codes`
--

DROP TABLE IF EXISTS `discount_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `discount_type` varchar(20) NOT NULL,
  `discount_value` decimal(10,2) DEFAULT NULL,
  `free_trial_days` int DEFAULT NULL,
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `max_uses` int DEFAULT NULL,
  `current_uses` int DEFAULT NULL,
  `min_purchase_amount` decimal(10,2) DEFAULT NULL,
  `applicable_plans` varchar(255) DEFAULT NULL,
  `first_time_users_only` tinyint(1) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_by_user_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `discount_codes_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_codes`
--

LOCK TABLES `discount_codes` WRITE;
/*!40000 ALTER TABLE `discount_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_usage`
--

DROP TABLE IF EXISTS `discount_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_usage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code_id` int NOT NULL,
  `user_id` int NOT NULL,
  `payment_id` int DEFAULT NULL,
  `discount_amount` decimal(10,2) DEFAULT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_code_user_payment_uc` (`code_id`,`user_id`,`payment_id`),
  KEY `user_id` (`user_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `discount_usage_ibfk_1` FOREIGN KEY (`code_id`) REFERENCES `discount_codes` (`id`),
  CONSTRAINT `discount_usage_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `discount_usage_ibfk_3` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_usage`
--

LOCK TABLES `discount_usage` WRITE;
/*!40000 ALTER TABLE `discount_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enhanced_quiz_responses`
--

DROP TABLE IF EXISTS `enhanced_quiz_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enhanced_quiz_responses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quiz_response_id` int NOT NULL,
  `user_confidence_level` float DEFAULT NULL,
  `difficulty_perception` float DEFAULT NULL,
  `cognitive_load_score` float DEFAULT NULL,
  `time_to_first_answer` float DEFAULT NULL,
  `answer_change_count` int DEFAULT NULL,
  `hesitation_score` float DEFAULT NULL,
  `question_order_in_session` int DEFAULT NULL,
  `user_fatigue_score` float DEFAULT NULL,
  `predicted_difficulty` float DEFAULT NULL,
  `actual_difficulty` float DEFAULT NULL,
  `knowledge_gain_estimate` float DEFAULT NULL,
  `skill_level_before` float DEFAULT NULL,
  `skill_level_after` float DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quiz_response_id` (`quiz_response_id`),
  CONSTRAINT `enhanced_quiz_responses_ibfk_1` FOREIGN KEY (`quiz_response_id`) REFERENCES `quiz_responses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enhanced_quiz_responses`
--

LOCK TABLES `enhanced_quiz_responses` WRITE;
/*!40000 ALTER TABLE `enhanced_quiz_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `enhanced_quiz_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friend_challenges`
--

DROP TABLE IF EXISTS `friend_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `friend_challenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `challenger_id` int NOT NULL,
  `challenged_id` int NOT NULL,
  `challenge_type` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `wager_xp` int DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `winner_id` int DEFAULT NULL,
  `challenger_score` int DEFAULT NULL,
  `challenged_score` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `challenger_id` (`challenger_id`),
  KEY `challenged_id` (`challenged_id`),
  KEY `winner_id` (`winner_id`),
  CONSTRAINT `friend_challenges_ibfk_1` FOREIGN KEY (`challenger_id`) REFERENCES `users` (`id`),
  CONSTRAINT `friend_challenges_ibfk_2` FOREIGN KEY (`challenged_id`) REFERENCES `users` (`id`),
  CONSTRAINT `friend_challenges_ibfk_3` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friend_challenges`
--

LOCK TABLES `friend_challenges` WRITE;
/*!40000 ALTER TABLE `friend_challenges` DISABLE KEYS */;
/*!40000 ALTER TABLE `friend_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_scenarios`
--

DROP TABLE IF EXISTS `game_scenarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_scenarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text,
  `scenario_type` varchar(50) DEFAULT NULL,
  `difficulty_level` int DEFAULT '1',
  `max_score` int DEFAULT '100',
  `time_limit_seconds` int DEFAULT NULL,
  `config_json` text,
  `template_name` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `order_index` int DEFAULT '0',
  `min_level_required` int DEFAULT '1',
  `is_premium` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_scenarios`
--

LOCK TABLES `game_scenarios` WRITE;
/*!40000 ALTER TABLE `game_scenarios` DISABLE KEYS */;
INSERT INTO `game_scenarios` VALUES (1,'Trafikkskilt Quiz','Identifiser forskjellige trafikkskilt','traffic_signs',1,100,300,'{\"signs_count\": 10, \"time_per_sign\": 30}','traffic_signs_game.html',1,1,1,0),(2,'Kjøreregler Test','Test din kunnskap om kjøreregler','driving_rules',2,150,600,'{\"questions_count\": 15, \"time_per_question\": 40}','rules_game.html',1,2,1,0),(3,'Minnespill - Skilt','Husk sekvenser av trafikkskilt','memory',1,80,240,'{\"sequence_length\": 5, \"show_time\": 2}','memory_game.html',1,3,1,0),(4,'Tidsutfordring','Svar på flest mulig spørsmål på tid','time_challenge',3,200,180,'{\"difficulty\": \"mixed\", \"bonus_time\": 5}','time_challenge.html',1,4,5,1),(5,'Kjøresimulator','Virtuell kjøreøvelse','driving_sim',3,300,900,'{\"scenario\": \"city_driving\", \"weather\": \"normal\"}','driving_sim.html',1,5,10,1);
/*!40000 ALTER TABLE `game_scenarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_sessions`
--

DROP TABLE IF EXISTS `game_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `scenario_id` int NOT NULL,
  `score` int DEFAULT NULL,
  `time_played_seconds` int DEFAULT NULL,
  `mistakes_count` int DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `scenario_id` (`scenario_id`),
  CONSTRAINT `game_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `game_sessions_ibfk_2` FOREIGN KEY (`scenario_id`) REFERENCES `game_scenarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_sessions`
--

LOCK TABLES `game_sessions` WRITE;
/*!40000 ALTER TABLE `game_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leaderboard_entries`
--

DROP TABLE IF EXISTS `leaderboard_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leaderboard_entries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `leaderboard_type` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `score` int DEFAULT NULL,
  `rank_position` int DEFAULT NULL,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `rank` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `leaderboard_entries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaderboard_entries`
--

LOCK TABLES `leaderboard_entries` WRITE;
/*!40000 ALTER TABLE `leaderboard_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `leaderboard_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learning_analytics`
--

DROP TABLE IF EXISTS `learning_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learning_analytics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `date` date NOT NULL,
  `total_study_time_minutes` int DEFAULT NULL,
  `questions_attempted` int DEFAULT NULL,
  `questions_correct` int DEFAULT NULL,
  `average_difficulty_attempted` float DEFAULT NULL,
  `avg_response_time` float DEFAULT NULL,
  `response_time_consistency` float DEFAULT NULL,
  `mistakes_per_session` float DEFAULT NULL,
  `learning_velocity` float DEFAULT NULL,
  `knowledge_retention` float DEFAULT NULL,
  `concept_mastery_score` float DEFAULT NULL,
  `preferred_study_duration` int DEFAULT NULL,
  `optimal_question_difficulty` float DEFAULT NULL,
  `learning_style_indicators` text,
  `weakest_categories` text,
  `strength_categories` text,
  `recommended_study_time` int DEFAULT NULL,
  `recommended_difficulty` float DEFAULT NULL,
  `priority_topics` text,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_date_analytics_uc` (`user_id`,`date`),
  KEY `idx_analytics_user_date` (`user_id`,`date`),
  KEY `idx_analytics_date` (`date`),
  CONSTRAINT `learning_analytics_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learning_analytics`
--

LOCK TABLES `learning_analytics` WRITE;
/*!40000 ALTER TABLE `learning_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `learning_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learning_path_items`
--

DROP TABLE IF EXISTS `learning_path_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learning_path_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `path_id` int NOT NULL,
  `item_type` varchar(50) DEFAULT NULL,
  `item_id` int DEFAULT NULL,
  `order_index` int DEFAULT NULL,
  `is_mandatory` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `path_id` (`path_id`),
  CONSTRAINT `learning_path_items_ibfk_1` FOREIGN KEY (`path_id`) REFERENCES `learning_paths` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learning_path_items`
--

LOCK TABLES `learning_path_items` WRITE;
/*!40000 ALTER TABLE `learning_path_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `learning_path_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learning_paths`
--

DROP TABLE IF EXISTS `learning_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learning_paths` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text,
  `estimated_hours` int DEFAULT NULL,
  `difficulty_level` int DEFAULT '1',
  `icon_filename` varchar(255) DEFAULT NULL,
  `is_recommended` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learning_paths`
--

LOCK TABLES `learning_paths` WRITE;
/*!40000 ALTER TABLE `learning_paths` DISABLE KEYS */;
INSERT INTO `learning_paths` VALUES (1,'Nybegynner Pakke','Alt du trenger for å starte',8,1,'beginner_path.png',1),(2,'Trafikkskilt Mester','Lær alle trafikkskilt',4,2,'signs_path.png',1),(3,'Kjøreregler Ekspert','Dyp forståelse av alle regler',6,2,'rules_path.png',0),(4,'Komplett Forberedelse','Full forberedelse til førerprøven',12,3,'complete_path.png',1);
/*!40000 ALTER TABLE `learning_paths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_email_logs`
--

DROP TABLE IF EXISTS `marketing_email_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_email_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `marketing_email_id` int NOT NULL,
  `user_id` int NOT NULL,
  `recipient_email` varchar(255) NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `error_message` text,
  `provider_response` text,
  `opened_at` datetime DEFAULT NULL,
  `clicked_at` datetime DEFAULT NULL,
  `unsubscribed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_marketing_email_user_uc` (`marketing_email_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `marketing_email_logs_ibfk_1` FOREIGN KEY (`marketing_email_id`) REFERENCES `marketing_emails` (`id`),
  CONSTRAINT `marketing_email_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_email_logs`
--

LOCK TABLES `marketing_email_logs` WRITE;
/*!40000 ALTER TABLE `marketing_email_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_email_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_emails`
--

DROP TABLE IF EXISTS `marketing_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_emails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `html_content` text NOT NULL,
  `target_all_opted_in` tinyint(1) DEFAULT NULL,
  `target_free_users` tinyint(1) DEFAULT NULL,
  `target_premium_users` tinyint(1) DEFAULT NULL,
  `target_pro_users` tinyint(1) DEFAULT NULL,
  `target_active_only` tinyint(1) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `recipients_count` int DEFAULT NULL,
  `sent_count` int DEFAULT NULL,
  `failed_count` int DEFAULT NULL,
  `created_by_user_id` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `marketing_emails_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_emails`
--

LOCK TABLES `marketing_emails` WRITE;
/*!40000 ALTER TABLE `marketing_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_templates`
--

DROP TABLE IF EXISTS `marketing_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `html_content` text NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `times_used` int DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `created_by_user_id` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `marketing_templates_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_templates`
--

LOCK TABLES `marketing_templates` WRITE;
/*!40000 ALTER TABLE `marketing_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_models`
--

DROP TABLE IF EXISTS `ml_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_models` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `version` varchar(50) NOT NULL,
  `description` text,
  `accuracy_score` float DEFAULT NULL,
  `precision_score` float DEFAULT NULL,
  `recall_score` float DEFAULT NULL,
  `f1_score` float DEFAULT NULL,
  `hyperparameters` text,
  `feature_importance` text,
  `is_active` tinyint(1) DEFAULT NULL,
  `total_predictions` int DEFAULT NULL,
  `last_retrained` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_model_version_uc` (`name`,`version`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `ml_models_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_models`
--

LOCK TABLES `ml_models` WRITE;
/*!40000 ALTER TABLE `ml_models` DISABLE KEYS */;
INSERT INTO `ml_models` VALUES (1,'skill_estimator','v1.0','Gradient Boosting model for estimating user skill levels',NULL,NULL,NULL,NULL,'{\"n_estimators\": 100, \"learning_rate\": 0.1, \"max_depth\": 6, \"random_state\": 42}',NULL,1,0,NULL,'2025-06-20 22:46:41',1),(2,'difficulty_predictor','v1.0','Random Forest model for predicting question difficulty',NULL,NULL,NULL,NULL,'{\"n_estimators\": 50, \"max_depth\": 8, \"random_state\": 42}',NULL,1,0,NULL,'2025-06-20 22:46:41',1);
/*!40000 ALTER TABLE `ml_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `options` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question_id` int NOT NULL,
  `option_letter` varchar(1) NOT NULL,
  `option_text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1421 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES (65,11,'a','30 km/t'),(66,11,'b','40 km/t'),(67,11,'c','50 km/t'),(68,11,'d','60 km/t'),(77,13,'a','Senk farten og gi fotgjengere tydelig vikeplikt  '),(78,13,'b','Kjør videre hvis fotgjengeren ikke har begynt å gå '),(79,13,'c','Tut for å varsle og kjør rolig gjennom '),(80,13,'d','Blink og sving unna hvis du ikke kan stoppe i tide'),(85,14,'a','Du har vikeplikt for trafikk som allerede er i rundkjøringen'),(86,14,'b','Du har forkjørsrett når du nærmer deg rundkjøringen'),(87,14,'c','Alle biler skal stoppe før rundkjøringen'),(88,14,'d','Du har vikeplikt for kjøretøy som kommer fra venstre i rundkjøringen'),(89,15,'a','1 sekund'),(90,15,'b','3 sekunder'),(91,15,'c','5 sekunder'),(92,15,'d','10 sekunder'),(117,24,'a','Fotgjengerfelt'),(118,24,'b','Glatt veibane'),(119,24,'c','Innkjøring forbudt'),(120,24,'d','Veiarbeid'),(121,25,'a','Fartsgrense'),(122,25,'b','Veiarbeid'),(123,25,'c','Innkjøring forbudt'),(124,25,'d','Enveiskjøring'),(125,26,'a','Fartsgrense'),(126,26,'b','Stoppskilt'),(127,26,'c','Vikeplikt'),(128,26,'d','Sving forbudt'),(129,27,'a','Veiarbeid'),(130,27,'b','Fotgjengerfelt'),(131,27,'c','Rundkjøring'),(132,27,'d','Innkjøring forbudt'),(145,31,'a','Sving forbudt'),(146,31,'b','Fare for barn'),(147,31,'c','Rundkjøring'),(148,31,'d','Parkering forbudt'),(149,32,'a','Fare for barn'),(150,32,'b','Sving forbudt'),(151,32,'c','Veiarbeid'),(152,32,'d','Glatt veibane'),(153,33,'a','Veiarbeid'),(154,33,'b','Innkjøring forbudt'),(155,33,'c','Stoppskilt'),(156,33,'d','Vikeplikt'),(157,34,'a','Stoppskilt'),(158,34,'b','Rundkjøring'),(159,34,'c','Sving forbudt'),(160,34,'d','Fare for barn'),(161,35,'a','Fartsgrense'),(162,35,'b','Glatt veibane'),(163,35,'c','Veiarbeid'),(164,35,'d','Rundkjøring'),(165,36,'a','Fartsgrense'),(166,36,'b','Fare for barn'),(167,36,'c','Vikeplikt'),(168,36,'d','Rundkjøring'),(169,37,'a','Stoppskilt'),(170,37,'b','Veiarbeid'),(171,37,'c','Glatt veibane'),(172,37,'d','Vikeplikt'),(173,38,'a','Sving forbudt'),(174,38,'b','Rundkjøring'),(175,38,'c','Fare for barn'),(176,38,'d','Veiarbeid'),(177,39,'a','Innkjøring forbudt'),(178,39,'b','Glatt veibane'),(179,39,'c','Rundkjøring'),(180,39,'d','Parkering forbudt'),(181,40,'a','Glatt veibane'),(182,40,'b','Sving forbudt'),(183,40,'c','Fotgjengerfelt'),(184,40,'d','Fartsgrense'),(185,41,'a','Stoppskilt'),(186,41,'b','Parkering forbudt'),(187,41,'c','Innkjøring forbudt'),(188,41,'d','Fotgjengerfelt'),(189,42,'a','Sving forbudt'),(190,42,'b','Vikeplikt'),(191,42,'c','Fotgjengerfelt'),(192,42,'d','Fartsgrense'),(193,43,'a','Fare for barn'),(194,43,'b','Glatt veibane'),(195,43,'c','Fotgjengerfelt'),(196,43,'d','Innkjøring forbudt'),(197,44,'a','Fartsgrense'),(198,44,'b','Veiarbeid'),(199,44,'c','Rundkjøring'),(200,44,'d','Innkjøring forbudt'),(201,45,'a','Enveiskjøring'),(202,45,'b','Fare for barn'),(203,45,'c','Fotgjengerfelt'),(204,45,'d','Fartsgrense'),(205,46,'a','Stoppskilt'),(206,46,'b','Sving forbudt'),(207,46,'c','Fare for barn'),(208,46,'d','Veiarbeid'),(209,47,'a','Sving forbudt'),(210,47,'b','Fartsgrense'),(211,47,'c','Veiarbeid'),(212,47,'d','Vikeplikt'),(213,48,'a','Fotgjengerfelt'),(214,48,'b','Fare for barn'),(215,48,'c','Veiarbeid'),(216,48,'d','Parkering forbudt'),(217,49,'a','Vikeplikt'),(218,49,'b','Innkjøring forbudt'),(219,49,'c','Fartsgrense'),(220,49,'d','Parkering forbudt'),(221,50,'a','Fartsgrense'),(222,50,'b','Fotgjengerfelt'),(223,50,'c','Rundkjøring'),(224,50,'d','Enveiskjøring'),(225,51,'a','Sving forbudt'),(226,51,'b','Fartsgrense'),(227,51,'c','Vikeplikt'),(228,51,'d','Veiarbeid'),(229,52,'a','Fare for barn'),(230,52,'b','Fotgjengerfelt'),(231,52,'c','Sving forbudt'),(232,52,'d','Stoppskilt'),(233,53,'a','Fartsgrense'),(234,53,'b','Enveiskjøring'),(235,53,'c','Fotgjengerfelt'),(236,53,'d','Parkering forbudt'),(237,54,'a','Innkjøring forbudt'),(238,54,'b','Sving forbudt'),(239,54,'c','Stoppskilt'),(240,54,'d','Rundkjøring'),(241,55,'a','Vikeplikt'),(242,55,'b','Enveiskjøring'),(243,55,'c','Innkjøring forbudt'),(244,55,'d','Glatt veibane'),(245,56,'a','Glatt veibane'),(246,56,'b','Fare for barn'),(247,56,'c','Fartsgrense'),(248,56,'d','Parkering forbudt'),(249,57,'a','Glatt veibane'),(250,57,'b','Veiarbeid'),(251,57,'c','Fotgjengerfelt'),(252,57,'d','Stoppskilt'),(253,58,'a','Sving forbudt'),(254,58,'b','Veiarbeid'),(255,58,'c','Rundkjøring'),(256,58,'d','Parkering forbudt'),(257,59,'a','Enveiskjøring'),(258,59,'b','Fotgjengerfelt'),(259,59,'c','Parkering forbudt'),(260,59,'d','Glatt veibane'),(261,60,'a','Veiarbeid'),(262,60,'b','Fotgjengerfelt'),(263,60,'c','Innkjøring forbudt'),(264,60,'d','Rundkjøring'),(265,61,'a','Enveiskjøring'),(266,61,'b','Rundkjøring'),(267,61,'c','Sving forbudt'),(268,61,'d','Vikeplikt'),(269,62,'a','Rundkjøring'),(270,62,'b','Fotgjengerfelt'),(271,62,'c','Parkering forbudt'),(272,62,'d','Veiarbeid'),(273,63,'a','Veiarbeid'),(274,63,'b','Fartsgrense'),(275,63,'c','Parkering forbudt'),(276,63,'d','Stoppskilt'),(277,64,'a','Fare for barn'),(278,64,'b','Glatt veibane'),(279,64,'c','Rundkjøring'),(280,64,'d','Fartsgrense'),(281,65,'a','Stoppskilt'),(282,65,'b','Fartsgrense'),(283,65,'c','Fotgjengerfelt'),(284,65,'d','Rundkjøring'),(285,66,'a','Vikeplikt'),(286,66,'b','Innkjøring forbudt'),(287,66,'c','Fartsgrense'),(288,66,'d','Glatt veibane'),(289,67,'a','Fotgjengerfelt'),(290,67,'b','Enveiskjøring'),(291,67,'c','Innkjøring forbudt'),(292,67,'d','Veiarbeid'),(293,68,'a','Fotgjengerfelt'),(294,68,'b','Rundkjøring'),(295,68,'c','Fare for barn'),(296,68,'d','Fartsgrense'),(297,69,'a','Fotgjengerfelt'),(298,69,'b','Fare for barn'),(299,69,'c','Glatt veibane'),(300,69,'d','Innkjøring forbudt'),(301,70,'a','Fartsgrense'),(302,70,'b','Parkering forbudt'),(303,70,'c','Fotgjengerfelt'),(304,70,'d','Sving forbudt'),(305,71,'a','Stoppskilt'),(306,71,'b','Parkering forbudt'),(307,71,'c','Enveiskjøring'),(308,71,'d','Vikeplikt'),(309,72,'a','Fare for barn'),(310,72,'b','Rundkjøring'),(311,72,'c','Sving forbudt'),(312,72,'d','Enveiskjøring'),(313,73,'a','Fare for barn'),(314,73,'b','Fartsgrense'),(315,73,'c','Vikeplikt'),(316,73,'d','Innkjøring forbudt'),(317,74,'a','Fare for barn'),(318,74,'b','Fotgjengerfelt'),(319,74,'c','Fartsgrense'),(320,74,'d','Vikeplikt'),(321,75,'a','Stoppskilt'),(322,75,'b','Fartsgrense'),(323,75,'c','Fare for barn'),(324,75,'d','Sving forbudt'),(325,76,'a','Vikeplikt'),(326,76,'b','Fotgjengerfelt'),(327,76,'c','Stoppskilt'),(328,76,'d','Fare for barn'),(329,77,'a','Sving forbudt'),(330,77,'b','Stoppskilt'),(331,77,'c','Parkering forbudt'),(332,77,'d','Fartsgrense'),(333,78,'a','Fotgjengerfelt'),(334,78,'b','Parkering forbudt'),(335,78,'c','Innkjøring forbudt'),(336,78,'d','Rundkjøring'),(337,79,'a','Sving forbudt'),(338,79,'b','Fartsgrense'),(339,79,'c','Parkering forbudt'),(340,79,'d','Innkjøring forbudt'),(341,80,'a','Veiarbeid'),(342,80,'b','Enveiskjøring'),(343,80,'c','Fartsgrense'),(344,80,'d','Sving forbudt'),(345,81,'a','Innkjøring forbudt'),(346,81,'b','Parkering forbudt'),(347,81,'c','Glatt veibane'),(348,81,'d','Fare for barn'),(349,82,'a','Parkering forbudt'),(350,82,'b','Sving forbudt'),(351,82,'c','Fotgjengerfelt'),(352,82,'d','Fartsgrense'),(353,83,'a','Rundkjøring'),(354,83,'b','Vikeplikt'),(355,83,'c','Enveiskjøring'),(356,83,'d','Stoppskilt'),(357,84,'a','Fotgjengerfelt'),(358,84,'b','Fartsgrense'),(359,84,'c','Innkjøring forbudt'),(360,84,'d','Enveiskjøring'),(361,85,'a','Glatt veibane'),(362,85,'b','Parkering forbudt'),(363,85,'c','Sving forbudt'),(364,85,'d','Fartsgrense'),(365,86,'a','Fotgjengerfelt'),(366,86,'b','Veiarbeid'),(367,86,'c','Glatt veibane'),(368,86,'d','Stoppskilt'),(369,87,'a','Parkering forbudt'),(370,87,'b','Glatt veibane'),(371,87,'c','Fotgjengerfelt'),(372,87,'d','Veiarbeid'),(373,88,'a','Fare for barn'),(374,88,'b','Innkjøring forbudt'),(375,88,'c','Fartsgrense'),(376,88,'d','Parkering forbudt'),(377,89,'a','Fotgjengerfelt'),(378,89,'b','Sving forbudt'),(379,89,'c','Enveiskjøring'),(380,89,'d','Stoppskilt'),(381,90,'a','Veiarbeid'),(382,90,'b','Innkjøring forbudt'),(383,90,'c','Stoppskilt'),(384,90,'d','Fare for barn'),(385,91,'a','Rundkjøring'),(386,91,'b','Fartsgrense'),(387,91,'c','Parkering forbudt'),(388,91,'d','Innkjøring forbudt'),(389,92,'a','Fotgjengerfelt'),(390,92,'b','Fare for barn'),(391,92,'c','Veiarbeid'),(392,92,'d','Sving forbudt'),(393,93,'a','Glatt veibane'),(394,93,'b','Enveiskjøring'),(395,93,'c','Sving forbudt'),(396,93,'d','Fare for barn'),(397,94,'a','Sving forbudt'),(398,94,'b','Parkering forbudt'),(399,94,'c','Enveiskjøring'),(400,94,'d','Glatt veibane'),(401,95,'a','Vikeplikt'),(402,95,'b','Fotgjengerfelt'),(403,95,'c','Glatt veibane'),(404,95,'d','Enveiskjøring'),(405,96,'a','Enveiskjøring'),(406,96,'b','Fotgjengerfelt'),(407,96,'c','Fartsgrense'),(408,96,'d','Sving forbudt'),(409,97,'a','Enveiskjøring'),(410,97,'b','Stoppskilt'),(411,97,'c','Fartsgrense'),(412,97,'d','Vikeplikt'),(413,98,'a','Stoppskilt'),(414,98,'b','Fare for barn'),(415,98,'c','Enveiskjøring'),(416,98,'d','Veiarbeid'),(417,99,'a','Rundkjøring'),(418,99,'b','Glatt veibane'),(419,99,'c','Innkjøring forbudt'),(420,99,'d','Stoppskilt'),(421,100,'a','Glatt veibane'),(422,100,'b','Rundkjøring'),(423,100,'c','Fare for barn'),(424,100,'d','Innkjøring forbudt'),(425,101,'a','Fare for barn'),(426,101,'b','Stoppskilt'),(427,101,'c','Rundkjøring'),(428,101,'d','Vikeplikt'),(429,102,'a','Fotgjengerfelt'),(430,102,'b','Fartsgrense'),(431,102,'c','Veiarbeid'),(432,102,'d','Fare for barn'),(433,103,'a','Innkjøring forbudt'),(434,103,'b','Fotgjengerfelt'),(435,103,'c','Fare for barn'),(436,103,'d','Vikeplikt'),(437,104,'a','Veiarbeid'),(438,104,'b','Fare for barn'),(439,104,'c','Sving forbudt'),(440,104,'d','Parkering forbudt'),(441,105,'a','Fotgjengerfelt'),(442,105,'b','Vikeplikt'),(443,105,'c','Innkjøring forbudt'),(444,105,'d','Rundkjøring'),(445,106,'a','Enveiskjøring'),(446,106,'b','Veiarbeid'),(447,106,'c','Rundkjøring'),(448,106,'d','Fare for barn'),(449,107,'a','Fotgjengerfelt'),(450,107,'b','Enveiskjøring'),(451,107,'c','Veiarbeid'),(452,107,'d','Vikeplikt'),(453,108,'a','Vikeplikt'),(454,108,'b','Sving forbudt'),(455,108,'c','Veiarbeid'),(456,108,'d','Stoppskilt'),(457,109,'a','Glatt veibane'),(458,109,'b','Rundkjøring'),(459,109,'c','Fare for barn'),(460,109,'d','Enveiskjøring'),(461,110,'a','Innkjøring forbudt'),(462,110,'b','Glatt veibane'),(463,110,'c','Sving forbudt'),(464,110,'d','Rundkjøring'),(465,111,'a','Fare for barn'),(466,111,'b','Parkering forbudt'),(467,111,'c','Innkjøring forbudt'),(468,111,'d','Fotgjengerfelt'),(469,112,'a','Fotgjengerfelt'),(470,112,'b','Stoppskilt'),(471,112,'c','Parkering forbudt'),(472,112,'d','Veiarbeid'),(473,113,'a','Vikeplikt'),(474,113,'b','Sving forbudt'),(475,113,'c','Fotgjengerfelt'),(476,113,'d','Fartsgrense'),(477,114,'a','Rundkjøring'),(478,114,'b','Sving forbudt'),(479,114,'c','Stoppskilt'),(480,114,'d','Fartsgrense'),(481,115,'a','Stoppskilt'),(482,115,'b','Veiarbeid'),(483,115,'c','Fartsgrense'),(484,115,'d','Innkjøring forbudt'),(485,116,'a','Glatt veibane'),(486,116,'b','Rundkjøring'),(487,116,'c','Parkering forbudt'),(488,116,'d','Innkjøring forbudt'),(489,117,'a','Glatt veibane'),(490,117,'b','Fare for barn'),(491,117,'c','Enveiskjøring'),(492,117,'d','Stoppskilt'),(493,118,'a','Parkering forbudt'),(494,118,'b','Fotgjengerfelt'),(495,118,'c','Stoppskilt'),(496,118,'d','Glatt veibane'),(497,119,'a','Fare for barn'),(498,119,'b','Rundkjøring'),(499,119,'c','Fartsgrense'),(500,119,'d','Vikeplikt'),(501,120,'a','Rundkjøring'),(502,120,'b','Parkering forbudt'),(503,120,'c','Innkjøring forbudt'),(504,120,'d','Enveiskjøring'),(505,121,'a','Vikeplikt'),(506,121,'b','Innkjøring forbudt'),(507,121,'c','Rundkjøring'),(508,121,'d','Fartsgrense'),(509,122,'a','Rundkjøring'),(510,122,'b','Fartsgrense'),(511,122,'c','Veiarbeid'),(512,122,'d','Parkering forbudt'),(513,123,'a','Fare for barn'),(514,123,'b','Sving forbudt'),(515,123,'c','Glatt veibane'),(516,123,'d','Fartsgrense'),(517,124,'a','Glatt veibane'),(518,124,'b','Enveiskjøring'),(519,124,'c','Veiarbeid'),(520,124,'d','Rundkjøring'),(521,125,'a','Rundkjøring'),(522,125,'b','Stoppskilt'),(523,125,'c','Enveiskjøring'),(524,125,'d','Glatt veibane'),(525,126,'a','Fotgjengerfelt'),(526,126,'b','Innkjøring forbudt'),(527,126,'c','Rundkjøring'),(528,126,'d','Enveiskjøring'),(529,127,'a','Glatt veibane'),(530,127,'b','Fartsgrense'),(531,127,'c','Vikeplikt'),(532,127,'d','Sving forbudt'),(533,128,'a','Parkering forbudt'),(534,128,'b','Glatt veibane'),(535,128,'c','Veiarbeid'),(536,128,'d','Rundkjøring'),(537,129,'a','Enveiskjøring'),(538,129,'b','Fartsgrense'),(539,129,'c','Sving forbudt'),(540,129,'d','Innkjøring forbudt'),(541,130,'a','Stoppskilt'),(542,130,'b','Rundkjøring'),(543,130,'c','Enveiskjøring'),(544,130,'d','Fare for barn'),(545,131,'a','Veiarbeid'),(546,131,'b','Fare for barn'),(547,131,'c','Vikeplikt'),(548,131,'d','Enveiskjøring'),(549,132,'a','Parkering forbudt'),(550,132,'b','Fare for barn'),(551,132,'c','Vikeplikt'),(552,132,'d','Glatt veibane'),(553,133,'a','Veiarbeid'),(554,133,'b','Enveiskjøring'),(555,133,'c','Fotgjengerfelt'),(556,133,'d','Fartsgrense'),(557,134,'a','Vikeplikt'),(558,134,'b','Parkering forbudt'),(559,134,'c','Veiarbeid'),(560,134,'d','Fare for barn'),(561,135,'a','Veiarbeid'),(562,135,'b','Sving forbudt'),(563,135,'c','Vikeplikt'),(564,135,'d','Stoppskilt'),(565,136,'a','Fare for barn'),(566,136,'b','Vikeplikt'),(567,136,'c','Innkjøring forbudt'),(568,136,'d','Fartsgrense'),(569,137,'a','Innkjøring forbudt'),(570,137,'b','Glatt veibane'),(571,137,'c','Stoppskilt'),(572,137,'d','Parkering forbudt'),(573,138,'a','Sving forbudt'),(574,138,'b','Stoppskilt'),(575,138,'c','Fotgjengerfelt'),(576,138,'d','Vikeplikt'),(577,139,'a','Enveiskjøring'),(578,139,'b','Sving forbudt'),(579,139,'c','Stoppskilt'),(580,139,'d','Veiarbeid'),(581,140,'a','Enveiskjøring'),(582,140,'b','Vikeplikt'),(583,140,'c','Glatt veibane'),(584,140,'d','Stoppskilt'),(585,141,'a','Sving forbudt'),(586,141,'b','Fotgjengerfelt'),(587,141,'c','Fartsgrense'),(588,141,'d','Stoppskilt'),(589,142,'a','Sving forbudt'),(590,142,'b','Veiarbeid'),(591,142,'c','Vikeplikt'),(592,142,'d','Rundkjøring'),(593,143,'a','Parkering forbudt'),(594,143,'b','Sving forbudt'),(595,143,'c','Fartsgrense'),(596,143,'d','Rundkjøring'),(597,144,'a','Rundkjøring'),(598,144,'b','Fartsgrense'),(599,144,'c','Vikeplikt'),(600,144,'d','Stoppskilt'),(601,145,'a','Fotgjengerfelt'),(602,145,'b','Fartsgrense'),(603,145,'c','Sving forbudt'),(604,145,'d','Stoppskilt'),(605,146,'a','Vikeplikt'),(606,146,'b','Fartsgrense'),(607,146,'c','Sving forbudt'),(608,146,'d','Fare for barn'),(609,147,'a','Fotgjengerfelt'),(610,147,'b','Enveiskjøring'),(611,147,'c','Rundkjøring'),(612,147,'d','Parkering forbudt'),(613,148,'a','Fotgjengerfelt'),(614,148,'b','Innkjøring forbudt'),(615,148,'c','Veiarbeid'),(616,148,'d','Rundkjøring'),(617,149,'a','Fartsgrense'),(618,149,'b','Innkjøring forbudt'),(619,149,'c','Veiarbeid'),(620,149,'d','Rundkjøring'),(621,150,'a','Sving forbudt'),(622,150,'b','Veiarbeid'),(623,150,'c','Stoppskilt'),(624,150,'d','Parkering forbudt'),(625,151,'a','Stoppskilt'),(626,151,'b','Vikeplikt'),(627,151,'c','Enveiskjøring'),(628,151,'d','Glatt veibane'),(629,152,'a','Fotgjengerfelt'),(630,152,'b','Rundkjøring'),(631,152,'c','Enveiskjøring'),(632,152,'d','Glatt veibane'),(633,153,'a','Innkjøring forbudt'),(634,153,'b','Sving forbudt'),(635,153,'c','Veiarbeid'),(636,153,'d','Enveiskjøring'),(637,154,'a','Rundkjøring'),(638,154,'b','Vikeplikt'),(639,154,'c','Parkering forbudt'),(640,154,'d','Glatt veibane'),(641,155,'a','Fotgjengerfelt'),(642,155,'b','Vikeplikt'),(643,155,'c','Enveiskjøring'),(644,155,'d','Stoppskilt'),(645,156,'a','Glatt veibane'),(646,156,'b','Fotgjengerfelt'),(647,156,'c','Fartsgrense'),(648,156,'d','Sving forbudt'),(649,157,'a','Sving forbudt'),(650,157,'b','Stoppskilt'),(651,157,'c','Fare for barn'),(652,157,'d','Fotgjengerfelt'),(653,158,'a','Sving forbudt'),(654,158,'b','Stoppskilt'),(655,158,'c','Veiarbeid'),(656,158,'d','Rundkjøring'),(657,159,'a','Stoppskilt'),(658,159,'b','Parkering forbudt'),(659,159,'c','Rundkjøring'),(660,159,'d','Fartsgrense'),(661,160,'a','Fotgjengerfelt'),(662,160,'b','Parkering forbudt'),(663,160,'c','Glatt veibane'),(664,160,'d','Fare for barn'),(665,161,'a','Stoppskilt'),(666,161,'b','Fare for barn'),(667,161,'c','Enveiskjøring'),(668,161,'d','Vikeplikt'),(669,162,'a','Rundkjøring'),(670,162,'b','Stoppskilt'),(671,162,'c','Vikeplikt'),(672,162,'d','Fotgjengerfelt'),(673,163,'a','Innkjøring forbudt'),(674,163,'b','Stoppskilt'),(675,163,'c','Veiarbeid'),(676,163,'d','Enveiskjøring'),(677,164,'a','Veiarbeid'),(678,164,'b','Sving forbudt'),(679,164,'c','Parkering forbudt'),(680,164,'d','Stoppskilt'),(681,165,'a','Sving forbudt'),(682,165,'b','Rundkjøring'),(683,165,'c','Vikeplikt'),(684,165,'d','Glatt veibane'),(685,166,'a','Vikeplikt'),(686,166,'b','Veiarbeid'),(687,166,'c','Glatt veibane'),(688,166,'d','Fartsgrense'),(689,167,'a','Veiarbeid'),(690,167,'b','Fartsgrense'),(691,167,'c','Glatt veibane'),(692,167,'d','Enveiskjøring'),(693,168,'a','Parkering forbudt'),(694,168,'b','Stoppskilt'),(695,168,'c','Fare for barn'),(696,168,'d','Innkjøring forbudt'),(697,169,'a','Fartsgrense'),(698,169,'b','Enveiskjøring'),(699,169,'c','Vikeplikt'),(700,169,'d','Stoppskilt'),(701,170,'a','Veiarbeid'),(702,170,'b','Fotgjengerfelt'),(703,170,'c','Fare for barn'),(704,170,'d','Vikeplikt'),(705,171,'a','Fare for barn'),(706,171,'b','Fotgjengerfelt'),(707,171,'c','Fartsgrense'),(708,171,'d','Rundkjøring'),(709,172,'a','Stoppskilt'),(710,172,'b','Veiarbeid'),(711,172,'c','Rundkjøring'),(712,172,'d','Glatt veibane'),(713,173,'a','Glatt veibane'),(714,173,'b','Veiarbeid'),(715,173,'c','Parkering forbudt'),(716,173,'d','Vikeplikt'),(717,174,'a','Fartsgrense'),(718,174,'b','Parkering forbudt'),(719,174,'c','Veiarbeid'),(720,174,'d','Enveiskjøring'),(721,175,'a','Stoppskilt'),(722,175,'b','Rundkjøring'),(723,175,'c','Parkering forbudt'),(724,175,'d','Sving forbudt'),(725,176,'a','Rundkjøring'),(726,176,'b','Fare for barn'),(727,176,'c','Parkering forbudt'),(728,176,'d','Sving forbudt'),(729,177,'a','Fare for barn'),(730,177,'b','Enveiskjøring'),(731,177,'c','Stoppskilt'),(732,177,'d','Fotgjengerfelt'),(733,178,'a','Innkjøring forbudt'),(734,178,'b','Sving forbudt'),(735,178,'c','Glatt veibane'),(736,178,'d','Fartsgrense'),(737,179,'a','Veiarbeid'),(738,179,'b','Fartsgrense'),(739,179,'c','Parkering forbudt'),(740,179,'d','Glatt veibane'),(741,180,'a','Fartsgrense'),(742,180,'b','Fare for barn'),(743,180,'c','Fotgjengerfelt'),(744,180,'d','Veiarbeid'),(745,181,'a','Fartsgrense'),(746,181,'b','Rundkjøring'),(747,181,'c','Stoppskilt'),(748,181,'d','Veiarbeid'),(749,182,'a','Veiarbeid'),(750,182,'b','Fartsgrense'),(751,182,'c','Fare for barn'),(752,182,'d','Vikeplikt'),(753,183,'a','Veiarbeid'),(754,183,'b','Vikeplikt'),(755,183,'c','Stoppskilt'),(756,183,'d','Innkjøring forbudt'),(757,184,'a','Sving forbudt'),(758,184,'b','Vikeplikt'),(759,184,'c','Glatt veibane'),(760,184,'d','Fare for barn'),(761,185,'a','Fare for barn'),(762,185,'b','Rundkjøring'),(763,185,'c','Vikeplikt'),(764,185,'d','Fartsgrense'),(765,186,'a','Innkjøring forbudt'),(766,186,'b','Fotgjengerfelt'),(767,186,'c','Fartsgrense'),(768,186,'d','Veiarbeid'),(769,187,'a','Veiarbeid'),(770,187,'b','Fartsgrense'),(771,187,'c','Sving forbudt'),(772,187,'d','Vikeplikt'),(773,188,'a','Glatt veibane'),(774,188,'b','Enveiskjøring'),(775,188,'c','Sving forbudt'),(776,188,'d','Fotgjengerfelt'),(777,189,'a','Fotgjengerfelt'),(778,189,'b','Fartsgrense'),(779,189,'c','Fare for barn'),(780,189,'d','Stoppskilt'),(781,190,'a','Enveiskjøring'),(782,190,'b','Stoppskilt'),(783,190,'c','Sving forbudt'),(784,190,'d','Fartsgrense'),(785,191,'a','Fare for barn'),(786,191,'b','Enveiskjøring'),(787,191,'c','Fotgjengerfelt'),(788,191,'d','Rundkjøring'),(789,192,'a','Vikeplikt'),(790,192,'b','Stoppskilt'),(791,192,'c','Fotgjengerfelt'),(792,192,'d','Enveiskjøring'),(793,193,'a','Fare for barn'),(794,193,'b','Vikeplikt'),(795,193,'c','Fotgjengerfelt'),(796,193,'d','Parkering forbudt'),(797,194,'a','Vikeplikt'),(798,194,'b','Innkjøring forbudt'),(799,194,'c','Glatt veibane'),(800,194,'d','Fartsgrense'),(801,195,'a','Fartsgrense'),(802,195,'b','Enveiskjøring'),(803,195,'c','Parkering forbudt'),(804,195,'d','Fotgjengerfelt'),(805,196,'a','Sving forbudt'),(806,196,'b','Innkjøring forbudt'),(807,196,'c','Vikeplikt'),(808,196,'d','Fare for barn'),(809,197,'a','Rundkjøring'),(810,197,'b','Fotgjengerfelt'),(811,197,'c','Sving forbudt'),(812,197,'d','Enveiskjøring'),(813,198,'a','Glatt veibane'),(814,198,'b','Stoppskilt'),(815,198,'c','Sving forbudt'),(816,198,'d','Fotgjengerfelt'),(817,199,'a','Veiarbeid'),(818,199,'b','Rundkjøring'),(819,199,'c','Enveiskjøring'),(820,199,'d','Vikeplikt'),(821,200,'a','Stoppskilt'),(822,200,'b','Enveiskjøring'),(823,200,'c','Parkering forbudt'),(824,200,'d','Vikeplikt'),(825,201,'a','Glatt veibane'),(826,201,'b','Enveiskjøring'),(827,201,'c','Fotgjengerfelt'),(828,201,'d','Vikeplikt'),(829,202,'a','Fare for barn'),(830,202,'b','Innkjøring forbudt'),(831,202,'c','Parkering forbudt'),(832,202,'d','Rundkjøring'),(833,203,'a','Sving forbudt'),(834,203,'b','Fare for barn'),(835,203,'c','Parkering forbudt'),(836,203,'d','Veiarbeid'),(837,204,'a','Stoppskilt'),(838,204,'b','Parkering forbudt'),(839,204,'c','Fotgjengerfelt'),(840,204,'d','Fare for barn'),(841,205,'a','Fotgjengerfelt'),(842,205,'b','Veiarbeid'),(843,205,'c','Stoppskilt'),(844,205,'d','Enveiskjøring'),(845,206,'a','Fare for barn'),(846,206,'b','Stoppskilt'),(847,206,'c','Fartsgrense'),(848,206,'d','Veiarbeid'),(849,207,'a','Enveiskjøring'),(850,207,'b','Veiarbeid'),(851,207,'c','Parkering forbudt'),(852,207,'d','Fotgjengerfelt'),(853,208,'a','Vikeplikt'),(854,208,'b','Fare for barn'),(855,208,'c','Stoppskilt'),(856,208,'d','Parkering forbudt'),(857,209,'a','Fotgjengerfelt'),(858,209,'b','Parkering forbudt'),(859,209,'c','Fare for barn'),(860,209,'d','Glatt veibane'),(861,210,'a','Fartsgrense'),(862,210,'b','Stoppskilt'),(863,210,'c','Vikeplikt'),(864,210,'d','Rundkjøring'),(865,211,'a','Fare for barn'),(866,211,'b','Veiarbeid'),(867,211,'c','Parkering forbudt'),(868,211,'d','Fartsgrense'),(869,212,'a','Rundkjøring'),(870,212,'b','Veiarbeid'),(871,212,'c','Sving forbudt'),(872,212,'d','Innkjøring forbudt'),(873,213,'a','Fare for barn'),(874,213,'b','Rundkjøring'),(875,213,'c','Sving forbudt'),(876,213,'d','Fotgjengerfelt'),(877,214,'a','Parkering forbudt'),(878,214,'b','Rundkjøring'),(879,214,'c','Innkjøring forbudt'),(880,214,'d','Stoppskilt'),(881,215,'a','Enveiskjøring'),(882,215,'b','Vikeplikt'),(883,215,'c','Fotgjengerfelt'),(884,215,'d','Parkering forbudt'),(885,216,'a','Sving forbudt'),(886,216,'b','Stoppskilt'),(887,216,'c','Parkering forbudt'),(888,216,'d','Fotgjengerfelt'),(889,217,'a','Enveiskjøring'),(890,217,'b','Parkering forbudt'),(891,217,'c','Rundkjøring'),(892,217,'d','Glatt veibane'),(893,218,'a','Veiarbeid'),(894,218,'b','Glatt veibane'),(895,218,'c','Vikeplikt'),(896,218,'d','Fotgjengerfelt'),(897,219,'a','Stoppskilt'),(898,219,'b','Fotgjengerfelt'),(899,219,'c','Rundkjøring'),(900,219,'d','Parkering forbudt'),(901,220,'a','Rundkjøring'),(902,220,'b','Innkjøring forbudt'),(903,220,'c','Fare for barn'),(904,220,'d','Enveiskjøring'),(905,221,'a','Veiarbeid'),(906,221,'b','Fartsgrense'),(907,221,'c','Enveiskjøring'),(908,221,'d','Rundkjøring'),(909,222,'a','Fartsgrense'),(910,222,'b','Enveiskjøring'),(911,222,'c','Parkering forbudt'),(912,222,'d','Glatt veibane'),(913,223,'a','Glatt veibane'),(914,223,'b','Fotgjengerfelt'),(915,223,'c','Enveiskjøring'),(916,223,'d','Parkering forbudt'),(917,224,'a','Innkjøring forbudt'),(918,224,'b','Glatt veibane'),(919,224,'c','Fartsgrense'),(920,224,'d','Rundkjøring'),(921,225,'a','Innkjøring forbudt'),(922,225,'b','Sving forbudt'),(923,225,'c','Parkering forbudt'),(924,225,'d','Veiarbeid'),(925,226,'a','Enveiskjøring'),(926,226,'b','Fotgjengerfelt'),(927,226,'c','Fare for barn'),(928,226,'d','Innkjøring forbudt'),(929,227,'a','Enveiskjøring'),(930,227,'b','Innkjøring forbudt'),(931,227,'c','Rundkjøring'),(932,227,'d','Glatt veibane'),(933,228,'a','Enveiskjøring'),(934,228,'b','Fartsgrense'),(935,228,'c','Fotgjengerfelt'),(936,228,'d','Innkjøring forbudt'),(937,229,'a','Vikeplikt'),(938,229,'b','Innkjøring forbudt'),(939,229,'c','Fotgjengerfelt'),(940,229,'d','Glatt veibane'),(941,230,'a','Vikeplikt'),(942,230,'b','Enveiskjøring'),(943,230,'c','Fotgjengerfelt'),(944,230,'d','Sving forbudt'),(945,231,'a','Fotgjengerfelt'),(946,231,'b','Fare for barn'),(947,231,'c','Stoppskilt'),(948,231,'d','Sving forbudt'),(949,232,'a','Glatt veibane'),(950,232,'b','Stoppskilt'),(951,232,'c','Vikeplikt'),(952,232,'d','Innkjøring forbudt'),(953,233,'a','Parkering forbudt'),(954,233,'b','Glatt veibane'),(955,233,'c','Fotgjengerfelt'),(956,233,'d','Rundkjøring'),(957,234,'a','Rundkjøring'),(958,234,'b','Sving forbudt'),(959,234,'c','Fare for barn'),(960,234,'d','Innkjøring forbudt'),(961,235,'a','Veiarbeid'),(962,235,'b','Glatt veibane'),(963,235,'c','Stoppskilt'),(964,235,'d','Innkjøring forbudt'),(965,236,'a','Fare for barn'),(966,236,'b','Glatt veibane'),(967,236,'c','Stoppskilt'),(968,236,'d','Enveiskjøring'),(969,237,'a','Sving forbudt'),(970,237,'b','Innkjøring forbudt'),(971,237,'c','Rundkjøring'),(972,237,'d','Fare for barn'),(973,238,'a','Glatt veibane'),(974,238,'b','Parkering forbudt'),(975,238,'c','Fare for barn'),(976,238,'d','Veiarbeid'),(977,239,'a','Enveiskjøring'),(978,239,'b','Fare for barn'),(979,239,'c','Sving forbudt'),(980,239,'d','Fartsgrense'),(981,240,'a','Stoppskilt'),(982,240,'b','Fare for barn'),(983,240,'c','Fotgjengerfelt'),(984,240,'d','Fartsgrense'),(985,241,'a','Glatt veibane'),(986,241,'b','Stoppskilt'),(987,241,'c','Vikeplikt'),(988,241,'d','Enveiskjøring'),(989,242,'a','Fare for barn'),(990,242,'b','Fotgjengerfelt'),(991,242,'c','Veiarbeid'),(992,242,'d','Rundkjøring'),(993,243,'a','Fartsgrense'),(994,243,'b','Rundkjøring'),(995,243,'c','Fotgjengerfelt'),(996,243,'d','Veiarbeid'),(997,244,'a','Rundkjøring'),(998,244,'b','Sving forbudt'),(999,244,'c','Parkering forbudt'),(1000,244,'d','Innkjøring forbudt'),(1001,245,'a','Enveiskjøring'),(1002,245,'b','Fare for barn'),(1003,245,'c','Fotgjengerfelt'),(1004,245,'d','Veiarbeid'),(1005,246,'a','Sving forbudt'),(1006,246,'b','Fartsgrense'),(1007,246,'c','Vikeplikt'),(1008,246,'d','Innkjøring forbudt'),(1009,247,'a','Innkjøring forbudt'),(1010,247,'b','Parkering forbudt'),(1011,247,'c','Vikeplikt'),(1012,247,'d','Fotgjengerfelt'),(1013,248,'a','Veiarbeid'),(1014,248,'b','Vikeplikt'),(1015,248,'c','Fartsgrense'),(1016,248,'d','Sving forbudt'),(1017,249,'a','Fartsgrense'),(1018,249,'b','Innkjøring forbudt'),(1019,249,'c','Glatt veibane'),(1020,249,'d','Sving forbudt'),(1021,250,'a','Vikeplikt'),(1022,250,'b','Veiarbeid'),(1023,250,'c','Sving forbudt'),(1024,250,'d','Fotgjengerfelt'),(1025,251,'a','Veiarbeid'),(1026,251,'b','Rundkjøring'),(1027,251,'c','Enveiskjøring'),(1028,251,'d','Innkjøring forbudt'),(1029,252,'a','Fotgjengerfelt'),(1030,252,'b','Enveiskjøring'),(1031,252,'c','Stoppskilt'),(1032,252,'d','Sving forbudt'),(1033,253,'a','Sving forbudt'),(1034,253,'b','Innkjøring forbudt'),(1035,253,'c','Vikeplikt'),(1036,253,'d','Rundkjøring'),(1037,254,'a','Fotgjengerfelt'),(1038,254,'b','Enveiskjøring'),(1039,254,'c','Glatt veibane'),(1040,254,'d','Innkjøring forbudt'),(1041,255,'a','Sving forbudt'),(1042,255,'b','Fartsgrense'),(1043,255,'c','Fotgjengerfelt'),(1044,255,'d','Enveiskjøring'),(1045,256,'a','Fare for barn'),(1046,256,'b','Glatt veibane'),(1047,256,'c','Fotgjengerfelt'),(1048,256,'d','Enveiskjøring'),(1049,257,'a','Sving forbudt'),(1050,257,'b','Rundkjøring'),(1051,257,'c','Veiarbeid'),(1052,257,'d','Stoppskilt'),(1053,258,'a','Veiarbeid'),(1054,258,'b','Sving forbudt'),(1055,258,'c','Fare for barn'),(1056,258,'d','Vikeplikt'),(1057,259,'a','Enveiskjøring'),(1058,259,'b','Stoppskilt'),(1059,259,'c','Fotgjengerfelt'),(1060,259,'d','Fartsgrense'),(1061,260,'a','Sving forbudt'),(1062,260,'b','Fotgjengerfelt'),(1063,260,'c','Innkjøring forbudt'),(1064,260,'d','Rundkjøring'),(1065,261,'a','Fotgjengerfelt'),(1066,261,'b','Rundkjøring'),(1067,261,'c','Veiarbeid'),(1068,261,'d','Innkjøring forbudt'),(1069,262,'a','Parkering forbudt'),(1070,262,'b','Veiarbeid'),(1071,262,'c','Enveiskjøring'),(1072,262,'d','Fare for barn'),(1073,263,'a','Sving forbudt'),(1074,263,'b','Enveiskjøring'),(1075,263,'c','Fare for barn'),(1076,263,'d','Fartsgrense'),(1077,264,'a','Fare for barn'),(1078,264,'b','Glatt veibane'),(1079,264,'c','Vikeplikt'),(1080,264,'d','Stoppskilt'),(1081,265,'a','Stoppskilt'),(1082,265,'b','Sving forbudt'),(1083,265,'c','Fartsgrense'),(1084,265,'d','Parkering forbudt'),(1085,266,'a','Veiarbeid'),(1086,266,'b','Fotgjengerfelt'),(1087,266,'c','Enveiskjøring'),(1088,266,'d','Sving forbudt'),(1089,267,'a','Veiarbeid'),(1090,267,'b','Innkjøring forbudt'),(1091,267,'c','Stoppskilt'),(1092,267,'d','Rundkjøring'),(1093,268,'a','Innkjøring forbudt'),(1094,268,'b','Fotgjengerfelt'),(1095,268,'c','Stoppskilt'),(1096,268,'d','Enveiskjøring'),(1097,269,'a','Vikeplikt'),(1098,269,'b','Fotgjengerfelt'),(1099,269,'c','Fartsgrense'),(1100,269,'d','Stoppskilt'),(1101,270,'a','Vikeplikt'),(1102,270,'b','Rundkjøring'),(1103,270,'c','Veiarbeid'),(1104,270,'d','Sving forbudt'),(1105,271,'a','Parkering forbudt'),(1106,271,'b','Fotgjengerfelt'),(1107,271,'c','Fartsgrense'),(1108,271,'d','Vikeplikt'),(1109,272,'a','Glatt veibane'),(1110,272,'b','Vikeplikt'),(1111,272,'c','Fotgjengerfelt'),(1112,272,'d','Enveiskjøring'),(1113,273,'a','Enveiskjøring'),(1114,273,'b','Glatt veibane'),(1115,273,'c','Rundkjøring'),(1116,273,'d','Innkjøring forbudt'),(1117,274,'a','Enveiskjøring'),(1118,274,'b','Vikeplikt'),(1119,274,'c','Fotgjengerfelt'),(1120,274,'d','Stoppskilt'),(1121,275,'a','Fare for barn'),(1122,275,'b','Parkering forbudt'),(1123,275,'c','Fartsgrense'),(1124,275,'d','Fotgjengerfelt'),(1125,276,'a','Sving forbudt'),(1126,276,'b','Veiarbeid'),(1127,276,'c','Fotgjengerfelt'),(1128,276,'d','Glatt veibane'),(1129,277,'a','Fare for barn'),(1130,277,'b','Sving forbudt'),(1131,277,'c','Innkjøring forbudt'),(1132,277,'d','Veiarbeid'),(1133,278,'a','Sving forbudt'),(1134,278,'b','Stoppskilt'),(1135,278,'c','Fartsgrense'),(1136,278,'d','Glatt veibane'),(1137,279,'a','Innkjøring forbudt'),(1138,279,'b','Fare for barn'),(1139,279,'c','Vikeplikt'),(1140,279,'d','Glatt veibane'),(1141,280,'a','Fare for barn'),(1142,280,'b','Veiarbeid'),(1143,280,'c','Stoppskilt'),(1144,280,'d','Glatt veibane'),(1145,281,'a','Glatt veibane'),(1146,281,'b','Stoppskilt'),(1147,281,'c','Innkjøring forbudt'),(1148,281,'d','Fartsgrense'),(1149,282,'a','Stoppskilt'),(1150,282,'b','Enveiskjøring'),(1151,282,'c','Fartsgrense'),(1152,282,'d','Vikeplikt'),(1153,283,'a','Veiarbeid'),(1154,283,'b','Parkering forbudt'),(1155,283,'c','Vikeplikt'),(1156,283,'d','Enveiskjøring'),(1157,284,'a','Fare for barn'),(1158,284,'b','Fartsgrense'),(1159,284,'c','Fotgjengerfelt'),(1160,284,'d','Sving forbudt'),(1161,285,'a','Rundkjøring'),(1162,285,'b','Fare for barn'),(1163,285,'c','Innkjøring forbudt'),(1164,285,'d','Fartsgrense'),(1165,286,'a','Glatt veibane'),(1166,286,'b','Vikeplikt'),(1167,286,'c','Veiarbeid'),(1168,286,'d','Sving forbudt'),(1169,287,'a','Innkjøring forbudt'),(1170,287,'b','Enveiskjøring'),(1171,287,'c','Rundkjøring'),(1172,287,'d','Glatt veibane'),(1173,288,'a','Parkering forbudt'),(1174,288,'b','Rundkjøring'),(1175,288,'c','Enveiskjøring'),(1176,288,'d','Glatt veibane'),(1177,289,'a','Innkjøring forbudt'),(1178,289,'b','Fartsgrense'),(1179,289,'c','Stoppskilt'),(1180,289,'d','Sving forbudt'),(1181,290,'a','Stoppskilt'),(1182,290,'b','Vikeplikt'),(1183,290,'c','Fare for barn'),(1184,290,'d','Fartsgrense'),(1185,291,'a','Veiarbeid'),(1186,291,'b','Glatt veibane'),(1187,291,'c','Innkjøring forbudt'),(1188,291,'d','Rundkjøring'),(1189,292,'a','Enveiskjøring'),(1190,292,'b','Sving forbudt'),(1191,292,'c','Rundkjøring'),(1192,292,'d','Veiarbeid'),(1193,293,'a','Parkering forbudt'),(1194,293,'b','Innkjøring forbudt'),(1195,293,'c','Fotgjengerfelt'),(1196,293,'d','Fare for barn'),(1197,294,'a','Fotgjengerfelt'),(1198,294,'b','Sving forbudt'),(1199,294,'c','Enveiskjøring'),(1200,294,'d','Parkering forbudt'),(1201,295,'a','Fare for barn'),(1202,295,'b','Rundkjøring'),(1203,295,'c','Stoppskilt'),(1204,295,'d','Innkjøring forbudt'),(1205,296,'a','Glatt veibane'),(1206,296,'b','Rundkjøring'),(1207,296,'c','Sving forbudt'),(1208,296,'d','Innkjøring forbudt'),(1209,297,'a','Vikeplikt'),(1210,297,'b','Fare for barn'),(1211,297,'c','Veiarbeid'),(1212,297,'d','Rundkjøring'),(1213,298,'a','Parkering forbudt'),(1214,298,'b','Veiarbeid'),(1215,298,'c','Sving forbudt'),(1216,298,'d','Vikeplikt'),(1217,299,'a','Stoppskilt'),(1218,299,'b','Fartsgrense'),(1219,299,'c','Fotgjengerfelt'),(1220,299,'d','Rundkjøring'),(1221,300,'a','Veiarbeid'),(1222,300,'b','Fare for barn'),(1223,300,'c','Fotgjengerfelt'),(1224,300,'d','Innkjøring forbudt'),(1225,301,'a','Innkjøring forbudt'),(1226,301,'b','Rundkjøring'),(1227,301,'c','Sving forbudt'),(1228,301,'d','Stoppskilt'),(1229,302,'a','Vikeplikt'),(1230,302,'b','Glatt veibane'),(1231,302,'c','Fare for barn'),(1232,302,'d','Enveiskjøring'),(1233,303,'a','Enveiskjøring'),(1234,303,'b','Fare for barn'),(1235,303,'c','Vikeplikt'),(1236,303,'d','Parkering forbudt'),(1237,304,'a','Fotgjengerfelt'),(1238,304,'b','Fartsgrense'),(1239,304,'c','Fare for barn'),(1240,304,'d','Vikeplikt'),(1241,305,'a','Vikeplikt'),(1242,305,'b','Stoppskilt'),(1243,305,'c','Fartsgrense'),(1244,305,'d','Glatt veibane'),(1245,306,'a','Vikeplikt'),(1246,306,'b','Innkjøring forbudt'),(1247,306,'c','Fartsgrense'),(1248,306,'d','Enveiskjøring'),(1249,307,'a','Fartsgrense'),(1250,307,'b','Innkjøring forbudt'),(1251,307,'c','Enveiskjøring'),(1252,307,'d','Fare for barn'),(1253,308,'a','Sving forbudt'),(1254,308,'b','Fare for barn'),(1255,308,'c','Fartsgrense'),(1256,308,'d','Glatt veibane'),(1257,309,'a','Glatt veibane'),(1258,309,'b','Fare for barn'),(1259,309,'c','Vikeplikt'),(1260,309,'d','Stoppskilt'),(1261,310,'a','Innkjøring forbudt'),(1262,310,'b','Rundkjøring'),(1263,310,'c','Fartsgrense'),(1264,310,'d','Enveiskjøring'),(1265,311,'a','Glatt veibane'),(1266,311,'b','Innkjøring forbudt'),(1267,311,'c','Stoppskilt'),(1268,311,'d','Enveiskjøring'),(1269,312,'a','Veiarbeid'),(1270,312,'b','Sving forbudt'),(1271,312,'c','Parkering forbudt'),(1272,312,'d','Fare for barn'),(1273,313,'a','Rundkjøring'),(1274,313,'b','Stoppskilt'),(1275,313,'c','Parkering forbudt'),(1276,313,'d','Veiarbeid'),(1277,314,'a','Vikeplikt'),(1278,314,'b','Stoppskilt'),(1279,314,'c','Fare for barn'),(1280,314,'d','Innkjøring forbudt'),(1281,315,'a','Fartsgrense'),(1282,315,'b','Veiarbeid'),(1283,315,'c','Glatt veibane'),(1284,315,'d','Sving forbudt'),(1285,316,'a','Rundkjøring'),(1286,316,'b','Parkering forbudt'),(1287,316,'c','Vikeplikt'),(1288,316,'d','Stoppskilt'),(1289,317,'a','Glatt veibane'),(1290,317,'b','Sving forbudt'),(1291,317,'c','Enveiskjøring'),(1292,317,'d','Stoppskilt'),(1293,318,'a','Rundkjøring'),(1294,318,'b','Veiarbeid'),(1295,318,'c','Stoppskilt'),(1296,318,'d','Vikeplikt'),(1297,319,'a','Enveiskjøring'),(1298,319,'b','Rundkjøring'),(1299,319,'c','Innkjøring forbudt'),(1300,319,'d','Stoppskilt'),(1301,320,'a','Glatt veibane'),(1302,320,'b','Parkering forbudt'),(1303,320,'c','Fartsgrense'),(1304,320,'d','Veiarbeid'),(1305,321,'a','Glatt veibane'),(1306,321,'b','Parkering forbudt'),(1307,321,'c','Fare for barn'),(1308,321,'d','Fotgjengerfelt'),(1309,322,'a','Stoppskilt'),(1310,322,'b','Parkering forbudt'),(1311,322,'c','Fare for barn'),(1312,322,'d','Innkjøring forbudt'),(1313,323,'a','Parkering forbudt'),(1314,323,'b','Sving forbudt'),(1315,323,'c','Veiarbeid'),(1316,323,'d','Rundkjøring'),(1317,324,'a','Sving forbudt'),(1318,324,'b','Parkering forbudt'),(1319,324,'c','Veiarbeid'),(1320,324,'d','Stoppskilt'),(1321,325,'a','Enveiskjøring'),(1322,325,'b','Parkering forbudt'),(1323,325,'c','Innkjøring forbudt'),(1324,325,'d','Fotgjengerfelt'),(1325,326,'a','Veiarbeid'),(1326,326,'b','Stoppskilt'),(1327,326,'c','Glatt veibane'),(1328,326,'d','Innkjøring forbudt'),(1329,327,'a','Stoppskilt'),(1330,327,'b','Rundkjøring'),(1331,327,'c','Veiarbeid'),(1332,327,'d','Vikeplikt'),(1333,328,'a','Fare for barn'),(1334,328,'b','Vikeplikt'),(1335,328,'c','Fartsgrense'),(1336,328,'d','Innkjøring forbudt'),(1337,329,'a','Glatt veibane'),(1338,329,'b','Fare for barn'),(1339,329,'c','Stoppskilt'),(1340,329,'d','Veiarbeid'),(1341,330,'a','Parkering forbudt'),(1342,330,'b','Fartsgrense'),(1343,330,'c','Enveiskjøring'),(1344,330,'d','Glatt veibane'),(1345,331,'a','Parkering forbudt'),(1346,331,'b','Fotgjengerfelt'),(1347,331,'c','Fartsgrense'),(1348,331,'d','Innkjøring forbudt'),(1349,332,'a','Stoppskilt'),(1350,332,'b','Fotgjengerfelt'),(1351,332,'c','Enveiskjøring'),(1352,332,'d','Fare for barn'),(1353,12,'a','Viser vei- og trafikkforhold'),(1354,12,'b','Viser fartsgrensen'),(1355,12,'c','Varsler spesielle regler'),(1356,12,'d','Viser at du kjører inn på motorvei'),(1365,1,'a','Det er påbudt å stoppe'),(1366,1,'b','Kun parkering er forbudt'),(1367,1,'c','Stans er forbudt'),(1368,1,'d','Du har vikeplikt'),(1369,2,'a','0,2 ‰'),(1370,2,'b','0,5 ‰'),(1371,2,'c','0,0 ‰'),(1372,2,'d','0,8 ‰'),(1373,20,'a','Rundkjøring'),(1374,20,'b','Parkering forbudt'),(1375,20,'c','Enveiskjøring'),(1376,20,'d','Innkjøring forbudt'),(1377,18,'a','Enveiskjøring'),(1378,18,'b','Vikeplikt'),(1379,18,'c','Sving forbudt'),(1380,18,'d','Rundkjøring'),(1381,19,'a','Sving forbudt'),(1382,19,'b','Parkering forbudt'),(1383,19,'c','Fartsgrense'),(1384,19,'d','Innkjøring forbudt'),(1385,21,'a','Fartsgrense'),(1386,21,'b','Glatt veibane'),(1387,21,'c','Vikeplikt'),(1388,21,'d','Veiarbeid'),(1389,22,'a','Vikeplikt'),(1390,22,'b','Fare for barn'),(1391,22,'c','Fartsgrense'),(1392,22,'d','Enveiskjøring'),(1393,28,'a','Fotgjengerfelt'),(1394,28,'b','Vikeplikt'),(1395,28,'c','Parkering forbudt'),(1396,28,'d','Enveiskjøring'),(1397,29,'a','Parkering forbudt'),(1398,29,'b','Fotgjengerfelt'),(1399,29,'c','Innkjøring forbudt'),(1400,29,'d','Fare for barn'),(1401,30,'a','Innkjøring forbudt'),(1402,30,'b','Vikeplikt'),(1403,30,'c','Veiarbeid'),(1404,30,'d','Sving forbudt'),(1409,17,'a','Varsler om militær aktivitet i området  '),(1410,17,'b','Viser nærhet til forsvarsmuseum'),(1411,17,'c','Påbud om å stanse ved kontroll'),(1412,17,'d','Informasjonsskilt for kaserne'),(1417,23,'a','En skarp sving til venstre'),(1418,23,'b','Farlige svinger, den første til høyre'),(1419,23,'c','En skarp sving til høyre'),(1420,23,'d','Farlige svinger, den første til venstre');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `subscription_id` int DEFAULT NULL,
  `plan_id` int NOT NULL,
  `amount_nok` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `stripe_payment_intent_id` varchar(255) DEFAULT NULL,
  `stripe_charge_id` varchar(255) DEFAULT NULL,
  `stripe_customer_id` varchar(255) DEFAULT NULL,
  `vipps_transaction_id` varchar(255) DEFAULT NULL,
  `bank_reference` varchar(100) DEFAULT NULL,
  `invoice_number` varchar(50) DEFAULT NULL,
  `invoice_pdf_path` varchar(255) DEFAULT NULL,
  `billing_name` varchar(255) DEFAULT NULL,
  `billing_email` varchar(255) DEFAULT NULL,
  `billing_address` text,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_postal_code` varchar(20) DEFAULT NULL,
  `billing_country` varchar(2) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `failure_reason` text,
  `refund_amount` decimal(10,2) DEFAULT NULL,
  `refund_reason` text,
  `refunded_at` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `metadata_json` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `subscription_id` (`subscription_id`),
  KEY `plan_id` (`plan_id`),
  KEY `idx_stripe_payment_intent` (`stripe_payment_intent_id`),
  KEY `idx_payment_date` (`payment_date`),
  KEY `idx_payment_user_status` (`user_id`,`status`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`subscription_id`) REFERENCES `user_subscriptions` (`id`),
  CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist_items`
--

DROP TABLE IF EXISTS `playlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `playlist_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `playlist_id` int NOT NULL,
  `video_id` int NOT NULL,
  `order_index` int DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_playlist_video_uc` (`playlist_id`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `playlist_items_ibfk_1` FOREIGN KEY (`playlist_id`) REFERENCES `video_playlists` (`id`),
  CONSTRAINT `playlist_items_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist_items`
--

LOCK TABLES `playlist_items` WRITE;
/*!40000 ALTER TABLE `playlist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `playlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `power_ups`
--

DROP TABLE IF EXISTS `power_ups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `power_ups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `icon` varchar(100) DEFAULT NULL,
  `cost_xp` int NOT NULL,
  `effect_type` varchar(50) DEFAULT NULL,
  `effect_duration` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `power_ups`
--

LOCK TABLES `power_ups` WRITE;
/*!40000 ALTER TABLE `power_ups` DISABLE KEYS */;
/*!40000 ALTER TABLE `power_ups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_difficulty_profiles`
--

DROP TABLE IF EXISTS `question_difficulty_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_difficulty_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question_id` int NOT NULL,
  `computed_difficulty` float DEFAULT NULL,
  `discrimination_power` float DEFAULT NULL,
  `guess_factor` float DEFAULT NULL,
  `total_attempts` int DEFAULT NULL,
  `correct_attempts` int DEFAULT NULL,
  `avg_response_time` float DEFAULT NULL,
  `response_time_variance` float DEFAULT NULL,
  `skill_threshold` float DEFAULT NULL,
  `learning_value` float DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`),
  KEY `idx_question_difficulty` (`computed_difficulty`),
  KEY `idx_question_discrimination` (`discrimination_power`),
  CONSTRAINT `question_difficulty_profiles_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_difficulty_profiles`
--

LOCK TABLES `question_difficulty_profiles` WRITE;
/*!40000 ALTER TABLE `question_difficulty_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_difficulty_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_images`
--

DROP TABLE IF EXISTS `question_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_images` (
  `question_id` int NOT NULL,
  `image_id` int NOT NULL,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`question_id`,`image_id`,`role`),
  KEY `image_id` (`image_id`),
  CONSTRAINT `question_images_ibfk_1` FOREIGN KEY (`image_id`) REFERENCES `quiz_images` (`id`),
  CONSTRAINT `question_images_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_images`
--

LOCK TABLES `question_images` WRITE;
/*!40000 ALTER TABLE `question_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_import_temp`
--

DROP TABLE IF EXISTS `question_import_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_import_temp` (
  `question` text,
  `correct_option` char(1) DEFAULT NULL,
  `option_a` text,
  `option_b` text,
  `option_c` text,
  `option_d` text,
  `category` varchar(255) DEFAULT NULL,
  `image_filename` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_import_temp`
--

LOCK TABLES `question_import_temp` WRITE;
/*!40000 ALTER TABLE `question_import_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_import_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `correct_option` varchar(255) NOT NULL,
  `image_filename` varchar(255) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `difficulty_level` int DEFAULT '1',
  `explanation` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `question_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=333 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,'Hva betyr dette trafikkskiltet?','Trafikkskilt','c','sf20051007121937001_gif.gif','Forbudsskilt',1,NULL,NULL,'2025-06-23 01:01:54',1,NULL),(2,'Hva er promillegrensen i Norge for vanlig bilførerkort?','Ukategorisert','a','promille.png','Alkohol',1,NULL,NULL,'2025-06-23 01:02:33',1,NULL),(11,'Hvilken fart er tillatt i boligområder?','Trafikkregler','a','boligstrk_fartsgrense.png','Fartsbegrensning',1,'I boligområder er fartsgrensen som regel 30 km/t med mindre annet er skiltet.','2025-06-20 23:36:14','2025-06-22 21:51:32',1,'multiple_choice'),(12,'Hva betyr dette opplysningsskiltet?','Trafikkskilt','d','sf20051007121976101_gif.gif','Opplysningsskilt',1,'Opplysningsskilt gir viktig informasjon til trafikantene.','2025-06-20 23:36:14','2025-06-23 00:55:45',1,'multiple_choice'),(13,'Hva er riktig oppførsel når du nærmer deg fotgjengerfeltet med fotgjengere som vil krysse?','Trafikkregler','a','overgangsfelt.png','Fotgjengere',2,'Du må alltid gi fotgjengere som krysser eller skal krysse veien forkjørsrett.','2025-06-20 23:36:14','2025-06-22 22:27:03',1,'multiple_choice'),(14,'Hvem har vikeplikt når du nærmer deg en rundkjøring?','Trafikkregler','d','rundkjring_ovenfra.png','Rundkjøring',2,'I rundkjøring har trafikk inne i rundkjøringen alltid forkjørsrett.','2025-06-20 23:36:14','2025-06-22 23:01:53',1,'multiple_choice'),(15,'Hvilken avstand skal du holde til bilen foran?','Trafikkregler','b','to_felt_med_biler.png','Avstand',2,'Følg 3-sekunders regelen - hold en avstand som tilsvarer 3 sekunders kjøring.','2025-06-20 23:36:14','2025-06-22 23:09:34',1,'multiple_choice'),(16,'Test question?','Test','b',NULL,NULL,2,'Test explanation','2025-06-22 19:32:33','2025-06-22 19:32:33',1,'multiple_choice'),(17,'Hva betyr dette skiltet?','Fareskilt','a','fareskilt_militaer_aktivitet.gif','',1,'Dette er et fareskilt som varsler om fare.','2025-06-22 19:32:34','2025-06-23 16:14:46',1,'multiple_choice'),(18,'Hva står dette trafikkskiltet for?','Trafikkskilt','c','sf200510071219330101_gif.gif','',1,NULL,'2025-06-23 00:21:54','2025-06-23 01:19:53',1,'multiple_choice'),(19,'Hvordan skal dette skiltet forstås?','Trafikkskilt','d','sf20051007121930201_gif.gif','',1,NULL,'2025-06-23 00:21:54','2025-06-23 01:20:52',1,'multiple_choice'),(20,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','a','sf20051007121912601_gif.gif','',1,NULL,'2025-06-23 00:21:54','2025-06-23 01:19:10',1,'multiple_choice'),(21,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','b','sf20051007121911601_gif.gif','',1,NULL,'2025-06-23 00:21:54','2025-06-23 01:21:51',1,'multiple_choice'),(22,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','c','sf20051007121936201_gif.gif','',1,NULL,'2025-06-23 00:21:54','2025-06-23 01:22:13',1,'multiple_choice'),(23,'Hva slags instruksjon gir dette trafikkskiltet?','Trafikkskilt','d','sf200510071219102201_gif.gif','',1,NULL,'2025-06-23 00:21:54','2025-06-23 16:24:31',1,'multiple_choice'),(24,'Hva betyr dette trafikkskiltet?','Trafikkskilt','b','sf200510071219402501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(25,'Hvilken informasjon gir dette trafikkskiltet?','Trafikkskilt','c','sf20051007121977301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(26,'Hva representerer dette skiltet?','Trafikkskilt','c','._sf20051007121910801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(27,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','b','._sf20051007121962501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(28,'Hva slags instruksjon gir dette trafikkskiltet?','Trafikkskilt','d','sf200510071219526101_gif.gif','',1,NULL,'2025-06-23 00:21:54','2025-06-23 01:23:38',1,'multiple_choice'),(29,'Hva informerer dette skiltet om?','Trafikkskilt','a','sf20051007121937201_gif.gif','',1,NULL,'2025-06-23 00:21:54','2025-06-23 01:24:12',1,'multiple_choice'),(30,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','b','','',1,NULL,'2025-06-23 00:21:54','2025-06-23 01:24:38',1,'multiple_choice'),(31,'Hva forteller dette trafikkskiltet deg?','Trafikkskilt','a','sf2005100712197921201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(32,'Hva er meningen med dette trafikkskiltet?','Trafikkskilt','d','sf200510071219103401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(33,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','c','sf20051007121983401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(34,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','a','sf2005100712197921501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(35,'Hva slags instruksjon gir dette trafikkskiltet?','Trafikkskilt','c','._sf200510071219102801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(36,'Hva representerer dette skiltet?','Trafikkskilt','b','sf200510071219306001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(37,'Hva representerer dette skiltet?','Trafikkskilt','a','._sf200510071219102201_gif_2.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(38,'Hva står dette trafikkskiltet for?','Trafikkskilt','c','sf200510071219102701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(39,'Hva forteller dette trafikkskiltet deg?','Trafikkskilt','a','sf20051007121975501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(40,'Hva symboliserer dette skiltet i trafikken?','Trafikkskilt','a','sf2005100712196504001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(41,'Hva viser dette trafikkskiltet?','Trafikkskilt','d','._sf20051007121962201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(42,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','d','sf200510071219306101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(43,'Hva viser dette trafikkskiltet?','Trafikkskilt','b','sf200510071219306401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(44,'Hva betyr dette trafikkskiltet?','Trafikkskilt','d','._sf20051007121952101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(45,'Hva står dette trafikkskiltet for?','Trafikkskilt','b','sf20051007121977601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(46,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','d','._sf200510071219100601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(47,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','c','._sf2005100712197236301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(48,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','a','._sf20051007121971101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(49,'Hva betyr dette trafikkskiltet?','Trafikkskilt','a','sf2005100712197923101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(50,'Hva er dette skiltet et tegn på?','Trafikkskilt','d','sf20051007121961601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(51,'Hva betyr dette trafikkskiltet?','Trafikkskilt','a','sf200510071219536101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(52,'Hva indikerer dette trafikkskiltet?','Trafikkskilt','c','._sf200510071219102101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(53,'Hva skal du være oppmerksom på ved dette skiltet?','Trafikkskilt','b','sf20051007121970101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(54,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','b','sf200510071219904v01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(55,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','c','sf20051007121962201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(56,'Hva skal du være oppmerksom på ved dette skiltet?','Trafikkskilt','c','._sf2005100712197234101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(57,'Hva symboliserer dette skiltet i trafikken?','Trafikkskilt','b','sf2005100712196501101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(58,'Hva informerer dette skiltet om?','Trafikkskilt','c','sf20051007121991201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(59,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','b','sf20051007121977101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(60,'Hva skal du være oppmerksom på ved dette skiltet?','Trafikkskilt','b','._sf200510071219146101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(61,'Hva slags advarsel eller informasjon gir dette skiltet?','Trafikkskilt','a','sf20051007121954201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(62,'Hva informerer dette skiltet om?','Trafikkskilt','d','sf200510071219101401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(63,'Hva slags regel gjelder ved dette skiltet?','Trafikkskilt','d','._sf200510071219306501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(64,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','b','sf20051007121991601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(65,'Hva er dette skiltet et tegn på?','Trafikkskilt','b','._sf20051007121915301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(66,'Hva informerer dette skiltet om?','Trafikkskilt','b','._sf200510071219526101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(67,'Hva indikerer dette trafikkskiltet?','Trafikkskilt','b','sf20051007121972501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(68,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','a','._sf20051007121972901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(69,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','a','sf20051007121950601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(70,'Hva viser dette trafikkskiltet?','Trafikkskilt','b','sf200510071219104401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(71,'Hva informerer dette skiltet om?','Trafikkskilt','c','sf20051007121973101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(72,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','a','._sf-20051007-1219-638-01-01.png',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(73,'Hvilken betydning har dette trafikkskiltet?','Trafikkskilt','b','sf-20051007-1219-1041-01-02.png',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(74,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','b','._sf200510071219906vh01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(75,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','d','sf20051007121933201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(76,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','c','sf20051007121975101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(77,'Hva symboliserer dette skiltet i trafikken?','Trafikkskilt','a','._sf20051007121920201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(78,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','c','._sf20051007121913901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(79,'Hva står dette trafikkskiltet for?','Trafikkskilt','a','sf20051007121912001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(80,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','a','._sf200510071219109601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(81,'Hva slags instruksjon gir dette trafikkskiltet?','Trafikkskilt','d','sf20051007121953901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(82,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','b','sf2005100712196502101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(83,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','b','sf200510071219138101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(84,'Hva betyr dette trafikkskiltet?','Trafikkskilt','b','._sf20051007121975301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(85,'Hva slags advarsel eller informasjon gir dette skiltet?','Trafikkskilt','a','._sf20051007121950301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(86,'Hva betyr dette trafikkskiltet?','Trafikkskilt','d','._sf20051007121940801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(87,'Hva skal du være oppmerksom på ved dette skiltet?','Trafikkskilt','d','._sf200510071219109801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(88,'Hvordan skal dette skiltet forstås?','Trafikkskilt','b','._sf2005100712196502001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(89,'Hvordan skal dette skiltet forstås?','Trafikkskilt','c','._sf20051007121972701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(90,'Hva viser dette trafikkskiltet?','Trafikkskilt','b','sf20051007121983101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(91,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','a','._fareskilt_militaer_aktivitet.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(92,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','a','._sf20051007121975101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(93,'Hva informerer dette skiltet om?','Trafikkskilt','a','._sf200510071219106101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(94,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','a','sf20051007121950701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(95,'Hvordan skal dette skiltet forstås?','Trafikkskilt','b','._sf200510071219531101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(96,'Hva viser dette trafikkskiltet?','Trafikkskilt','a','sf200510071219103701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(97,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','a','sf20051007121977201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(98,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','b','sf20051007121911001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(99,'Hvordan skal dette skiltet forstås?','Trafikkskilt','b','sf200510071219813201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(100,'Hva står dette trafikkskiltet for?','Trafikkskilt','a','sf200510071219902h01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(101,'Hva er dette skiltet et tegn på?','Trafikkskilt','c','sf200510071219807701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(102,'Hva slags regel gjelder ved dette skiltet?','Trafikkskilt','a','sf200510071219402101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(103,'Hvilken betydning har dette trafikkskiltet?','Trafikkskilt','a','._sf200510071219100801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(104,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','b','._sf-20051007-1219-377-01_gif.png',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(105,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','d','sf20051007121981701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(106,'Hva betyr dette trafikkskiltet?','Trafikkskilt','a','sf200510071219527101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(107,'Hva informerer dette skiltet om?','Trafikkskilt','c','sf2005100712191082201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(108,'Hva signaliserer dette skiltet?','Trafikkskilt','c','._sf200510071219103701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(109,'Hva representerer dette skiltet?','Trafikkskilt','c','._sf20051007121971701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(110,'Hva er meningen med dette trafikkskiltet?','Trafikkskilt','c','sf200510071219102101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(111,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','a','sf-20051007-1219-380-01_PNG.png',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(112,'Hva symboliserer dette skiltet i trafikken?','Trafikkskilt','b','sf200510071219906vh01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(113,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','b','sf200510071219136201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(114,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','c','sf2005100712197236101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(115,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','b','._sf200510071219807801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(116,'Hvilken betydning har dette trafikkskiltet?','Trafikkskilt','a','._sf20051007121931001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(117,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','b','._sf20051007121990801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(118,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','c','sf20051007121952401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(119,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','c','sf200510071219526101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(120,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','c','._sf200510071219527401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(121,'Hva slags advarsel eller informasjon gir dette skiltet?','Trafikkskilt','d','sf20051007121911401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(122,'Hva signaliserer dette skiltet?','Trafikkskilt','d','sf200510071219108601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(123,'Hva informerer dette skiltet om?','Trafikkskilt','b','._sf20051007121913201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(124,'Hva slags advarsel eller informasjon gir dette skiltet?','Trafikkskilt','c','sf200510071219376101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(125,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','d','._sf20051007121933401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(126,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','d','sf20051007121977401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(127,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','d','sf2005100712195702h01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(128,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','b','._sf20051007121956501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(129,'Hva forteller dette trafikkskiltet deg?','Trafikkskilt','d','sf2005100712191050201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(130,'Hva forteller dette trafikkskiltet deg?','Trafikkskilt','d','sf2005100712197231101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(131,'Hva skal du være oppmerksom på ved dette skiltet?','Trafikkskilt','c','sf200510071219104201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(132,'Hva betyr dette trafikkskiltet?','Trafikkskilt','a','._sf20051007121915601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(133,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','a','._sf20051007121952001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(134,'Hva symboliserer dette skiltet i trafikken?','Trafikkskilt','c','._sf20051007121950501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(135,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','a','._sf200510071219318201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(136,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','b','._sf20051007121914201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(137,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','c','sf20051007121976701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(138,'Hva signaliserer dette skiltet?','Trafikkskilt','a','sf20051007121921001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(139,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','a','._sf200510071219105201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(140,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','c','._sf20051007121960801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(141,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','b','sf-20051007-1219-382-01_PNG.png',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(142,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','d','sf2005100712197231601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(143,'Hva signaliserer dette skiltet?','Trafikkskilt','d','._sf20051007121974301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(144,'Hva står dette trafikkskiltet for?','Trafikkskilt','b','sf20051007121910801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(145,'Hva symboliserer dette skiltet i trafikken?','Trafikkskilt','c','sf20051007121994001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(146,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','d','._sf2005100712197921501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(147,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','a','._sf20051007121970701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(148,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','b','sf20051007121971301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(149,'Hva er dette skiltet et tegn på?','Trafikkskilt','d','sf200510071219807601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(150,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','b','sf20051007121913401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(151,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','a','._sf200510071219109001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(152,'Hva betyr dette trafikkskiltet?','Trafikkskilt','b','sf200510071219102601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(153,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','a','._sf20051007121921201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(154,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','a','sf200510071219536201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(155,'Hva representerer dette skiltet?','Trafikkskilt','a','sf20051007121951301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(156,'Hva skal du være oppmerksom på ved dette skiltet?','Trafikkskilt','c','sf2005100712197237101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(157,'Hva skal du tolke ut fra dette skiltet?','Trafikkskilt','d','sf20051007121961201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(158,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','d','sf200510071219102201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(159,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','d','._sf20051007121982601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(160,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','b','sf20051007121915501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(161,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','c','sf200510071219807801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(162,'Hva betyr dette trafikkskiltet?','Trafikkskilt','b','._sf20051007121936201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(163,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','c','._sf20051007121954201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(164,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','b','._sf20051007121962101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(165,'Hva er dette skiltet et tegn på?','Trafikkskilt','a','sf2005100712197921101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(166,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','b','._sf20051007121911801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(167,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','c','._sf20051007121961601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(168,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','a','sf200510071219306701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(169,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','b','._sf200510071219102601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(170,'Hva står dette trafikkskiltet for?','Trafikkskilt','c','._sf200510071219146301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(171,'Hvilken informasjon gir dette trafikkskiltet?','Trafikkskilt','b','._sf2005100712197231301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(172,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','c','sf200510071219102001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(173,'Hvilken betydning har dette trafikkskiltet?','Trafikkskilt','d','._sf20051007121963701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(174,'Hva skal du tolke ut fra dette skiltet?','Trafikkskilt','a','._sf200510071219103401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(175,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','d','._sf2005100712195702h01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(176,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','d','._sf20051007121981001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(177,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','c','sf20051007121972901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(178,'Hvilken betydning har dette trafikkskiltet?','Trafikkskilt','b','._sf200510071219103601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(179,'Hva representerer dette skiltet?','Trafikkskilt','a','sf200510071219521201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(180,'Hva viser dette trafikkskiltet?','Trafikkskilt','c','._sf20051007121976501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(181,'Hva slags advarsel eller informasjon gir dette skiltet?','Trafikkskilt','a','sf20051007121933401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(182,'Hva informerer dette skiltet om?','Trafikkskilt','a','._sf20051007121950901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(183,'Hva er meningen med dette trafikkskiltet?','Trafikkskilt','c','sf200510071219108802_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(184,'Hva er dette skiltet et tegn på?','Trafikkskilt','a','sf20051007121981001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(185,'Hva slags advarsel eller informasjon gir dette skiltet?','Trafikkskilt','d','._sf20051007121952401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(186,'Hvordan skal dette skiltet forstås?','Trafikkskilt','d','sf200510071219101001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(187,'Hva er dette skiltet et tegn på?','Trafikkskilt','a','._sf20051007121921001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(188,'Hva slags advarsel eller informasjon gir dette skiltet?','Trafikkskilt','c','._sf20051007121991201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(189,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','b','sf20051007121970501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(190,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','d','sf200510071219138201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(191,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','c','._sf20051007121951801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(192,'Hvilken informasjon gir dette trafikkskiltet?','Trafikkskilt','b','sf20051007121962101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(193,'Hvilken informasjon gir dette trafikkskiltet?','Trafikkskilt','b','sf200510071219106201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(194,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','d','._sf200510071219318101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(195,'Hvordan skal dette skiltet forstås?','Trafikkskilt','d','._vegoppmerkingsskilt_som_viser_75_tonn__grafikk.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(196,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','a','sf200510071219105401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(197,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','c','sf20051007121915001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(198,'Hva er meningen med dette trafikkskiltet?','Trafikkskilt','c','._sf2005100712197901001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(199,'Hva slags instruksjon gir dette trafikkskiltet?','Trafikkskilt','d','._sf20051007121973101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(200,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','a','sf20051007121911201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(201,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','c','._sf2005100712197902001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(202,'Hvilken informasjon gir dette trafikkskiltet?','Trafikkskilt','d','sf20051007121930801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(203,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','a','._sf-20051007-1219-379-01_png.png',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(204,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','c','._sf200510071219138201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(205,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','c','sf2005100712197231301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(206,'Hva skal du tolke ut fra dette skiltet?','Trafikkskilt','c','._sf2005100712197237301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(207,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','d','._sf2005100712197231201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(208,'Hva signaliserer dette skiltet?','Trafikkskilt','a','sf20051007121951101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(209,'Hva representerer dette skiltet?','Trafikkskilt','a','._sf20051007121974101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(210,'Hvordan skal dette skiltet forstås?','Trafikkskilt','d','._sf200510071219508201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(211,'Hva representerer dette skiltet?','Trafikkskilt','a','sf20051007121931601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:54','2025-06-23 00:21:54',1,'multiple_choice'),(212,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','b','sf200510071219530b01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(213,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','b','sf200510071219556101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(214,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','c','._sf200510071219920h01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(215,'Hva skal du tolke ut fra dette skiltet?','Trafikkskilt','d','._sf200510071219100201_gif_2.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(216,'Hvordan skal dette skiltet forstås?','Trafikkskilt','b','sf20051007121932401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(217,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','c','._sf2005100712197923001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(218,'Hva er dette skiltet et tegn på?','Trafikkskilt','c','._sf200510071219306601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(219,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','b','sf200510071219100801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(220,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','a','sf200510071219531201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(221,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','b','._sf20051007121981601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(222,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','a','sf200510071219526201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(223,'Hva representerer dette skiltet?','Trafikkskilt','c','._sf200510071219106301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(224,'Hvordan skal dette skiltet forstås?','Trafikkskilt','a','._sf200510071219536201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(225,'Hva står dette trafikkskiltet for?','Trafikkskilt','d','._sf20051007121956001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(226,'Hvilken betydning har dette trafikkskiltet?','Trafikkskilt','c','._sf2005100712196401001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(227,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','b','sf200510071219404101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(228,'Hva representerer dette skiltet?','Trafikkskilt','a','sf20051007121932601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(229,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','c','._sf20051007121974901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(230,'Hva signaliserer dette skiltet?','Trafikkskilt','c','._sf20051007121960501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(231,'Hva informerer dette skiltet om?','Trafikkskilt','b','._sf20051007121981201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(232,'Hvordan skal dette skiltet forstås?','Trafikkskilt','a','sf200510071219100201_gif_2.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(233,'Hva er dette skiltet et tegn på?','Trafikkskilt','c','sf200510071219318101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(234,'Hva viser dette trafikkskiltet?','Trafikkskilt','c','._sf200510071219330101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(235,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','d','sf20051007121956501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(236,'Hva skal du tolke ut fra dette skiltet?','Trafikkskilt','b','._sf20051007121961801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(237,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','c','sf200510071219102801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(238,'Hva er dette skiltet et tegn på?','Trafikkskilt','d','sf2005100712197921301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(239,'Hva signaliserer dette skiltet?','Trafikkskilt','a','._sf20051007121970101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(240,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','c','._sf2005100712197921201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(241,'Hva forteller dette trafikkskiltet deg?','Trafikkskilt','c','sf2005100712197234101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(242,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','d','sf20051007121977501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(243,'Hva informerer dette skiltet om?','Trafikkskilt','c','._sf20051007121931401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(244,'Hvilken informasjon gir dette trafikkskiltet?','Trafikkskilt','d','sf200510071219920vm01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(245,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','a','sf20051007121920601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(246,'Hva varsler dette trafikkskiltet om?','Trafikkskilt','c','._sf2005100712196502101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(247,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','d','sf20051007121920801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(248,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','c','sf2005100712197235101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(249,'Hva representerer dette skiltet?','Trafikkskilt','c','sf200510071219376201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(250,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','a','sf200510071219510101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(251,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','b','sf20051007121960501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(252,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','c','sf20051007121974901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(253,'Hva indikerer dette trafikkskiltet?','Trafikkskilt','b','._sf20051007121930801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(254,'Hva skal du være oppmerksom på ved dette skiltet?','Trafikkskilt','a','sf20051007121914901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(255,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','b','sf20051007121971501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(256,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','c','._sf2005100712197232101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(257,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','c','._sf200510071219510201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(258,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','c','sf200510071219100101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(259,'Hva betyr dette trafikkskiltet?','Trafikkskilt','d','._sf200510071219103901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(260,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','d','._sf200510071219306401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(261,'Hva betyr dette trafikkskiltet?','Trafikkskilt','a','._sf20051007121980201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(262,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','a','sf20051007121933701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(263,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','a','._sf200510071219306101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(264,'Hva informerer dette skiltet om?','Trafikkskilt','c','sf2005100712195701h01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(265,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','b','sf200510071219106301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(266,'Hva representerer dette skiltet?','Trafikkskilt','b','._sf2005100712197232201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(267,'Hva representerer dette skiltet?','Trafikkskilt','a','._sf20051007121953901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(268,'Hvordan skal dette skiltet forstås?','Trafikkskilt','a','._sf20051007121913401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(269,'Hva informerer dette skiltet om?','Trafikkskilt','c','sf200510071219613201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(270,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','b','sf20051007121951801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(271,'Hva skal du være oppmerksom på ved dette skiltet?','Trafikkskilt','c','sf20051007121954001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(272,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','c','sf20051007121980601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(273,'Hvilken informasjon gir dette trafikkskiltet?','Trafikkskilt','a','._sf2005100712197236201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(274,'Hvilken betydning har dette trafikkskiltet?','Trafikkskilt','d','._sf2005100712197921101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(275,'Hva informerer dette skiltet om?','Trafikkskilt','d','._sf20051007121913501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(276,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','a','._sf20051007121950601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(277,'Hva symboliserer dette skiltet i trafikken?','Trafikkskilt','d','sf200510071219531101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(278,'Hva er meningen med dette trafikkskiltet?','Trafikkskilt','d','sf200510071219402701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(279,'Hva slags trafikksituasjon beskriver dette skiltet?','Trafikkskilt','c','._sf200510071219402201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(280,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','d','._sf200510071219531201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(281,'Hva skal du tolke ut fra dette skiltet?','Trafikkskilt','b','sf200510071219556201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(282,'Hva forteller dette trafikkskiltet deg?','Trafikkskilt','b','._sf200510071219902h01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(283,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','c','sf20051007121961801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(284,'Hva informerer dette skiltet om?','Trafikkskilt','b','._sf20051007121983401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(285,'Hva står dette trafikkskiltet for?','Trafikkskilt','c','sf20051007121980401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(286,'Hva representerer dette skiltet?','Trafikkskilt','d','._sf200510071219402701_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(287,'Hva viser dette trafikkskiltet?','Trafikkskilt','d','sf200510071219828101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(288,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','c','._sf20051007121920801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(289,'Hva indikerer dette trafikkskiltet?','Trafikkskilt','d','._sf200510071219807501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(290,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','d','sf20051007121910901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(291,'Hva skal du tolke ut fra dette skiltet?','Trafikkskilt','b','._sf200510071219108802_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(292,'Hva er budskapet i dette trafikkskiltet?','Trafikkskilt','b','sf200510071219807201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(293,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','a','._sf20051007121936801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(294,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','a','._sf2005100712197231101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(295,'Hva symboliserer dette skiltet i trafikken?','Trafikkskilt','b','._sf2005100712196504001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(296,'Hva symboliserer dette skiltet i trafikken?','Trafikkskilt','d','sf20051007121950301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(297,'Hva slags instruksjon gir dette trafikkskiltet?','Trafikkskilt','c','sf200510071219807501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(298,'Hva indikerer dette trafikkskiltet?','Trafikkskilt','c','._sf200510071219534b01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(299,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','c','._sf200510071219108402_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(300,'Hva er meningen med dette trafikkskiltet?','Trafikkskilt','d','._sf-20051007-1219-380-01_PNG.png',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(301,'Hva informerer dette skiltet om?','Trafikkskilt','a','._sf20051007121915001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(302,'Hva informerer dette skiltet om?','Trafikkskilt','b','._sf20051007121954801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(303,'Hvilken informasjon gir dette trafikkskiltet?','Trafikkskilt','c','sf20051007121951201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(304,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','d','._sf20051007121940601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(305,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','a','._sf200510071219807301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(306,'Hva viser dette trafikkskiltet?','Trafikkskilt','c','._sf20051007121937001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(307,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','c','sf2005100712197231401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(308,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','c','._sf20051007121933501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(309,'Hva slags plikt eller rettighet viser dette skiltet?','Trafikkskilt','d','._sf200510071219106201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(310,'Hva slags advarsel eller informasjon gir dette skiltet?','Trafikkskilt','d','._sf200510071219306901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(311,'Hvordan skal dette skiltet forstås?','Trafikkskilt','c','sf20051007121982201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(312,'Hva slags regel gjelder ved dette skiltet?','Trafikkskilt','d','._sf20051007121983101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(313,'Hva forteller dette trafikkskiltet deg?','Trafikkskilt','b','._sf20051007121977301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(314,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','d','sf200510071219906v01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(315,'Hva innebærer dette trafikkskiltet?','Trafikkskilt','a','._sf200510071219105001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(316,'Hva skal dette skiltet fortelle deg?','Trafikkskilt','a','sf20051007121960801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(317,'Hvordan skal dette skiltet forstås?','Trafikkskilt','a','._sf200510071219536101_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(318,'Hva slags instruksjon gir dette trafikkskiltet?','Trafikkskilt','d','._sf200510071219914v01_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(319,'Hva signaliserer dette skiltet?','Trafikkskilt','b','._sf200510071219402401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(320,'Hva forteller dette trafikkskiltet deg?','Trafikkskilt','d','._sf20051007121914801_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(321,'Hva representerer dette skiltet?','Trafikkskilt','c','sf20051007121912201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(322,'Hva slags instruksjon gir dette trafikkskiltet?','Trafikkskilt','d','sf20051007121920401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(323,'Hva skal du gjøre når du ser dette skiltet?','Trafikkskilt','b','._sf20051007121977501_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(324,'Hvilken informasjon gir dette trafikkskiltet?','Trafikkskilt','b','sf-20051007-1219-379-01_png.png',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(325,'Hva informerer dette skiltet om?','Trafikkskilt','c','._sf20051007121921401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(326,'Hvordan påvirker dette skiltet kjøringen din?','Trafikkskilt','a','._sf20051007121914001_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(327,'Hva slags regel gjelder ved dette skiltet?','Trafikkskilt','b','sf200510071219101201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(328,'Hva slags beskjed gir dette skiltet?','Trafikkskilt','d','sf20051007121971901_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(329,'Hvilket budskap gir dette skiltet i trafikken?','Trafikkskilt','d','sf20051007121952201_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(330,'Hva slags handling tilsier dette skiltet?','Trafikkskilt','b','._sf20051007121912601_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(331,'Hva er meningen med dette trafikkskiltet?','Trafikkskilt','a','sf20051007121982401_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice'),(332,'Hva slags advarsel eller informasjon gir dette skiltet?','Trafikkskilt','a','sf2005100712197237301_gif.gif',NULL,1,NULL,'2025-06-23 00:21:55','2025-06-23 00:21:55',1,'multiple_choice');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_images`
--

DROP TABLE IF EXISTS `quiz_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `folder` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `uploader_id` int DEFAULT NULL,
  `tags` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_images`
--

LOCK TABLES `quiz_images` WRITE;
/*!40000 ALTER TABLE `quiz_images` DISABLE KEYS */;
INSERT INTO `quiz_images` VALUES (1,'promille.png','quiz','promille',NULL,'2025-06-10 21:41:01',NULL,NULL),(2,'promille.png','quiz','promille',NULL,'2025-06-10 21:43:19',NULL,NULL),(3,'promille.png','quiz','promille',NULL,'2025-06-10 21:47:03',NULL,NULL),(4,'boligstrk_fartsgrense.png','quiz','Boligstrøk fartsgrense',NULL,'2025-06-22 21:48:15',NULL,NULL),(5,'overgangsfelt.png','quiz','Overgangsfelt',NULL,'2025-06-22 22:20:22',NULL,NULL),(6,'rundkjring_ovenfra.png','quiz','Rundkjøring ovenfra',NULL,'2025-06-22 23:01:43',NULL,NULL),(7,'to_felt_med_biler.png','quiz','to felt med biler',NULL,'2025-06-22 23:09:24',NULL,NULL);
/*!40000 ALTER TABLE `quiz_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_responses`
--

DROP TABLE IF EXISTS `quiz_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_responses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` int NOT NULL,
  `question_id` int NOT NULL,
  `user_answer` varchar(1) DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT NULL,
  `time_spent_seconds` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `quiz_responses_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `quiz_sessions` (`id`),
  CONSTRAINT `quiz_responses_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_responses`
--

LOCK TABLES `quiz_responses` WRITE;
/*!40000 ALTER TABLE `quiz_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_sessions`
--

DROP TABLE IF EXISTS `quiz_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `quiz_type` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `total_questions` int DEFAULT NULL,
  `correct_answers` int DEFAULT NULL,
  `time_spent_seconds` int DEFAULT NULL,
  `score` decimal(5,2) DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `quiz_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_sessions`
--

LOCK TABLES `quiz_sessions` WRITE;
/*!40000 ALTER TABLE `quiz_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refund_requests`
--

DROP TABLE IF EXISTS `refund_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refund_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_id` int NOT NULL,
  `user_id` int NOT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `description` text,
  `requested_amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `admin_notes` text,
  `processed_by_user_id` int DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `stripe_refund_id` varchar(255) DEFAULT NULL,
  `actual_refund_amount` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `user_id` (`user_id`),
  KEY `processed_by_user_id` (`processed_by_user_id`),
  CONSTRAINT `refund_requests_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `refund_requests_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `refund_requests_ibfk_3` FOREIGN KEY (`processed_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refund_requests`
--

LOCK TABLES `refund_requests` WRITE;
/*!40000 ALTER TABLE `refund_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `refund_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streak_rewards`
--

DROP TABLE IF EXISTS `streak_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `streak_rewards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `streak_days` int NOT NULL,
  `reward_name` varchar(100) NOT NULL,
  `xp_bonus` int DEFAULT NULL,
  `badge_id` int DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `streak_days` (`streak_days`),
  KEY `badge_id` (`badge_id`),
  CONSTRAINT `streak_rewards_ibfk_1` FOREIGN KEY (`badge_id`) REFERENCES `achievements` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streak_rewards`
--

LOCK TABLES `streak_rewards` WRITE;
/*!40000 ALTER TABLE `streak_rewards` DISABLE KEYS */;
/*!40000 ALTER TABLE `streak_rewards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plans`
--

DROP TABLE IF EXISTS `subscription_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `price_nok` decimal(10,2) NOT NULL DEFAULT '0.00',
  `billing_cycle` enum('monthly','yearly') NOT NULL DEFAULT 'monthly',
  `description` text,
  `features_json` text,
  `max_daily_quizzes` int DEFAULT NULL,
  `max_weekly_exams` int DEFAULT NULL,
  `has_ads` tinyint(1) NOT NULL DEFAULT '1',
  `has_detailed_stats` tinyint(1) NOT NULL DEFAULT '0',
  `has_ai_adaptive` tinyint(1) NOT NULL DEFAULT '0',
  `has_offline_mode` tinyint(1) NOT NULL DEFAULT '0',
  `has_personal_tutor` tinyint(1) NOT NULL DEFAULT '0',
  `has_video_access` tinyint(1) NOT NULL DEFAULT '0',
  `priority_support` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plans`
--

LOCK TABLES `subscription_plans` WRITE;
/*!40000 ALTER TABLE `subscription_plans` DISABLE KEYS */;
INSERT INTO `subscription_plans` VALUES (1,'free','Gratis Plan',0.00,'monthly','Gratis tilgang med begrensninger','[\"Grunnleggende quiz\", \"2 prøveeksamener per uke\", \"Grunnleggende statistikk\"]',5,2,1,0,0,0,0,0,0,1,'2025-06-20 22:34:01'),(2,'premium','Premium Plan',149.00,'monthly','Ubegrenset tilgang uten reklame','[\"Ubegrensede quiz\", \"Videoer\", \"Detaljert statistikk\", \"AI-tilpasset læring\"]',NULL,NULL,0,1,1,0,0,1,0,1,'2025-06-20 22:34:01'),(3,'pro','Pro Plan',249.00,'monthly','Alt i Premium plus offline og personlig tutor','[\"Alt i Premium\", \"Offline modus\", \"Personlig tutor\", \"Prioritert support\"]',NULL,NULL,0,1,1,1,1,1,1,1,'2025-06-20 22:34:01');
/*!40000 ALTER TABLE `subscription_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tournament_participants`
--

DROP TABLE IF EXISTS `tournament_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tournament_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `tournament_id` int NOT NULL,
  `score` int DEFAULT NULL,
  `rank` int DEFAULT NULL,
  `joined_at` datetime DEFAULT NULL,
  `last_participation` datetime DEFAULT NULL,
  `prize_earned` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_tournament_uc` (`user_id`,`tournament_id`),
  KEY `tournament_id` (`tournament_id`),
  CONSTRAINT `tournament_participants_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tournament_participants_ibfk_2` FOREIGN KEY (`tournament_id`) REFERENCES `weekly_tournaments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tournament_participants`
--

LOCK TABLES `tournament_participants` WRITE;
/*!40000 ALTER TABLE `tournament_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `tournament_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `traffic_signs`
--

DROP TABLE IF EXISTS `traffic_signs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `traffic_signs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sign_code` varchar(255) DEFAULT NULL,
  `description` text,
  `category` varchar(50) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `explanation` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `traffic_signs`
--

LOCK TABLES `traffic_signs` WRITE;
/*!40000 ALTER TABLE `traffic_signs` DISABLE KEYS */;
INSERT INTO `traffic_signs` VALUES (1,'151','Militer aktivitet','fare','fareskilt_militaer_aktivitet.gif','Dette skiltet varsler om at det kan foregå militær øvelse eller aktivitet i området. Vær forberedt på militære kjøretøy, soldater eller uventet aktivitet på veien.'),(2,'100.1','Farlig Sving Høyre','fare','sf200510071219100101_gif.gif','Varselet betyr at det kommer en skarp sving mot høyre. Senk farten og vær oppmerksom på veigrepet.'),(3,'100.2','Farlig Sving Venstre','fare','sf200510071219100201_gif.gif','Varselet betyr at det kommer en skarp sving mot Venstre. Senk farten og vær oppmerksom på veigrepet.'),(4,'102.1','Farlige Svinger Høgre','fare','sf200510071219102101_gif.gif','Her er det flere svinger etter hverandre, den første mot høyre. Konstruksjonen av veien kan være krevende, og du må ha lav fart og god kontroll.'),(5,'102.2','Farlige Svinger Venstre','fare','sf200510071219102201_gif.gif','Flere svinger i rekkefølge, med første mot venstre. Reduser farten og vær forberedt på uoversiktlige partier.'),(6,'104.1','Bratt Bakke Opp','fare','sf200510071219104101_gif.gif','Skiltet viser at det kommer en bratt stigning. Biler med svak motor må kanskje gå i lavt gir. Vær også oppmerksom på biler foran som kan miste fart.'),(7,'104.2','Bratt Bakke Ned','fare','sf200510071219104201_gif.gif','Skiltet varsler om en bratt nedoverbakke – vær forberedt på økt bremselengde.'),(8,'106.1','Smalere Veg Begge','fare','sf200510071219106101_gif.gif','Kjørebane blir smalere på begge sider – møtende trafikk må tas hensyn til.'),(9,'106.2','Smalere Veg Fra Høgre','fare','sf200510071219106201_gif.gif','Kjørebane blir smalere fra høyre side. Vær oppmerksom på møtende trafikk.'),(10,'106.3','Smalere Veg Fra Venstre','fare','sf200510071219106301_gif.gif','Kjørebane blir smalere fra venstre side. Vær forberedt på mindre plass.'),(11,'108','Ujevn Veg','fare','sf20051007121910801_gif.gif','Veibanen har ujevnheter som hull eller dumper. Kjør forsiktig.'),(12,'109','Fartshump','fare','sf20051007121910901_gif.gif','Skiltet varsler om fartshump – reduser hastigheten.'),(13,'110','Vegarbeid','fare','sf20051007121911001_gif.gif','Det pågår arbeid i eller nær veibanen – vis særlig aktsomhet.'),(14,'112','Steinsprut','fare','sf20051007121911201_gif.gif','Fare for steinsprut, ofte på grunn av løst dekke eller fjell.'),(15,'114','Rasfare','fare','sf20051007121911401_gif.gif','Område med fare for stein- eller jordras – vær ekstra varsom.'),(16,'116','Glatt Kjørebane','fare','sf20051007121911601_gif.gif','Fare for glatt kjørebane – kan skyldes is, olje eller annet underlag.'),(17,'117','Farlig Vegskulder','fare','sf20051007121911701_gif.gif','Skulderen på veien er svak eller lav – risiko ved utforkjøring eller møting.'),(18,'118','Bevegelig Bru','fare','sf20051007121911801_gif.gif','Varsler om bru som kan åpnes/løftes – stans og vent kan være nødvendig.'),(19,'120','Kai, Strand, Ferjeleie','fare','sf20051007121912001_gif.gif','Fare for å kjøre i vannet – området leder mot kai, strand eller ferje.'),(20,'122','Tunnel','fare','sf20051007121912201_gif.gif','Inngang til tunnel – vær oppmerksom på lysforhold og nødutganger.'),(21,'124','Farlig Vegkryss','fare','sf20051007121912401_gif.gif','Kryss med nedsatt sikt eller høy ulykkesrisiko – reduser farten.'),(22,'126','Rundkjøring','fare','sf20051007121912601_gif.gif','Du nærmer deg en rundkjøring – gi tegn og vikeplikt ved innkjøring.'),(23,'132','Trafikklyssignal','fare','sf20051007121913201_gif.gif','Kryss eller punkt regulert med trafikklys – vær klar for stans.'),(24,'134','Planovergang Med Bom','fare','sf20051007121913401_gif.gif','Jernbaneovergang med bom – stans ved rødt lys eller lukket bom.'),(25,'135','Planovergang Uten Bom','fare','sf20051007121913501_gif.gif','Jernbaneovergang uten bom – ekstra oppmerksomhet nødvendig.'),(26,'136.1','Avstandsskilt 300 meter','fare','sf200510071219136101_gif.gif','Skiltet varsler at det kommer et farlig punkt om 300 meter.'),(27,'136.2','Avstandsskilt 200 meter','fare','sf200510071219136201_gif.gif','Farlig punkt kommer om 200 meter – forberede deg på handling.'),(28,'136.3','Avstandsskilt 100 meter','fare','sf200510071219136301_gif.gif','Farlig punkt kommer om 100 meter – vær oppmerksom.'),(29,'138.1','Jernbarnespor Enkeltsporet','fare','sf200510071219138101_gif.gif','Enkelt jernbanespor krysser veien – stans ved behov.'),(30,'138.2','Jernbarnespor Flersporet','fare','sf200510071219138201_gif.gif','Flere jernbanespor krysser veien – vær ekstra oppmerksom.'),(31,'139','Sporvogn','fare','sf20051007121913901_gif.gif','Vei krysset eller delt med sporvogn – fare for kryssende trafikk.'),(32,'140','Avstand Til Gangfelt','fare','sf20051007121914001_gif.gif','Gangfelt nærmer seg – vis hensyn til fotgjengere.'),(33,'142','Barn','fare','sf20051007121914201_gif.gif','Barn kan komme plutselig ut i veien – typisk nær skole eller lekeområde.'),(34,'144','Syklende','fare','sf20051007121914401_gif.gif','Syklister i området – vær varsom ved forbikjøring.'),(35,'146.1','Elg','fare','sf200510071219146101_gif.gif','Fareskilt som varsler om elgfare – vanlig i skogsområder. Reduser farten og vær oppmerksom, spesielt ved skumring.'),(36,'146.2','Rein','fare','sf200510071219146201_gif.gif','Fareskilt for rein – ofte brukt på fjellet eller i nordlige strøk. Reinen går ofte i flokker.'),(37,'146.3','Hjort','fare','sf200510071219146301_gif.gif','Varsler om fare for hjortekollisjoner. Hjorten kan komme løpende brått ut fra skog eller skråning.'),(38,'146.4','Ku','fare','sf200510071219146401_gif.gif','Fare for at kyr kan være på eller ved veien – vanlig nær beitemark.'),(39,'146.5','sauer og Lam','fare','sf200510071219146501_gif.gif','Fare for lam og sau i veibanen – kjør forsiktig.'),(40,'148','Møtende Trafikk','fare','sf20051007121914801_gif.gif','Fareskilt for sau – typisk brukt i fjellområder eller beiteområder med løsdrift.'),(41,'149','Ko','fare','sf20051007121914901_gif.gif','Varsler om fare for stillestående eller saktegående trafikk – typisk ved stor trafikkmengde, rushtid eller ulykker.'),(42,'150','Fly','fare','sf20051007121915001_gif.gif','Lavtgående fly i området – særlig ved rullebaner nær veien.'),(43,'152','Sidevind','fare','sf20051007121915201_gif.gif','Fare for sterk sidevind – risiko for å miste kontroll over kjøretøyet.'),(44,'153','Trafikkulykke','fare','sf20051007121915301_gif.gif','Utsatt punkt for trafikkulykker – vær ekstra aktpågivende.'),(45,'154','Skiløpere','fare','sf20051007121915401_gif.gif','Kryssende skiløype – reduser farten og se etter skiløpere.'),(46,'155','Ridende','fare','sf20051007121915501_gif.gif','Kryssende ridesti – fare for hest og rytter i eller ved veien.'),(47,'156','Annen fare','fare','sf20051007121915601_gif.gif','Skiltet brukes når faren ikke dekkes av andre fareskilt – se etter supplerende informasjon.'),(48,'302','Innkjoring Forbudt','forbuds','sf20051007121930201_gif.gif','Det er ikke tillatt å kjøre inn i veien fra denne retningen.'),(49,'306.0','Forbudt for alle kjoretoy','forbuds','sf200510071219306001_gif.gif','Gjelder alle typer kjøretøy – ingen motorisert eller ikke-motorisert trafikk.'),(50,'306.1','Forbudt for motorvogn med unntak av liten elektrisk motorvogn','forbuds','sf200510071219306101_gif.gif','Forbud mot motorvogn, men små elektriske kjøretøy som el-sparkesykkel kan være unntatt.'),(51,'306.3','Forbudt for alle traktorer og for motorredskap konstruert for fart mindre enn 40 km/t.','forbuds','sf200510071219306301_gif.gif','Traktorer og motorredskap som anleggsmaskiner har ikke tillatelse.'),(52,'306.4','Forbudt for motorsykkel og moped','forbuds','sf200510071219306401_gif.gif','Gjelder tohjuls- eller trehjuls motoriserte kjøretøy.'),(53,'306.5','Forbudt for lastebil og trekkbil','forbuds','sf200510071219306501_gif.gif','Lastebiler og trekkbiler har ikke adgang.'),(54,'306.6','Forbudt for syklende og forer av liten elektrisk motorvogn','forbuds','sf200510071219306601_gif.gif','Gjelder syklister og små elektriske kjøretøy som el-sparkesykkel.'),(55,'306.7','Forbudt for gaende','forbuds','sf200510071219306701_gif.gif','Fotgjengere har ikke adgang.'),(56,'306.8','Forbudt for gaende, syklende og fører av liten elektrisk motorvogn','forbuds','sf200510071219306801_gif.gif','Totalforbud for disse trafikantgruppene – ofte brukt i tunneler.'),(57,'306.9','Forbudt for ridende','forbuds','sf200510071219306901_gif.gif','Gjelder personer som rir – vanlig ved høytrafikkerte veier eller motorvei.'),(58,'306.10','Forbudt for liten elektrisk motorvogn','forbuds','sf-20051007-1219-306-10-01_gif.png','Forbud mot små elektriske kjøretøy som el-sparkesykkel.'),(59,'308','Forbudt for transport av farlig gods','forbuds','sf20051007121930801_gif.gif','Ikke tillatt å transportere farlig gods – eksplosiver, gass, gift osv.'),(60,'310','Forbudt for motorvogn med flere enn to hjul og med tillatt totalvekt høyere enn angitt','forbuds','sf20051007121931001_gif.gif','Forbud mot større motorvogn – typisk busser og lastebiler med visse unntak.'),(61,'312','Breddegrense','forbuds','sf20051007121931201_gif.gif','Kjøretøy som er bredere enn angitt må ikke passere.'),(62,'314','Høydegrense','forbuds','sf20051007121931401_gif.gif','Kjøretøy som er høyere enn angitt må ikke passere.'),(63,'316','Lengdegrense','forbuds','sf20051007121931601_gif.gif','Kjøretøy som er lengre enn angitt må ikke kjøre inn.'),(64,'318.1','Totalvektgrense for kjoretoy','forbuds','sf200510071219318101_gif.gif','Kjøretøy over angitt totalvekt har ikke tillatelse til å passere.'),(65,'318.2','Totalvektgrense for for vogntog','forbuds','sf200510071219318201_gif.gif','Vogntog over angitt totalvekt har ikke tillatelse til å passere.'),(66,'320','Aksellastgrense','forbuds','sf20051007121932001_gif.gif','Begrenser aksellast – viktig for broers og vegers bæreevne.'),(67,'322','Boggilastgrense','forbuds','sf20051007121932201_gif.gif','Begrenser boggilast – gjelder for tunge kjøretøykombinasjoner.'),(68,'324','Stopp for angitt formal','forbuds','sf20051007121932401_gif.gif','Stopp for kontroll eller annen kontrollfunksjon – se undertekst eller symbol.'),(69,'326','Stopp for toll','forbuds','sf20051007121932601_gif.gif','Stopp for toll – brukes nær grenseoverganger eller tollstasjoner.'),(70,'330.1','Svingeforbud Høgre','forbuds','sf200510071219330101_gif.gif','Det er forbudt å svinge til høyre der dette skiltet er plassert.'),(71,'330.2','Svingeforbud Venstre','forbuds','sf200510071219330201_gif.gif','Det er forbudt å svinge til venstre der dette skiltet er plassert.'),(72,'332','Vendingsforbud','forbuds','sf20051007121933201_gif.gif','Det er ikke tillatt å snu – for eksempel i kryss eller U-sving.'),(73,'334','Forbikjøringsforbud','forbuds','sf20051007121933401_gif.gif','Forbikjøring av motorvogn på mer enn to hjul er forbudt.'),(74,'335','Forbikjoringsforbud for lastebil','forbuds','sf20051007121933501_gif.gif','Forbikjøring med lastebil er forbudt – gjelder tunge kjøretøy.'),(75,'336','Slutt på forbikjoringsforbud','forbuds','sf20051007121933601_gif.gif','Forbudet mot forbikjøring oppheves – gjelder alle kjøretøy.'),(76,'337','Slutt på forbikjoringsforbud for lastebil','forbuds','sf20051007121933701_gif.gif','Forbudet mot forbikjøring med lastebil oppheves.'),(77,'362','Fartsgrense','forbuds','sf20051007121936201_gif.gif','Viser hvilken fartsgrense som gjelder fra og med skiltets plassering.'),(78,'364','Slutt på serskilt fartsgrense','forbuds','sf20051007121936401_gif.gif','Fartsgrensen som tidligere gjaldt opphører – generelle regler gjelder videre.'),(79,'366','Fartsgrensesone','forbuds','sf20051007121936601_gif.gif','Område der angitt fartsgrense gjelder til sonen oppheves.'),(80,'367','Fartsgrensesone for liten elektrisk motorvogn','forbuds','sf-20051007-1219-367-01_gif.png','Fartsgrensesone spesifikt for liten elektrisk motorvogn, f.eks. el-sparkesykkel.'),(81,'368','Slutt pa fartsgrensesone','forbuds','sf20051007121936801_gif.gif','Slutt på fartsgrensesone – den angitte soneregelen oppheves.'),(82,'369','Slutt på fartsgrensesone for liten elektrisk motorvogn','forbuds','sf-20051007-1219-369-01_gif.png','Slutt på sone med fartsgrense for liten elektrisk motorvogn.'),(83,'370','Stans forbudt','forbuds','sf20051007121937001_gif.gif','Stans av kjøretøy er forbudt på området skiltet dekker.'),(84,'372','Parkering forbudt','forbuds','sf20051007121937201_gif.gif','Parkering er ikke tillatt – se eventuelle tilleggsskilt for tidsrom.'),(85,'376.1','Parkeringssone','forbuds','sf200510071219376101_gif.gif','Område der parkeringsregler gjelder som en sone – gjelder inntil opphevet.'),(86,'376.2','Parkeringssone','forbuds','sf200510071219376201_gif.gif','Område der parkeringsregler gjelder som en sone – gjelder inntil opphevet.'),(87,'377','Sone med parkeringsforbud for liten elektrisk motorvogn','forbuds','sf-20051007-1219-377-01_gif.png','Sone med parkeringsforbud for liten elektrisk motorvogn – f.eks. el-sparkesykkel.'),(88,'378.1','Slutt på parkeringssone','forbuds','sf200510071219378101_gif.gif','Slutt på område der parkeringssone-regler har vært gjeldende.'),(89,'378.2','Slutt på parkeringsforbud','forbuds','sf200510071219378201_gif.gif','Slutt på område med parkeringsforbud – normal parkering tillatt.'),(90,'379','Slutt på sone med parkeringsforbud for liten elektrisk motorvogn','forbuds','sf-20051007-1219-379-01_png.png','Slutt på sone med parkeringsforbud for liten elektrisk motorvogn.'),(91,'380','Sone med bruksforbud for liten elektrisk motorvogn','forbuds','sf-20051007-1219-380-01_PNG.png','Område der bruk av liten elektrisk motorvogn er forbudt.'),(92,'382','Slutt på sone med bruksforbud for liten elektrisk motorvogn','forbuds','sf-20051007-1219-382-01_PNG.png','Slutt på sone med bruksforbud for liten elektrisk motorvogn.'),(93,'1000','Kjørefeltlinje','linjer_og','sf200510071219100001_gif.gif','Angir deling mellom kjørefelt i samme retning – kan krysses med varsomhet.'),(94,'1002','Varsellinje','linjer_og','sf200510071219100201_gif_2.gif','Varsler overgang til sperrelinje – kryssing frarådes.'),(95,'1004','Sperrelinje','linjer_og','sf200510071219100401_gif.gif','Det er ikke tillatt å krysse denne linjen – forbudt passering.'),(96,'1006','Kombinerte linjer','linjer_og','sf200510071219100601_gif.gif','En blanding av sperrelinje og kjørefeltlinje – gjelder forskjellig for hver retning.'),(97,'1008','Skillelinje','linjer_og','sf200510071219100801_gif.gif','Skiller kjørefelt som går i ulike retninger – kryssing forbudt.'),(98,'1010','Ledelinje','linjer_og','sf200510071219101001_gif.gif','Brukes for å lede trafikk i kryss eller rundkjøring – gir retning.'),(99,'1012','Kantlinje','linjer_og','sf200510071219101201_gif.gif','Marker ytterkant av kjørebanen – hjelper med plassering i veibanen.'),(100,'1014','Sperreområde','linjer_og','sf200510071219101401_gif.gif','Område markert med heltrukne linjer – kjøring tillates ikke innenfor.'),(101,'1020','Stopplinje','linjer_og','sf200510071219102001_gif.gif','Linje hvor kjøretøy må stanse ved stoppskilt eller rødt lys.'),(102,'1022','Vikelinje','linjer_og','sf200510071219102201_gif_2.gif','Angir hvor vikeplikt skal utøves – stans er ikke påkrevd med mindre nødvendig.'),(103,'1024','Gangfelt','linjer_og','sf200510071219102401_gif.gif','Markerer gangfelt – gir fotgjengere rett til å krysse veien trygt.'),(104,'1026','Sykkelkryssing','linjer_og','sf200510071219102601_gif.gif','Markerer kryssing for syklister – gir informasjon om syklistens trase.'),(105,'1027','Fartshump','linjer_og','sf200510071219102701_gif.gif','Markering av fartshump – varsler sjåfører om å redusere hastigheten.'),(106,'1028','Parkeringsfelt','linjer_og','sf200510071219102801_gif.gif','Angir parkeringsfelt – veibanen er reservert for parkering.'),(107,'1034','Piler','linjer_og','sf200510071219103401_gif.gif','Piler angir kjørefeltets retning eller tillatt bevegelse.'),(108,'1036','Vikesymbol','linjer_og','sf200510071219103601_gif.gif','Symbol som markerer vikeplikt i veikryss.'),(109,'1037','Gangsymbol','linjer_og','sf200510071219103701_gif.gif','Symbol som viser hvor fotgjengere forventes å krysse.'),(110,'1038','Delesymbol','linjer_og','sf200510071219103901_gif.gif','Delesymbol for gang- og sykkelvei – skiller soner for gående og syklende.'),(111,'1040','Parkeringssymbol','linjer_og','sf200510071219104001_gif.gif','Symbol for parkering – ofte brukt i kombinasjon med parkeringsfelt.'),(112,'1041','Liten elektrisk motorvogn','linjer_og','sf-20051007-1219-1041-01-02.png','Markering for område eller felt for liten elektrisk motorvogn (f.eks. el-sparkesykkel).'),(113,'1042','Symbol for forflytningshemmede','linjer_og','sf200510071219104201_gif_2.gif','Markerer plass eller område reservert for forflytningshemmede.'),(114,'1044','Skinnekjøretøy','linjer_og','sf200510071219104401_gif.gif','Symbol for trikk/sporvogn – markerer felt der disse kjører.'),(115,'1050','Tekst','linjer_og','sf200510071219105001_gif.gif','Inngravert eller malt tekst i veibanen – gir ekstra informasjon, f.eks. «BUSS».'),(116,'1052','Sambruksfelt','linjer_og','sf200510071219105201_gif.gif','Felt reservert for felles bruk, f.eks. buss, taxi og elbil.'),(117,'1054','Fartsgrense','linjer_og','sf200510071219105401_gif.gif','Fartsgrensen angitt med tall i kjørebanen.'),(118,'1053','Tungtrafikkfelt','linjer_og','vegoppmerkingsskilt_som_viser_75_tonn__grafikk.gif','Felt reservert for tunge kjøretøy som lastebil og buss.'),(119,'761','Motorveg','opplysnings','sf20051007121950201_gif.gif','Vei reservert for motorvogn med høy standard – avkjørsler kun i planfrie kryss.'),(120,'763','Motortrafikkveg','opplysnings','sf20051007121950301_gif.gif','Hovedvei for motorisert trafikk med visse restriksjoner for gående og syklende.'),(121,'504','Slutt på motorveg','opplysnings','sf20051007121950401_gif.gif','Motorveien opphører – normale trafikkregler gjelder videre.'),(122,'505','Slutt på motortrafikkveg','opplysnings','sf20051007121950501_gif.gif','Motortrafikkveien opphører – vær oppmerksom på mulig redusert standard.'),(123,'506','Tungtrafikkfelt','opplysnings','sf20051007121950601_gif.gif','Felt forbeholdt tunge kjøretøy, som lastebil og buss.'),(124,'507','Slutt på tungtrafikkfelt','opplysnings','sf20051007121950701_gif.gif','Avslutning på særskilt felt for tungtrafikk.'),(125,'508.1','Kollektivfelt for buss','opplysnings','sf200510071219508101_gif.gif','Felt reservert for busser – andre kjøretøy må ikke bruke dette.'),(126,'508.2','Kollektivfelt for buss og drosje','opplysnings','sf200510071219508201_gif.gif','Felt reservert for busser og drosjer (taxi).'),(127,'509','Sambruksfelt','opplysnings','sf20051007121950901_gif.gif','Felt for felles bruk, f.eks. elbil, taxi, kollektiv m.m. – se skilt.'),(128,'510.1','Slutt på kollektivfelt','opplysnings','sf200510071219510101_gif.gif','Slutt på område med kollektivfelt – vanlige regler gjelder.'),(129,'510.2','Slutt på kollektivfelt for buss og drosje','opplysnings','sf200510071219510201_gif.gif','Kollektivfelt for buss og drosje opphører – normale regler gjelder.'),(130,'511','Slutt på sambruksfelt','opplysnings','sf20051007121951101_gif.gif','Felt for elbil, taxi m.m. opphører – vanlig trafikkfelt følger.'),(131,'512','Holdeplass for buss','opplysnings','sf20051007121951201_gif.gif','Marker område der buss stopper for av- og påstigning.'),(132,'513','Holdeplass for sporvogn','opplysnings','sf20051007121951301_gif.gif','Marker område der trikk/sporvogn stopper – se opp for passasjerer.'),(133,'514','Holdeplass for drosje','opplysnings','sf20051007121951401_gif.gif','Reservert plass for taxi – ventende og kjørende drosjer.'),(134,'516','Gangfelt','opplysnings','sf20051007121951601_gif.gif','Opplyser om fotgjengerovergang – vis hensyn og vikeplikt.'),(135,'518','Gangveg','opplysnings','sf20051007121951801_gif.gif','Opplyser om veg kun for gående – sykling forbudt.'),(136,'520','Sykkelveg','opplysnings','sf20051007121952001_gif.gif','Opplyser om veg kun for syklister – andre trafikanter forbudt.'),(137,'521.1','Sykkelfelt – sideplassert','opplysnings','sf20051007121952101_gif.gif','Oppmerksomhet på sykkelfelt langs veikant – kun for syklister.'),(138,'521.2','Sykkelfelt – Midtstilt','opplysnings','sf200510071219521201_gif.gif','Sykkelfelt plassert i midten av kjørefelt – kun for syklister.'),(139,'522','Gang- og sykkelveg','opplysnings','sf20051007121952201_gif.gif','Veg delt mellom gående og syklende – vis hensyn og hold deg til riktig side.'),(140,'524','Møteplass','opplysnings','sf20051007121952401_gif.gif','Utvidet område der kjøretøy kan møtes og passere hverandre.'),(141,'526.1','Envegskjøring frem','opplysnings','sf200510071219526101_gif.gif','Kun én kjøreretning tillatt – fremover i pilens retning.'),(142,'526.2','Envegskjøring venstre','opplysnings','sf200510071219526201_gif.gif','Enveisveg med kjøreretning til venstre.'),(143,'527.1','Blindveg','opplysnings','sf200510071219527101_gif.gif','Veg som ikke har gjennomkjøring – ender blindt.'),(144,'527.2','Skiltet viser at vegen er fysisk stengt.','opplysnings','sf200510071219527201_gif.gif','Veg sperret med fysisk hindring, f.eks. bom, mur eller annet.'),(145,'527.3','Skiltet viser at kryssende veg er fysisk stengt','opplysnings','sf200510071219527301_gif.gif','Kryssende veg er fysisk sperret – gjennomkjøring umulig.'),(146,'527.4','Skiltet viser at vegen er stengt for biltrafikk, men åpen for gående og syklende','opplysnings','sf200510071219527401_gif.gif','Biltrafikk forhindres – men annen ferdsel kan være tillatt.'),(147,'528','Valgfritt kjørefelt','opplysnings','sf20051007121952801_gif.gif','Trafikanter kan velge fritt mellom kjørefeltene i angitt område.'),(148,'530','Sammenfletting','opplysnings','sf200510071219530a01_gif.gif','Kjørefelt flettes sammen – veksle på å slippe frem kjøretøy.'),(149,'531.1','Felt for fartsøkning','opplysnings','sf200510071219531101_gif.gif','Kjørefelt for akselerasjon – benyttes ved innkjøring på hovedvei.'),(150,'532','Kjørefelt slutter','opplysnings','sf200510071219532a01_gif.gif','Et kjørefelt opphører – vær oppmerksom og flett inn i tide.'),(151,'534','Kjørefelt begynner','opplysnings','sf200510071219534a01_gif.gif','Et nytt kjørefelt starter – benytt ved behov.'),(152,'536.1','Påkjøring fortsetter i eget kjørefelt','opplysnings','sf200510071219536101_gif.gif','Feltet du kommer fra fortsetter – ingen fletting nødvendig.'),(153,'538','Kjørefeltinndeling','opplysnings','sf20051007121953801_gif.gif','Viser hvordan kjørefeltene er delt – planlegg kjøring deretter.'),(154,'539','Endret kjøremønster','opplysnings','sf20051007121953901_gif.gif','Kjør forsiktig – uvanlig eller midlertidig kjøremønster i området.'),(155,'540','Gatetun','opplysnings','sf20051007121954001_gif.gif','Område der gående har prioritet – lav hastighet påbudt.'),(156,'542','Slutt på gatetun','opplysnings','sf20051007121954201_gif.gif','Vanlige trafikkregler gjelder igjen – vis hensyn.'),(157,'548','Gågate','opplysnings','sf20051007121954801_gif.gif','Veg kun for gående – kjøring vanligvis forbudt.'),(158,'550','Slutt på gågate','opplysnings','sf20051007121955001_gif.gif','Kjøring kan gjenopptas – følg gjeldende regler.'),(159,'552','Parkering','opplysnings','sf20051007121955201_gif.gif','Område der det er tillatt å parkere – følg eventuelle tilleggsskilt.'),(160,'555','Havarilomme','opplysnings','sf20051007121955501_gif.gif','Lomme i veien for nødstopp – ikke ment for vanlig parkering.'),(161,'556.1','Automatisk trafikkontroll – punktmåling','opplysnings','sf200510071219556101_gif.gif','Fotoboks måler kjøretøyets hastighet på et bestemt punkt.'),(162,'556.2','Automatisk trafikkontroll – strekningsmåling','opplysnings','sf200510071219556201_gif.gif','Gjennomsnittshastighet måles over en strekning.'),(163,'558','Videokontroll/-overvåking','opplysnings','sf20051007121955801_gif.gif','Området er videoovervåket – ofte brukt ved bomstasjoner eller tunneler.'),(164,'560','Opplysningstavle','opplysnings','sf20051007121956001_gif.gif','Gir generell informasjon – kan brukes sammen med symbol eller tekst.'),(165,'565','Feil kjøreretning','opplysnings','sf20051007121956501_gif.gif','Varsel om at du kjører mot kjøreretningen – snu umiddelbart.'),(166,'570.1','Nødutgangsskilt for tunnel','opplysnings','sf2005100712195701h01_gif.gif','Viser plassering av nødutgang i tunnel.'),(167,'570.2','Retning og avstand til nødutgang','opplysnings','sf2005100712195702h01_gif.gif','Angir retningen og avstanden til nærmeste nødutgang.'),(168,'650.22','Sykkelloype','service','serviceskilt_som_viser_sykkelløype__grafikk.gif','Vei eller rute tilrettelagt for syklister – del av nasjonalt eller lokalt nettverk.'),(169,'602','Førstehjelp','service','sf20051007121960201_gif.gif','Sted der førstehjelpsutstyr er tilgjengelig – f.eks. hjertestarter.'),(170,'605','Nødtelefon','service','sf20051007121960501_gif.gif','Plassering av telefon for nødsituasjoner – ofte i tunneler eller langs motorvei.'),(171,'606','Brannslokningsapparat','service','sf20051007121960601_gif.gif','Viser hvor brannslukker er plassert – viktig ved brannfare.'),(172,'608','Kjøretøyverksted','service','sf20051007121960801_gif.gif','Verksted der kjøretøy kan repareres – dekker både små og store kjøretøy.'),(173,'609','Hurtiglading av motorvogn','service','sf20051007121960901_gif.gif','Tilgang til hurtigladestasjon for elbil eller annet elektrisk kjøretøy.'),(174,'610.1 ','Drivstoff','service','sf200510071219610101_gif.gif','Tilgang på bensin, diesel eller annen type drivstoff – bensinstasjon.'),(175,'611','Toalettømmeanlegg','service','sf20051007121961101_gif.gif','Tømmestasjon for campingvogner eller bobiler – sanitæranlegg.'),(176,'612','Toalett','service','sf20051007121961201_gif.gif','Offentlig toalett tilgjengelig på stedet.'),(177,'613.1','Rasteplass','service','sf200510071219613101_gif.gif','Tilrettelagt stoppested med sitteplasser, ofte med toalett og informasjon.'),(178,'613.2','Rasteplass med toalett','service','sf200510071219613201_gif.gif','Rast med både sitteplass og toalett – egnet for lengre stopp.'),(179,'614','Enklere servering','service','sf20051007121961401_gif.gif','Kiosk, kafé eller annen enkel matservering.'),(180,'616','Spisested','service','sf20051007121961601_gif.gif','Restaurant eller større serveringssted med varm mat.'),(181,'618','Campingplass','service','sf20051007121961801_gif.gif','Område tilrettelagt for telt og campingvogner.'),(182,'621','Bobilplass','service','sf20051007121962101_gif.gif','Oppstillingsplass spesifikt for bobiler – ofte med strøm og vann.'),(183,'622','Campinghytter','service','sf20051007121962201_gif.gif','Enkle overnattingshytter ofte tilknyttet campingplass.'),(184,'624','Vandrerhjem','service','sf20051007121962401_gif.gif','Rimelig overnatting med fellesrom og selvbetjening.'),(185,'625','Rom og frokost','service','sf20051007121962501_gif.gif','Privat overnatting med frokost inkludert – «bed and breakfast».'),(186,'626','Overnattingssted','service','sf20051007121962601_gif.gif','Generell overnatting – hotell, motell, pensjonat osv.'),(187,'635','Informasjon','service','sf20051007121963501_gif.gif','Generell informasjonstavle for reisende – f.eks. kart, regler eller tilbud.'),(188,'637','Turistkontor','service','sf20051007121963701_gif.gif','Offentlig kontor med informasjon for turister – kart, brosjyrer, tips.'),(189,'638','Døgnhvileplass','service','sf-20051007-1219-638-01-01.png','Parkeringsplass for langtransport med fasiliteter for hvile og overnatting.'),(190,'640.10','Severdighet','service','sf2005100712196401001_gif.gif','Viser vei til kulturelt eller naturlig interessant sted.'),(191,'640.12','Museum/galleri','service','sf2005100712196401201_gif.gif','Tilgang til kunstutstilling eller museum.'),(192,'640.20 ','Utsiktspunkt','service','sf2005100712196402001_gif.gif','Sted med utsikt over landskap, by eller severdighet.'),(193,'650.10','Badeplass','service','sf2005100712196501001_gif.gif','Offentlig tilrettelagt badeområde.'),(194,'650.11','Fiskeplass','service','sf2005100712196501101_gif.gif','Tilrettelagt område for sportsfiske eller fritidsfiske.'),(195,'650.20','Tursti','service','sf2005100712196502001_gif.gif','Merket rute for fotturer i naturen.'),(196,'650.21','Skiløype','service','sf2005100712196502101_gif.gif','Preparert løype for langrenn eller annen skigåing.'),(197,'650.40','Gardsmat/bygdeturisme','service','sf2005100712196504001_gif.gif','Tilbud om lokal mat, gårdsopplevelser eller overnatting i landlige omgivelser.'),(198,'1080','Hovedsignal','signaler','sf200510071219108001_gif.gif','Vanlig trafikklys for motorvogner – regulerer kjøring med rødt, gult og grønt.'),(199,'1082.1','Pilsignal Venstre','signaler','sf2005100712191082101_gif.gif','Trafikklys med pil til venstre – gjelder kun for venstresvingende trafikk.'),(200,'1082.2','Pilsignal Opp','signaler','sf2005100712191082201_gif.gif','Pilsignal rett frem – gjelder bare for trafikk rett frem.'),(201,'1082.3','Pilsignal Høgre','signaler','sf2005100712191082301_gif.gif','Pil til høyre – signalet gjelder bare for høyresvingende trafikk.'),(202,'1084','Sykkelsignal','signaler','sf200510071219108402_gif.gif','Eget lys for syklister – styrer når det er trygt å krysse eller kjøre.'),(203,'1086','Fotgjengersignal','signaler','sf200510071219108601_gif.gif','Signal for fotgjengere – grønn mann = gå, rød mann = stans.'),(204,'1088','Signal for kollektivtrafikk','signaler','sf200510071219108802_gif.gif','Trafikklys for buss og trikk – egne signaler som ikke gjelder andre trafikanter.'),(205,'1090','Kjørefeltsignal','signaler','sf200510071219109001_gif.gif','Lyssignal over kjørefelt – viser om feltet er åpent eller stengt.'),(206,'1092','Tolyssignal','signaler','sf200510071219109201_gif.gif','Rødt og grønt lys brukt der gult ikke er nødvendig – f.eks. bommer.'),(207,'1094','Rødt stoppblinksignal','signaler','sf200510071219109401_gif.gif','Blinkende rødt lys – stans umiddelbart og følg anvisninger eller bommer.'),(208,'1096','Blinkende signal foran jernbane','signaler','sf200510071219109601_gif.gif','Varsellys før planovergang – stans ved blinkende rødt, jernbane nærmer seg.'),(209,'1098','Gult blinksignal','signaler','sf200510071219109801_gif.gif','Varsellys som ber trafikanter være ekstra oppmerksomme – ingen stans plikt.'),(210,'1100.1','Blinkende lyspil','signaler','sf2005100712191100101_gif.gif','Pil som blinker for å vise anbefalt kjøreretning – ofte ved hinder eller veiarbeid.'),(211,'902.1','Bakgrunnsmarkering Høgre','markering','sf200510071219902h01_gif.gif','Refleksmarkering som viser hindringer eller objekter på høyre side.'),(212,'902.2','Bakgrunnsmarkering Venstre','markering','sf200510071219902v01_gif.gif','Refleksmarkering som viser hindringer eller objekter på venstre side.'),(213,'904 .1','Retningsmarkering Høgre','markering','sf200510071219904h01_gif.gif','Viser skarp sving eller kurve til høyre – gir tidlig visuell varsling.'),(214,'904.2','Retningsmarkering Venstre','markering','sf200510071219904v01_gif.gif','Viser skarp sving eller kurve til venstre – gir tidlig visuell varsling.'),(215,'906.1','Hindermarkering Høgre','markering','sf200510071219906h01_gif.gif','Markerer hindring – passer på høyre side.'),(216,'906.2','Hindermarkering Venstre','markering','sf200510071219906v01_gif.gif','Markerer hindring – passer på venstre side.'),(217,'906.3','Hindermarkering Frem','markering','sf200510071219906vh01_gif.gif','Hindring skal passeres rett frem – typisk midt i veien.'),(218,'908','Hindermarkering','markering','sf20051007121990801_gif.gif','Generell markering av hindringer i eller ved veibanen.'),(219,'912','Avkjøringsmarkering','markering','sf20051007121991201_gif.gif','Marker avkjøring – ofte brukt før utfartsramper.'),(220,'914','Tunnelmarkering','markering','sf200510071219914h01_gif.gif','Brukes i tunneler for å vise vegkanter eller retning.'),(221,'916','Avstandsmarkering i tunnel','markering','sf20051007121991601_gif.gif','Viser avstand i meter til nærmeste nødutgang – plassert jevnlig i tunnelvegger.'),(222,'920','Kantstolpe','markering','sf200510071219920h01_gif.gif','Marker kant av veien – reflekser gir veiledning i mørke.'),(223,'940','Trafikkjegle','markering','sf20051007121994001_gif.gif','Midlertidig markering ved arbeid, ulykker eller hindringer – lett flyttbar.'),(224,'942','Trafikksylinder','markering','sf20051007121994201_gif.gif','Høy, sylindrisk markør for å lede trafikk eller sperre av område midlertidig.'),(225,'802','Avstand','under','sf20051007121980201_gif.gif','Viser hvor langt restriksjon eller informasjon gjelder fremover.'),(226,'804','Utstrekning','under','sf20051007121980401_gif.gif','Angir total lengde eller område som restriksjonen gjelder.'),(227,'806','Tid','under','sf20051007121980601_gif.gif','Viser når skiltet gjelder – f.eks. ukedager, klokkeslett.'),(228,'807.1 ','Personbil','under','sf200510071219807101_gif.gif','Skiltet gjelder kun for personbiler.'),(229,'807.2','Varebil, lastebil og trekkbil','under','sf200510071219807201_gif.gif','Gjelder kjøretøy med varer, gods eller tilhenger – som lastebil og trekkbil.'),(230,'807.3','Buss','under','sf200510071219807301_gif.gif','Skiltet gjelder for busser i rutetrafikk eller turtrafikk.'),(231,'807.4','Vogntog','under','sf200510071219807401_gif.gif','Gjelder kjøretøykombinasjoner – f.eks. lastebil med tilhenger.'),(232,'807.5','Tilhenger særskilt innredet til campingbruk, samt eventuell trekkvogn','under','sf200510071219807501_gif.gif','Gjelder tilhengere innredet til campingbruk.'),(233,'807.6','Sykkel og liten elektrisk motorvogn','under','sf200510071219807601_gif.gif','Skiltet gjelder for sykler, el-sykler og små elektriske kjøretøy.'),(234,'807.7','Tohjuls motorsykkel med og uten sidevogn og tohjuls moped','under','sf200510071219807701_gif.gif','Gjelder tohjuls motorsykkel og moped, med eller uten sidevogn.'),(235,'807.8','Forflytningshemmede med parkeringstillatelse','under','sf200510071219807801_gif.gif','Gjelder kun for personer med gyldig parkeringsbevis for forflytningshemmede.'),(236,'807.9','Kjøretøy særskilt innredet til campingbruk (bobil)','under','sf200510071219807901_gif.gif','Gjelder for bobiler og større kjøretøy spesielt tilpasset camping.'),(237,'808','Tekst','under','sf20051007121980801_gif.gif','Tilleggsskilt med informasjon i form av tekst.'),(238,'810','Svingpil','under','sf20051007121981001_gif.gif','Angir hvilken retning skiltet gjelder for – f.eks. høyresving.'),(239,'812','Anbefalt fart','under','sf20051007121981201_gif.gif','Viser anbefalt hastighet under spesielle forhold – ikke bindende.'),(240,'813.1','Stigningsgrad','under','sf200510071219813101_gif.gif','Angir stigning eller helling på veien i prosent.'),(241,'814','Virkelig fri vegbredde','under','sf20051007121981401_gif.gif','Viser faktisk tilgjengelig bredde på veien – nyttig for større kjøretøy.'),(242,'816','Kryssende tømmertransport','under','sf20051007121981601_gif.gif','Informasjon om at veien krysses av tømmertransport – vis forsiktighet.'),(243,'817','Særlig ulykkesfare','under','sf20051007121981701_gif.gif','Varsel om høy ulykkesrisiko – kjør ekstra forsiktig.'),(244,'822','Forløp av forkjørsveg','under','sf20051007121982201_gif.gif','Viser hvordan forkjørsveien fortsetter gjennom kryss – viktig for vikeplikt.'),(245,'824','Forvarsling av stopp','under','sf20051007121982401_gif.gif','Informerer om at det kommer et stopp-skilt lenger fremme.'),(246,'826','Sykkeltrafikk i begge kjøreretninger','under','sf20051007121982601_gif.gif','Angir at syklister kan kjøre begge retninger i enveiskjørt gate.'),(247,'828.1','Utstrekning av stans- og parkeringsregulering','under','sf200510071219828101_gif.gif','Viser hvor langt parkeringsforbud eller stansforbud gjelder.'),(248,'829','Oppstilling av parkert kjøretøy','under','sf20051007121982901_gif.gif','Viser hvordan kjøretøy skal plasseres på parkeringsplass.'),(249,'831','Parkeringsskive/gratisbillett','under','sf20051007121983101_gif.gif','Informasjon om at parkeringsskive eller gratisbillett må brukes.'),(250,'834','Kombinert regulering','under','sf20051007121983401_gif.gif','Flere parkeringsregler gjelder samtidig – les nøye tilleggsskilt.'),(251,'701','Tabellorienteringstavle','vegvisnings','sf20051007121970101_gif.gif','Stor oversiktstavle som viser flere reisemål og avstander – plassert i god avstand fra veikryss.'),(252,'703','Diagramorienteringstavle','vegvisnings','sf20051007121970301_gif.gif','Viser veikryss med kjøremønster – forbereder fører på veivalg.'),(253,'705','Avkjøringstavle','vegvisnings','sf20051007121970501_gif.gif','Informerer om avkjøring fra hovedvei – viser destinasjon og avstand.'),(254,'707','Kjørefeltorienteringstavle','vegvisnings','sf20051007121970701_gif.gif','Viser hvilke felt som leder til ulike reisemål – hjelper ved feltskifte.'),(255,'709','Portalorienteringstavle','vegvisnings','sf20051007121970901_gif.gif','Oversiktsskilt plassert over veibanen – viser felt og destinasjoner.'),(256,'711','Tabellvegviser','vegvisnings','sf20051007121971101_gif.gif','Standard vegviserskilt med tekst og eventuelt symboler – viser retning og reisemål.'),(257,'713','Vanlig vegviser','vegvisnings','sf20051007121971301_gif.gif','Enklere retningsskilt med ett eller få reisemål.'),(258,'715','Avkjøringsvegviser','vegvisnings','sf20051007121971501_gif.gif','Skilt ved selve avkjøringen – angir reisemål for den aktuelle avkjøringen.'),(259,'717','Kjørefeltvegviser','vegvisnings','sf20051007121971701_gif.gif','Viser hvilke felt som leder til spesifikke reisemål – plassert langs veien.'),(260,'719','Portalvegviser','vegvisnings','sf20051007121971901_gif.gif','Skilt over kjørebanen som viser retning og felt for ulike reisemål.'),(261,'723.11','Vegnummer for europaveg','vegvisnings','sf2005100712197231101_gif.gif','Viser nummer på europaveg – E-veier med grønn bakgrunn og hvit tekst.'),(262,'723.13','Vegnummer for riksveg som ikke er europaveg','vegvisnings','sf2005100712197231301_gif.gif','Viser nummer på nasjonal hovedvei – hvit bakgrunn, sort tekst.'),(263,'723.15','Vegnummer for nummerert fylkesveg','vegvisnings','sf2005100712197231501_gif.gif','Nummerert fylkesvei – skilt med blå bakgrunn og hvit tekst.'),(264,'723.21','Ringveg/ringrute','vegvisnings','sf2005100712197232101_gif.gif','Viser rutenummer for ringvei – brukes i større byområder.'),(265,'723.31','Nasjonal turistveg','vegvisnings','sf2005100712197233101_gif.gif','Spesielt utvalgte veier med naturopplevelser – brun bakgrunn.'),(266,'723.41','Omkjøringsrute for store kjøretøy','vegvisnings','sf2005100712197234101_gif.gif','Anbefalt omkjøringsvei for store kjøretøy som ikke kommer gjennom vanlig rute.'),(267,'723.51','Rute for transport av farlig gods','vegvisnings','sf2005100712197235101_gif.gif','Skilt for anbefalt rute for kjøretøy med farlig last.'),(268,'723.61','Andre omkjøringsruter','vegvisnings','sf2005100712197236101_gif.gif','Midlertidige eller faste ruter brukt ved stengte veier eller veiarbeid.'),(269,'723.62','Andre omkjøringsruter','vegvisnings','sf2005100712197236201_gif.gif','Midlertidige eller faste ruter brukt ved stengte veier eller veiarbeid.'),(270,'723.63','Andre omkjøringsruter','vegvisnings','sf2005100712197236301_gif.gif','Midlertidige eller faste ruter brukt ved stengte veier eller veiarbeid.'),(271,'723.64','Andre omkjøringsruter','vegvisnings','sf2005100712197236401_gif.gif','Midlertidige eller faste omkjøringsruter – gjerne nummererte og fargede symboler.'),(272,'723.65','Andre omkjøringsruter','vegvisnings','sf2005100712197236501_gif.gif','Midlertidige eller faste omkjøringsruter – gjerne nummererte og fargede symboler.'),(273,'723.66','Andre omkjøringsruter','vegvisnings','sf2005100712197236601_gif.gif','Midlertidige eller faste omkjøringsruter – gjerne nummererte og fargede symboler.'),(274,'723.71','Kryssnummer på flerfeltsveg','vegvisnings','sf2005100712197237101_gif.gif','Angir nummer på kryss langs motorvei – hjelper fører med orientering.'),(275,'723.73','Kryssnummer på tofeltsveg','vegvisnings','sf2005100712197237301_gif.gif','Viser nummer på kryss langs tofelts hovedvei.'),(276,'725','Avstandsskilt','vegvisnings','sf20051007121972501_gif.gif','Viser avstand til ulike reisemål langs ruten – vanligvis i kilometer.'),(277,'727','Stedsnavnskilt','vegvisnings','sf20051007121972701_gif.gif','Angir hvilket sted du nå kjører inn i.'),(278,'729','Gate-/vegnavnskilt','vegvisnings','sf20051007121972901_gif.gif','Viser navn på gaten eller veien – orienteringshjelp i tettbygde strøk.'),(279,'731','Samleskilt for vegvisning','vegvisnings','sf20051007121973101_gif.gif','Flere vegvisere samlet på én tavle – gir oversikt over retninger.'),(280,'741','Omkjøring for bestemte kjøretøygrupper','vegvisnings','sf20051007121974101_gif.gif','Viser omkjøring spesielt for f.eks. tunge kjøretøy, farlig gods osv.'),(281,'743','Midlertidig omkjøring','vegvisnings','sf20051007121974301_gif.gif','Midlertidig rute grunnet f.eks. veiarbeid eller hendelser.'),(282,'745','Slutt på midlertidig omkjøring','vegvisnings','sf20051007121974501_gif.gif','Informerer om at midlertidig rute nå avsluttes.'),(283,'749','Vegviser for gangtrafikk','vegvisnings','sf20051007121974901_gif.gif','Skilt som viser retning for gående trafikanter.'),(284,'751','Vegviser for sykkelrute','vegvisnings','sf20051007121975101_gif.gif','Viser retning og nummer for sykkelrute – nasjonale eller lokale.'),(285,'753','Tabellvegviser for sykkelrute','vegvisnings','sf20051007121975301_gif.gif','Oversikt over flere sykkelruter med destinasjoner og avstand.'),(286,'755','Sykkelruteskilt','vegvisnings','sf20051007121975501_gif.gif','Symbolskilt som viser hvilken sykkelrute du befinner deg på.'),(287,'757','Avstandsskilt for sykkelrute','vegvisnings','sf20051007121975701_gif.gif','Viser avstand til mål for sykkelruten.'),(288,'761','Motorveg','vegvisnings','sf20051007121976101_gif.gif','Vei reservert for motorvogn med høy standard – avkjørsler kun i planfrie kryss.'),(289,'763','Motortrafikkveg','vegvisnings','sf20051007121976301_gif.gif','Hovedvei for motorisert trafikk med visse restriksjoner for gående og syklende.'),(290,'765','Bomveg/brukerbetaling på veg','vegvisnings','sf20051007121976501_gif.gif','Informerer om at veien er avgiftsbelagt.'),(291,'767','Parkering','vegvisnings','sf20051007121976701_gif.gif','Skilt som viser hvor det finnes parkeringsplass.'),(292,'769','Parkeringshus','vegvisnings','sf20051007121976901_gif.gif','Viser vei til innendørs parkeringsanlegg.'),(293,'771','Lufthavn/flyplass','vegvisnings','sf20051007121977101_gif.gif','Viser vei til flyplass.'),(294,'772','Helikopterplass','vegvisnings','sf20051007121977201_gif.gif','Skilt for helikopterlandingsplass.'),(295,'773','Busstasjon/bussterminal','vegvisnings','sf20051007121977301_gif.gif','Viser plassering av bussterminal eller stasjon.'),(296,'774','Jernbanestasjon/togterminal','vegvisnings','sf20051007121977401_gif.gif','Sted der tog ankommer og går – skiltet viser retning til nærmeste jernbanestasjon.'),(297,'775','Bilferje','vegvisnings','sf20051007121977501_gif.gif','Viser vei til ferjeleie for kjøretøy – skiltet benyttes der bilferje er del av transportnettet.'),(298,'776','Godshavn','vegvisnings','sf20051007121977601_gif.gif','Angir plassering av havn for gods – brukes til å lede tungtrafikk eller frakttransport.'),(299,'780','Kjetting','vegvisnings','sf20051007121978001_gif.gif','Skiltet angir plass for pålegging eller kontroll av kjettinger ved vinterføre.'),(300,'790.10','Kirke','vegvisnings','sf2005100712197901001_gif.gif','Viser vei til kirke – både for religiøse formål og som severdighet.'),(301,'790.15','Næringsområde','vegvisnings','sf2005100712197901501_gif.gif','Angir plassering av industri- eller næringsområde.'),(302,'790.20','Svømmehall','vegvisnings','sf2005100712197902001_gif.gif','Skilt for offentlig svømmeanlegg – viser hvor man finner bademulighet.'),(303,'790.30','Alpinanlegg','vegvisnings','sf2005100712197903001_gif.gif','Brukes for å vise vei til anlegg for alpint eller skisport.'),(304,'790.31','Hoppbakke','vegvisnings','sf2005100712197903101_gif.gif','Viser plassering av skihoppanlegg.'),(305,'790.32 ','Skistadion','vegvisnings','sf2005100712197903201_gif.gif','Skilt for anlegg med langrennsløyper, skiskytterarena eller lignende.'),(306,'790.40','Golfbane','vegvisnings','sf2005100712197904001_gif.gif','Angir vei til golfbane eller golfanlegg.'),(307,'792.11','Betaling med elektronisk brikke','vegvisnings','sf2005100712197921101_gif.gif','Bompassering der betaling skjer automatisk med elektronisk brikke, f.eks. AutoPASS.'),(308,'792.12','Betaling til betjent','vegvisnings','sf2005100712197921201_gif.gif','Bomstasjon hvor betaling gjøres manuelt til betjent.'),(309,'792.13','Betaling med mynter til automat','vegvisnings','sf2005100712197921301_gif.gif','Bom der man betaler med mynter i automat.'),(310,'792.14','Betaling med kort til automat','vegvisnings','sf2005100712197921401_gif.gif','Bom der man betaler med bankkort/kredittkort i automat.'),(311,'792.15','Betaling med sedler til automat','vegvisnings','sf2005100712197921501_gif.gif','Bomstasjon der man kan betale med kontantsedler i automat.'),(312,'792.16','Ta billett i et lukket betalingssystem','vegvisnings','sf2005100712197921601_gif.gif','Du må ta en billett ved innkjøringen – brukes ved parkeringsanlegg.'),(313,'792.17','Lever billett i et lukket betalingssystem','vegvisnings','sf2005100712197921701_gif.gif','Du må levere billett ved utkjøring for å betale korrekt beløp.'),(314,'792.30','Helautomatisk bomstasjon som passeres uten å stanse','vegvisnings','sf2005100712197923001_gif.gif','Passering skjer automatisk – ingen manuell betaling på stedet.'),(315,'792.31','Betaling med AutoPASS','vegvisnings','sf2005100712197923101_gif.gif','Skiltet viser at bompengene betales automatisk via AutoPASS-avtale.'),(316,'790.16','Kjøpesenter','vegvisnings','vegvisningsskilt_som_viser_en_handlevogn_for_kjøpesenter__grafikk.gif','Viser retning til større kjøpesenter eller handlesenter.');
/*!40000 ALTER TABLE `traffic_signs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_limits`
--

DROP TABLE IF EXISTS `usage_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_limits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `daily_quizzes_taken` int DEFAULT NULL,
  `daily_limit_date` date DEFAULT NULL,
  `weekly_exams_taken` int DEFAULT NULL,
  `weekly_limit_start` date DEFAULT NULL,
  `monthly_videos_watched` int DEFAULT NULL,
  `monthly_limit_start` date DEFAULT NULL,
  `last_daily_reset` datetime DEFAULT NULL,
  `last_weekly_reset` datetime DEFAULT NULL,
  `last_monthly_reset` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usage_user_date` (`user_id`,`daily_limit_date`),
  CONSTRAINT `usage_limits_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_limits`
--

LOCK TABLES `usage_limits` WRITE;
/*!40000 ALTER TABLE `usage_limits` DISABLE KEYS */;
INSERT INTO `usage_limits` VALUES (1,1,0,'2025-06-23',0,'2025-06-23',0,NULL,'2025-06-23 14:30:53','2025-06-23 14:30:53',NULL,'2025-06-20 22:39:58','2025-06-23 14:30:53'),(3,3,0,'2025-06-21',0,'2025-06-16',0,NULL,NULL,NULL,NULL,'2025-06-21 00:13:01','2025-06-21 00:13:01');
/*!40000 ALTER TABLE `usage_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_achievements`
--

DROP TABLE IF EXISTS `user_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_achievements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `achievement_id` int NOT NULL,
  `earned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_achievement` (`user_id`,`achievement_id`),
  KEY `achievement_id` (`achievement_id`),
  CONSTRAINT `user_achievements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_achievements_ibfk_2` FOREIGN KEY (`achievement_id`) REFERENCES `achievements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_achievements`
--

LOCK TABLES `user_achievements` WRITE;
/*!40000 ALTER TABLE `user_achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_daily_challenges`
--

DROP TABLE IF EXISTS `user_daily_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_daily_challenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `challenge_id` int NOT NULL,
  `progress` int DEFAULT NULL,
  `completed` tinyint(1) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `xp_earned` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_daily_challenge_uc` (`user_id`,`challenge_id`),
  KEY `challenge_id` (`challenge_id`),
  CONSTRAINT `user_daily_challenges_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_daily_challenges_ibfk_2` FOREIGN KEY (`challenge_id`) REFERENCES `daily_challenges` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_daily_challenges`
--

LOCK TABLES `user_daily_challenges` WRITE;
/*!40000 ALTER TABLE `user_daily_challenges` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_daily_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_feedback`
--

DROP TABLE IF EXISTS `user_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `feedback_type` varchar(50) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `status` varchar(50) DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_feedback`
--

LOCK TABLES `user_feedback` WRITE;
/*!40000 ALTER TABLE `user_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learning_paths`
--

DROP TABLE IF EXISTS `user_learning_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learning_paths` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `path_id` int NOT NULL,
  `progress_percentage` int DEFAULT '0',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_path` (`user_id`,`path_id`),
  KEY `path_id` (`path_id`),
  CONSTRAINT `user_learning_paths_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_learning_paths_ibfk_2` FOREIGN KEY (`path_id`) REFERENCES `learning_paths` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learning_paths`
--

LOCK TABLES `user_learning_paths` WRITE;
/*!40000 ALTER TABLE `user_learning_paths` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learning_paths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_levels`
--

DROP TABLE IF EXISTS `user_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_levels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `current_level` int DEFAULT NULL,
  `current_xp` int DEFAULT NULL,
  `total_xp` int DEFAULT NULL,
  `next_level_xp` int DEFAULT NULL,
  `last_level_up` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `user_levels_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_levels`
--

LOCK TABLES `user_levels` WRITE;
/*!40000 ALTER TABLE `user_levels` DISABLE KEYS */;
INSERT INTO `user_levels` VALUES (1,1,1,0,0,100,NULL),(2,3,1,0,0,100,NULL);
/*!40000 ALTER TABLE `user_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notification_preferences`
--

DROP TABLE IF EXISTS `user_notification_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_notification_preferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `daily_reminders` tinyint(1) DEFAULT '1',
  `weekly_summary` tinyint(1) DEFAULT '1',
  `achievement_notifications` tinyint(1) DEFAULT '1',
  `streak_lost_reminders` tinyint(1) DEFAULT '1',
  `study_tips` tinyint(1) DEFAULT '1',
  `new_features` tinyint(1) DEFAULT '1',
  `progress_milestones` tinyint(1) DEFAULT '1',
  `quiz_reminder_frequency` varchar(20) DEFAULT 'daily',
  `marketing_emails` tinyint(1) DEFAULT '0',
  `partner_offers` tinyint(1) DEFAULT '0',
  `reminder_time` time DEFAULT '18:00:00',
  `timezone` varchar(50) DEFAULT 'Europe/Oslo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_notification_preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notification_preferences`
--

LOCK TABLES `user_notification_preferences` WRITE;
/*!40000 ALTER TABLE `user_notification_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_notification_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_power_ups`
--

DROP TABLE IF EXISTS `user_power_ups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_power_ups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `power_up_id` int NOT NULL,
  `quantity` int DEFAULT NULL,
  `purchased_at` datetime DEFAULT NULL,
  `used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `power_up_id` (`power_up_id`),
  CONSTRAINT `user_power_ups_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_power_ups_ibfk_2` FOREIGN KEY (`power_up_id`) REFERENCES `power_ups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_power_ups`
--

LOCK TABLES `user_power_ups` WRITE;
/*!40000 ALTER TABLE `user_power_ups` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_power_ups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_progress`
--

DROP TABLE IF EXISTS `user_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `total_quizzes_taken` int DEFAULT '0',
  `total_questions_answered` int DEFAULT '0',
  `correct_answers` int DEFAULT '0',
  `total_game_sessions` int DEFAULT '0',
  `total_game_score` int DEFAULT '0',
  `total_videos_watched` int DEFAULT '0',
  `videos_completed` int DEFAULT '0',
  `current_streak_days` int DEFAULT '0',
  `longest_streak_days` int DEFAULT '0',
  `last_activity_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_progress`
--

LOCK TABLES `user_progress` WRITE;
/*!40000 ALTER TABLE `user_progress` DISABLE KEYS */;
INSERT INTO `user_progress` VALUES (1,1,0,0,0,0,0,0,0,0,0,'2025-06-20'),(3,3,0,0,0,0,0,0,0,0,0,NULL),(4,4,0,0,0,0,0,0,0,0,0,NULL),(5,5,0,0,0,0,0,0,0,0,0,NULL),(6,7,0,0,0,0,0,0,0,0,0,NULL);
/*!40000 ALTER TABLE `user_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_skill_profiles`
--

DROP TABLE IF EXISTS `user_skill_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_skill_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `category` varchar(100) NOT NULL,
  `subcategory` varchar(100) DEFAULT NULL,
  `accuracy_score` float DEFAULT NULL,
  `confidence_score` float DEFAULT NULL,
  `learning_rate` float DEFAULT NULL,
  `difficulty_preference` float DEFAULT NULL,
  `avg_response_time` float DEFAULT NULL,
  `response_time_variance` float DEFAULT NULL,
  `questions_attempted` int DEFAULT NULL,
  `questions_correct` int DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_skill_uc` (`user_id`,`category`,`subcategory`),
  KEY `idx_user_skill_category` (`user_id`,`category`),
  CONSTRAINT `user_skill_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_skill_profiles`
--

LOCK TABLES `user_skill_profiles` WRITE;
/*!40000 ALTER TABLE `user_skill_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_skill_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_subscriptions`
--

DROP TABLE IF EXISTS `user_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `plan_id` int NOT NULL,
  `status` enum('active','cancelled','expired','pending') DEFAULT 'active',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `auto_renew` tinyint(1) DEFAULT '1',
  `next_billing_date` date DEFAULT NULL,
  `stripe_subscription_id` varchar(255) DEFAULT NULL,
  `payment_method_id` varchar(255) DEFAULT NULL,
  `is_trial` tinyint(1) DEFAULT '0',
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `cancelled_reason` text,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `plan_id` (`plan_id`),
  CONSTRAINT `user_subscriptions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_subscriptions_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_subscriptions`
--

LOCK TABLES `user_subscriptions` WRITE;
/*!40000 ALTER TABLE `user_subscriptions` DISABLE KEYS */;
INSERT INTO `user_subscriptions` VALUES (1,1,3,'active','2025-06-05 22:10:04','2025-07-05 22:10:04',NULL,1,'2025-07-05',NULL,NULL,0,NULL,NULL,NULL,'2025-06-20 22:10:04','2025-06-20 22:10:04'),(2,3,2,'active','2025-06-20 23:15:17','2025-07-20 23:15:17',NULL,1,'2025-07-21',NULL,NULL,0,NULL,NULL,NULL,'2025-06-20 23:15:17','2025-06-20 23:15:17');
/*!40000 ALTER TABLE `user_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `profile_picture` varchar(255) DEFAULT NULL,
  `preferred_language` varchar(10) DEFAULT 'no',
  `total_xp` int NOT NULL DEFAULT '0',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `subscription_tier` varchar(20) DEFAULT 'free',
  `current_plan_id` int NOT NULL DEFAULT '1',
  `subscription_status` enum('active','cancelled','expired','trial') DEFAULT 'active',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `current_plan_id` (`current_plan_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`current_plan_id`) REFERENCES `subscription_plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'viktor','viktorandreas@hotmail.com','pbkdf2:sha256:600000$1zg4PLmiqrrB7Mh8$67aac70d24556700e90b222045d1cf59c5be3cf95bca1f4c4ef9a6aa9f383916','Administrator','1997-08-06','2025-06-20 22:34:01','2025-06-23 12:21:44',1,NULL,'no',0,1,'free',3,'active',1),(3,'test','viktor@iberiangreenline.com','pbkdf2:sha256:600000$kGWwIFMBVawJAKp4$f98e2c9ffefd2f10d1b587de9fe276b03c799e6c6400e964a08e68dd49c95637','test',NULL,'2025-06-20 23:03:06','2025-06-20 23:12:52',1,NULL,'no',0,1,'free',2,'active',0),(4,'newuser','newuser@example.com','pbkdf2:sha256:600000$DA6DiHWNduAaJ89e$e570f651be5278946be6bc7c7203e615a007ecccc5156c57972abf3336a4ce8c','New User',NULL,'2025-06-22 17:32:33',NULL,1,NULL,'no',0,0,'free',1,'active',0),(5,'testlogin','testlogin@example.com','pbkdf2:sha256:600000$PIOZuJEhcOCb4rjW$9c0ce283af3823392cd738141c9e26c12cf66b4a0bdc717da5a6e5546348d2e2','Test Login',NULL,'2025-06-22 17:32:33','2025-06-22 17:32:33',1,NULL,'no',0,1,'free',1,'active',0),(7,'testuser','test@example.com','pbkdf2:sha256:600000$BG4J4zzngmsr8YoM$b2a5eac1a1dc56bc9969cb9f6a11d23c41936e9916829bac0c2fbc913333331b','Test User',NULL,'2025-06-22 17:32:34',NULL,1,NULL,'no',0,1,'free',1,'active',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_bookmarks`
--

DROP TABLE IF EXISTS `video_bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_bookmarks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `video_id` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_video_bookmark_uc` (`user_id`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `video_bookmarks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `video_bookmarks_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_bookmarks`
--

LOCK TABLES `video_bookmarks` WRITE;
/*!40000 ALTER TABLE `video_bookmarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_bookmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_categories`
--

DROP TABLE IF EXISTS `video_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(100) DEFAULT NULL,
  `order_index` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_categories`
--

LOCK TABLES `video_categories` WRITE;
/*!40000 ALTER TABLE `video_categories` DISABLE KEYS */;
INSERT INTO `video_categories` VALUES (1,'Grunnleggende Trafikkregler','Lær de viktigste trafikkreglene','fa-traffic-light',1),(2,'Trafikkskilt','Forstå alle typer trafikkskilt','fa-sign',2),(3,'Kjøreteknikk','Praktiske kjøretips og teknikker','fa-car',3),(4,'Sikkerhet','Trafikksikkerhet og risikovurdering','fa-shield-alt',4),(5,'Førstehjelp','Grunnleggende førstehjelp ved ulykker','fa-first-aid',5);
/*!40000 ALTER TABLE `video_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_checkpoints`
--

DROP TABLE IF EXISTS `video_checkpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_checkpoints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `video_id` int NOT NULL,
  `timestamp_seconds` int NOT NULL,
  `question_id` int DEFAULT NULL,
  `is_mandatory` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `video_id` (`video_id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `video_checkpoints_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `video_checkpoints_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_checkpoints`
--

LOCK TABLES `video_checkpoints` WRITE;
/*!40000 ALTER TABLE `video_checkpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_checkpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_notes`
--

DROP TABLE IF EXISTS `video_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `video_id` int NOT NULL,
  `timestamp_seconds` int NOT NULL,
  `note_text` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `video_notes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `video_notes_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_notes`
--

LOCK TABLES `video_notes` WRITE;
/*!40000 ALTER TABLE `video_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_playlists`
--

DROP TABLE IF EXISTS `video_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_playlists` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text,
  `thumbnail_url` varchar(500) DEFAULT NULL,
  `is_official` tinyint(1) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `video_playlists_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_playlists`
--

LOCK TABLES `video_playlists` WRITE;
/*!40000 ALTER TABLE `video_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_progress`
--

DROP TABLE IF EXISTS `video_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `video_id` int NOT NULL,
  `last_position_seconds` int DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `checkpoints_passed` int DEFAULT '0',
  `total_checkpoints` int DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_video` (`user_id`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `video_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `video_progress_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_progress`
--

LOCK TABLES `video_progress` WRITE;
/*!40000 ALTER TABLE `video_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_ratings`
--

DROP TABLE IF EXISTS `video_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_ratings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `video_id` int NOT NULL,
  `rating` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_video_rating_uc` (`user_id`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `video_ratings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `video_ratings_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`),
  CONSTRAINT `_rating_range_check` CHECK (((`rating` >= 1) and (`rating` <= 5)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_ratings`
--

LOCK TABLES `video_ratings` WRITE;
/*!40000 ALTER TABLE `video_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_subtitles`
--

DROP TABLE IF EXISTS `video_subtitles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_subtitles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `video_id` int NOT NULL,
  `language_code` varchar(10) NOT NULL,
  `subtitle_file` varchar(255) DEFAULT NULL,
  `is_auto_generated` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_video_language_uc` (`video_id`,`language_code`),
  CONSTRAINT `video_subtitles_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_subtitles`
--

LOCK TABLES `video_subtitles` WRITE;
/*!40000 ALTER TABLE `video_subtitles` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_subtitles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `filename` varchar(255) DEFAULT NULL,
  `youtube_url` varchar(255) DEFAULT NULL,
  `duration_seconds` int DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `difficulty_level` int DEFAULT '1',
  `order_index` int DEFAULT NULL,
  `thumbnail_filename` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) DEFAULT '1',
  `view_count` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `videos_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `video_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
INSERT INTO `videos` VALUES (1,'Grunnleggende Trafikkregler','Introduksjon til de viktigste trafikkreglene i Norge',NULL,'https://youtube.com/watch?v=example1',480,'Trafikkregler',1,1,1,'thumb_trafikkregler.jpg','2025-06-20 22:36:14',1,0),(2,'Trafikkskilt - Del 1','Lær de mest vanlige trafikkskiltene',NULL,'https://youtube.com/watch?v=example2',360,'Trafikkskilt',2,1,1,'thumb_skilt1.jpg','2025-06-20 22:36:14',1,0),(3,'Sikker Kjøring i By','Tips for trygg kjøring i tettbebygde områder',NULL,'https://youtube.com/watch?v=example3',600,'Kjøreteknikk',3,2,1,'thumb_by_kjoring.jpg','2025-06-20 22:36:14',1,0),(4,'Førstehjelp ved Trafikkulykker','Grunnleggende førstehjelp du bør kunne',NULL,'https://youtube.com/watch?v=example4',720,'Førstehjelp',5,2,1,'thumb_forstehjelp.jpg','2025-06-20 22:36:14',1,0),(5,'Avanserte Kjøreteknikker','Teknikker for erfarne sjåfører',NULL,'https://youtube.com/watch?v=example5',900,'Kjøreteknikk',3,3,2,'thumb_avansert.jpg','2025-06-20 22:36:14',1,0);
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekly_tournaments`
--

DROP TABLE IF EXISTS `weekly_tournaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weekly_tournaments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text,
  `tournament_type` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `entry_fee_xp` int DEFAULT NULL,
  `prize_pool_xp` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekly_tournaments`
--

LOCK TABLES `weekly_tournaments` WRITE;
/*!40000 ALTER TABLE `weekly_tournaments` DISABLE KEYS */;
/*!40000 ALTER TABLE `weekly_tournaments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xp_transactions`
--

DROP TABLE IF EXISTS `xp_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xp_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `amount` int NOT NULL,
  `transaction_type` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `reference_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `xp_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xp_transactions`
--

LOCK TABLES `xp_transactions` WRITE;
/*!40000 ALTER TABLE `xp_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `xp_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sertifikatet'
--

--
-- Dumping routines for database 'sertifikatet'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-23 20:27:11

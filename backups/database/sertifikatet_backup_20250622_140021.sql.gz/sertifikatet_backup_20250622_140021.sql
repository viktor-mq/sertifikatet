-- MySQL dump 10.13  Distrib 9.3.0, for macos15.2 (arm64)
--
-- Host: localhost    Database: sertifikatet
-- ------------------------------------------------------
-- Server version	9.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `achievements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `icon_filename` varchar(255) DEFAULT NULL,
  `points` int DEFAULT '10',
  `category` varchar(50) DEFAULT NULL,
  `requirement_type` varchar(50) DEFAULT NULL,
  `requirement_value` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `achievements`
--

LOCK TABLES `achievements` WRITE;
/*!40000 ALTER TABLE `achievements` DISABLE KEYS */;
INSERT INTO `achievements` VALUES (1,'Første Quiz','Fullført din første quiz','first_quiz.png',10,'quiz','quiz_count',1),(2,'Quiz Mester','Fullført 10 quiz','quiz_master.png',50,'quiz','quiz_count',10),(3,'Perfekt Score','Oppnådde 100% på en quiz','perfect_score.png',25,'quiz','perfect_score',1),(4,'Uke Streak','Tok quiz 7 dager på rad','week_streak.png',30,'streak','streak_days',7),(5,'Måned Streak','Tok quiz 30 dager på rad','month_streak.png',100,'streak','streak_days',30),(6,'Video Lærer','Så 5 instruksjonsvideoer','video_learner.png',20,'video','videos_watched',5),(7,'Spill Entusiast','Spilte 10 spill','game_enthusiast.png',40,'game','games_played',10),(8,'Kunnskapssøker','Besvarte 100 spørsmål','knowledge_seeker.png',60,'quiz','questions_answered',100),(9,'Ekspert','Besvarte 500 spørsmål','expert.png',200,'quiz','questions_answered',500),(10,'Trafikkskilt Mester','Fullført alle trafikkskilt kategorier','signs_master.png',75,'category','category_complete',1);
/*!40000 ALTER TABLE `achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adaptive_quiz_sessions`
--

DROP TABLE IF EXISTS `adaptive_quiz_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adaptive_quiz_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `quiz_session_id` int NOT NULL,
  `algorithm_version` varchar(50) DEFAULT NULL,
  `target_difficulty` float DEFAULT NULL,
  `adaptation_strength` float DEFAULT NULL,
  `initial_skill_estimate` float DEFAULT NULL,
  `final_skill_estimate` float DEFAULT NULL,
  `skill_improvement` float DEFAULT NULL,
  `questions_above_skill` int DEFAULT NULL,
  `questions_below_skill` int DEFAULT NULL,
  `questions_optimal` int DEFAULT NULL,
  `average_engagement_score` float DEFAULT NULL,
  `frustration_indicators` int DEFAULT NULL,
  `confidence_trend` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `quiz_session_id` (`quiz_session_id`),
  CONSTRAINT `adaptive_quiz_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `adaptive_quiz_sessions_ibfk_2` FOREIGN KEY (`quiz_session_id`) REFERENCES `quiz_sessions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adaptive_quiz_sessions`
--

LOCK TABLES `adaptive_quiz_sessions` WRITE;
/*!40000 ALTER TABLE `adaptive_quiz_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `adaptive_quiz_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_audit_log`
--

DROP TABLE IF EXISTS `admin_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_user_id` int NOT NULL,
  `admin_user_id` int DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `additional_info` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `target_user_id` (`target_user_id`),
  KEY `admin_user_id` (`admin_user_id`),
  CONSTRAINT `admin_audit_log_ibfk_1` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `admin_audit_log_ibfk_2` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_audit_log`
--

LOCK TABLES `admin_audit_log` WRITE;
/*!40000 ALTER TABLE `admin_audit_log` DISABLE KEYS */;
INSERT INTO `admin_audit_log` VALUES (1,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:43:28'),(2,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:45:36'),(3,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:33'),(4,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:36'),(5,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:41'),(6,1,1,'ml_system_activate','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','\"{\\\"success\\\": true}\"','2025-06-20 21:46:41'),(7,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:41'),(8,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:50'),(9,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:46:52'),(10,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:47:22'),(11,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:54:31'),(12,1,NULL,'admin_login_success','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','{\"success\": true}','2025-06-20 21:54:34');
/*!40000 ALTER TABLE `admin_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_reports`
--

DROP TABLE IF EXISTS `admin_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `report_type` varchar(50) NOT NULL,
  `priority` varchar(20) DEFAULT 'medium',
  `status` varchar(20) DEFAULT 'new',
  `title` varchar(255) NOT NULL,
  `description` text,
  `reported_by_user_id` int DEFAULT NULL,
  `affected_user_id` int DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `url` text,
  `error_message` text,
  `stack_trace` text,
  `metadata_json` text,
  `screenshot_filename` varchar(255) DEFAULT NULL,
  `assigned_to_user_id` int DEFAULT NULL,
  `resolved_by_user_id` int DEFAULT NULL,
  `resolution_notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `resolved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reported_by_user_id` (`reported_by_user_id`),
  KEY `affected_user_id` (`affected_user_id`),
  KEY `assigned_to_user_id` (`assigned_to_user_id`),
  KEY `resolved_by_user_id` (`resolved_by_user_id`),
  CONSTRAINT `admin_reports_ibfk_1` FOREIGN KEY (`reported_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `admin_reports_ibfk_2` FOREIGN KEY (`affected_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `admin_reports_ibfk_3` FOREIGN KEY (`assigned_to_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `admin_reports_ibfk_4` FOREIGN KEY (`resolved_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_reports`
--

LOCK TABLES `admin_reports` WRITE;
/*!40000 ALTER TABLE `admin_reports` DISABLE KEYS */;
INSERT INTO `admin_reports` VALUES (1,'unexpected_error','medium','new','Application Error: OperationalError','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','http://127.0.0.1:8000/api/leaderboard?type=weekly&category=overall&limit=20','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\npymysql.err.OperationalError: (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/api/routes.py\", line 212, in get_leaderboard\n    leaderboard = leaderboard_service.get_leaderboard(\n                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/services/leaderboard_service.py\", line 170, in get_leaderboard\n    ).limit(limit).all()\n                   ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2688, in all\n    return self._iter().all()  # type: ignore\n           ^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2842, in _iter\n    result: Union[ScalarResult[_T], Result[_T]] = self.session.execute(\n                                                  ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2262, in execute\n    return self._execute_internal(\n           ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2144, in _execute_internal\n    result: Result[Any] = compile_state_cls.orm_execute_statement(\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/context.py\", line 293, in orm_execute_statement\n    result = conn.execute(\n             ^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1412, in execute\n    return meth(\n           ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/sql/elements.py\", line 515, in _execute_on_connection\n    return connection._execute_clauseelement(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1635, in _execute_clauseelement\n    ret = self._execute_context(\n          ^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1844, in _execute_context\n    return self._exec_single_context(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1984, in _exec_single_context\n    self._handle_dbapi_exception(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 2339, in _handle_dbapi_exception\n    raise sqlalchemy_exception.with_traceback(exc_info[2]) from e\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\nsqlalchemy.exc.OperationalError: (pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 21:40:51','2025-06-20 21:40:51',NULL),(2,'unexpected_error','medium','new','Application Error: OperationalError','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at \nFROM leaderboard_entries \nWHERE leaderboard_entries.user_id = %(user_id_1)s AND leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s \n LIMIT %(param_1)s]\n[parameters: {\'user_id_1\': 1, \'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 1}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15','http://127.0.0.1:8000/api/leaderboard/user-rank?type=weekly&category=overall','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at \nFROM leaderboard_entries \nWHERE leaderboard_entries.user_id = %(user_id_1)s AND leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s \n LIMIT %(param_1)s]\n[parameters: {\'user_id_1\': 1, \'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 1}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\npymysql.err.OperationalError: (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/api/routes.py\", line 245, in get_user_rank\n    user_rank = leaderboard_service.get_user_rank(\n                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/services/leaderboard_service.py\", line 196, in get_user_rank\n    ).first()\n      ^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2743, in first\n    return self.limit(1)._iter().first()  # type: ignore\n           ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2842, in _iter\n    result: Union[ScalarResult[_T], Result[_T]] = self.session.execute(\n                                                  ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2262, in execute\n    return self._execute_internal(\n           ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2144, in _execute_internal\n    result: Result[Any] = compile_state_cls.orm_execute_statement(\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/context.py\", line 293, in orm_execute_statement\n    result = conn.execute(\n             ^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1412, in execute\n    return meth(\n           ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/sql/elements.py\", line 515, in _execute_on_connection\n    return connection._execute_clauseelement(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1635, in _execute_clauseelement\n    ret = self._execute_context(\n          ^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1844, in _execute_context\n    return self._exec_single_context(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1984, in _exec_single_context\n    self._handle_dbapi_exception(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 2339, in _handle_dbapi_exception\n    raise sqlalchemy_exception.with_traceback(exc_info[2]) from e\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\nsqlalchemy.exc.OperationalError: (pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at \nFROM leaderboard_entries \nWHERE leaderboard_entries.user_id = %(user_id_1)s AND leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s \n LIMIT %(param_1)s]\n[parameters: {\'user_id_1\': 1, \'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 1}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 21:40:51','2025-06-20 21:40:51',NULL),(3,'unexpected_error','medium','new','Application Error: ImportError','cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/auth/register','cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/auth/routes.py\", line 76, in register\n    from app.models import Plan\nImportError: cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 22:56:23','2025-06-20 22:56:23',NULL),(4,'unexpected_error','medium','new','Application Error: ImportError','cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/auth/register','cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/auth/routes.py\", line 76, in register\n    from app.models import Plan\nImportError: cannot import name \'Plan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 22:57:12','2025-06-20 22:57:12',NULL),(5,'unexpected_error','medium','new','Application Error: ImportError','cannot import name \'SubscriptionPlan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/auth/register','cannot import name \'SubscriptionPlan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/auth/routes.py\", line 76, in register\n    from ..models import SubscriptionPlan\nImportError: cannot import name \'SubscriptionPlan\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 22:58:07','2025-06-20 22:58:07',NULL),(6,'unexpected_error','medium','new','Application Error: ImportError','cannot import name \'subscription_tier\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/auth/register','cannot import name \'subscription_tier\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/auth/routes.py\", line 76, in register\n    from ..models import subscription_tier\nImportError: cannot import name \'subscription_tier\' from \'app.models\' (/Users/viktorigesund/Documents/teoritest/app/models.py)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 23:01:36','2025-06-20 23:01:36',NULL),(7,'unexpected_error','medium','new','Application Error: OperationalError','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','http://localhost:8000/api/leaderboard?type=weekly&category=overall&limit=20','(pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)','Traceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\npymysql.err.OperationalError: (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1484, in full_dispatch_request\n    rv = self.dispatch_request()\n         ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/flask/app.py\", line 1469, in dispatch_request\n    return self.ensure_sync(self.view_functions[rule.endpoint])(**view_args)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/api/routes.py\", line 212, in get_leaderboard\n    leaderboard = leaderboard_service.get_leaderboard(\n                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/app/services/leaderboard_service.py\", line 170, in get_leaderboard\n    ).limit(limit).all()\n                   ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2688, in all\n    return self._iter().all()  # type: ignore\n           ^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/query.py\", line 2842, in _iter\n    result: Union[ScalarResult[_T], Result[_T]] = self.session.execute(\n                                                  ^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2262, in execute\n    return self._execute_internal(\n           ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/session.py\", line 2144, in _execute_internal\n    result: Result[Any] = compile_state_cls.orm_execute_statement(\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/orm/context.py\", line 293, in orm_execute_statement\n    result = conn.execute(\n             ^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1412, in execute\n    return meth(\n           ^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/sql/elements.py\", line 515, in _execute_on_connection\n    return connection._execute_clauseelement(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1635, in _execute_clauseelement\n    ret = self._execute_context(\n          ^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1844, in _execute_context\n    return self._exec_single_context(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1984, in _exec_single_context\n    self._handle_dbapi_exception(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 2339, in _handle_dbapi_exception\n    raise sqlalchemy_exception.with_traceback(exc_info[2]) from e\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/base.py\", line 1965, in _exec_single_context\n    self.dialect.do_execute(\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/sqlalchemy/engine/default.py\", line 921, in do_execute\n    cursor.execute(statement, parameters)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 158, in execute\n    result = self._query(query)\n             ^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/cursors.py\", line 325, in _query\n    conn.query(q)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 549, in query\n    self._affected_rows = self._read_query_result(unbuffered=unbuffered)\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 779, in _read_query_result\n    result.read()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 1157, in read\n    first_packet = self.connection._read_packet()\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/connections.py\", line 729, in _read_packet\n    packet.raise_for_error()\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/protocol.py\", line 221, in raise_for_error\n    err.raise_mysql_exception(self._data)\n  File \"/Users/viktorigesund/Documents/teoritest/venv/lib/python3.11/site-packages/pymysql/err.py\", line 143, in raise_mysql_exception\n    raise errorclass(errno, errval)\nsqlalchemy.exc.OperationalError: (pymysql.err.OperationalError) (1054, \"Unknown column \'leaderboard_entries.rank\' in \'field list\'\")\n[SQL: SELECT leaderboard_entries.id AS leaderboard_entries_id, leaderboard_entries.user_id AS leaderboard_entries_user_id, leaderboard_entries.leaderboard_type AS leaderboard_entries_leaderboard_type, leaderboard_entries.category AS leaderboard_entries_category, leaderboard_entries.score AS leaderboard_entries_score, leaderboard_entries.`rank` AS leaderboard_entries_rank, leaderboard_entries.period_start AS leaderboard_entries_period_start, leaderboard_entries.period_end AS leaderboard_entries_period_end, leaderboard_entries.created_at AS leaderboard_entries_created_at, users.id AS users_id, users.username AS users_username, users.email AS users_email, users.password_hash AS users_password_hash, users.full_name AS users_full_name, users.date_of_birth AS users_date_of_birth, users.created_at AS users_created_at, users.last_login AS users_last_login, users.is_active AS users_is_active, users.profile_picture AS users_profile_picture, users.preferred_language AS users_preferred_language, users.total_xp AS users_total_xp, users.is_verified AS users_is_verified, users.subscription_tier AS users_subscription_tier, users.current_plan_id AS users_current_plan_id, users.subscription_status AS users_subscription_status, users.is_admin AS users_is_admin \nFROM leaderboard_entries INNER JOIN users ON leaderboard_entries.user_id = users.id \nWHERE leaderboard_entries.leaderboard_type = %(leaderboard_type_1)s AND leaderboard_entries.category = %(category_1)s AND leaderboard_entries.period_start = %(period_start_1)s AND leaderboard_entries.period_end = %(period_end_1)s ORDER BY leaderboard_entries.`rank` \n LIMIT %(param_1)s]\n[parameters: {\'leaderboard_type_1\': \'weekly\', \'category_1\': \'overall\', \'period_start_1\': datetime.datetime(2025, 6, 16, 0, 0), \'period_end_1\': datetime.datetime(2025, 6, 23, 0, 0), \'param_1\': 20}]\n(Background on this error at: https://sqlalche.me/e/20/e3q8)\n',NULL,NULL,NULL,NULL,NULL,'2025-06-20 23:15:43','2025-06-20 23:15:43',NULL);
/*!40000 ALTER TABLE `admin_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badge_categories`
--

DROP TABLE IF EXISTS `badge_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `badge_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `icon` varchar(100) DEFAULT NULL,
  `order_index` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badge_categories`
--

LOCK TABLES `badge_categories` WRITE;
/*!40000 ALTER TABLE `badge_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `badge_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_addresses`
--

DROP TABLE IF EXISTS `billing_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_addresses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) DEFAULT NULL,
  `city` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `country` varchar(2) DEFAULT NULL,
  `organization_number` varchar(20) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_billing_user` (`user_id`),
  CONSTRAINT `billing_addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_addresses`
--

LOCK TABLES `billing_addresses` WRITE;
/*!40000 ALTER TABLE `billing_addresses` DISABLE KEYS */;
INSERT INTO `billing_addresses` VALUES (1,3,NULL,'test','test','','Oslo','0195','NO',NULL,1,1,'2025-06-21 00:15:17','2025-06-21 00:15:17');
/*!40000 ALTER TABLE `billing_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_challenges`
--

DROP TABLE IF EXISTS `daily_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_challenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text,
  `challenge_type` varchar(50) DEFAULT NULL,
  `requirement_value` int DEFAULT NULL,
  `xp_reward` int DEFAULT NULL,
  `bonus_reward` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_challenges`
--

LOCK TABLES `daily_challenges` WRITE;
/*!40000 ALTER TABLE `daily_challenges` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_codes`
--

DROP TABLE IF EXISTS `discount_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `discount_type` varchar(20) NOT NULL,
  `discount_value` decimal(10,2) DEFAULT NULL,
  `free_trial_days` int DEFAULT NULL,
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `max_uses` int DEFAULT NULL,
  `current_uses` int DEFAULT NULL,
  `min_purchase_amount` decimal(10,2) DEFAULT NULL,
  `applicable_plans` varchar(255) DEFAULT NULL,
  `first_time_users_only` tinyint(1) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_by_user_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `discount_codes_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_codes`
--

LOCK TABLES `discount_codes` WRITE;
/*!40000 ALTER TABLE `discount_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_usage`
--

DROP TABLE IF EXISTS `discount_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_usage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code_id` int NOT NULL,
  `user_id` int NOT NULL,
  `payment_id` int DEFAULT NULL,
  `discount_amount` decimal(10,2) DEFAULT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_code_user_payment_uc` (`code_id`,`user_id`,`payment_id`),
  KEY `user_id` (`user_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `discount_usage_ibfk_1` FOREIGN KEY (`code_id`) REFERENCES `discount_codes` (`id`),
  CONSTRAINT `discount_usage_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `discount_usage_ibfk_3` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_usage`
--

LOCK TABLES `discount_usage` WRITE;
/*!40000 ALTER TABLE `discount_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enhanced_quiz_responses`
--

DROP TABLE IF EXISTS `enhanced_quiz_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enhanced_quiz_responses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quiz_response_id` int NOT NULL,
  `user_confidence_level` float DEFAULT NULL,
  `difficulty_perception` float DEFAULT NULL,
  `cognitive_load_score` float DEFAULT NULL,
  `time_to_first_answer` float DEFAULT NULL,
  `answer_change_count` int DEFAULT NULL,
  `hesitation_score` float DEFAULT NULL,
  `question_order_in_session` int DEFAULT NULL,
  `user_fatigue_score` float DEFAULT NULL,
  `predicted_difficulty` float DEFAULT NULL,
  `actual_difficulty` float DEFAULT NULL,
  `knowledge_gain_estimate` float DEFAULT NULL,
  `skill_level_before` float DEFAULT NULL,
  `skill_level_after` float DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quiz_response_id` (`quiz_response_id`),
  CONSTRAINT `enhanced_quiz_responses_ibfk_1` FOREIGN KEY (`quiz_response_id`) REFERENCES `quiz_responses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enhanced_quiz_responses`
--

LOCK TABLES `enhanced_quiz_responses` WRITE;
/*!40000 ALTER TABLE `enhanced_quiz_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `enhanced_quiz_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friend_challenges`
--

DROP TABLE IF EXISTS `friend_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `friend_challenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `challenger_id` int NOT NULL,
  `challenged_id` int NOT NULL,
  `challenge_type` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `wager_xp` int DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `winner_id` int DEFAULT NULL,
  `challenger_score` int DEFAULT NULL,
  `challenged_score` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `challenger_id` (`challenger_id`),
  KEY `challenged_id` (`challenged_id`),
  KEY `winner_id` (`winner_id`),
  CONSTRAINT `friend_challenges_ibfk_1` FOREIGN KEY (`challenger_id`) REFERENCES `users` (`id`),
  CONSTRAINT `friend_challenges_ibfk_2` FOREIGN KEY (`challenged_id`) REFERENCES `users` (`id`),
  CONSTRAINT `friend_challenges_ibfk_3` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friend_challenges`
--

LOCK TABLES `friend_challenges` WRITE;
/*!40000 ALTER TABLE `friend_challenges` DISABLE KEYS */;
/*!40000 ALTER TABLE `friend_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_scenarios`
--

DROP TABLE IF EXISTS `game_scenarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_scenarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text,
  `scenario_type` varchar(50) DEFAULT NULL,
  `difficulty_level` int DEFAULT '1',
  `max_score` int DEFAULT '100',
  `time_limit_seconds` int DEFAULT NULL,
  `config_json` text,
  `template_name` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `order_index` int DEFAULT '0',
  `min_level_required` int DEFAULT '1',
  `is_premium` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_scenarios`
--

LOCK TABLES `game_scenarios` WRITE;
/*!40000 ALTER TABLE `game_scenarios` DISABLE KEYS */;
INSERT INTO `game_scenarios` VALUES (1,'Trafikkskilt Quiz','Identifiser forskjellige trafikkskilt','traffic_signs',1,100,300,'{\"signs_count\": 10, \"time_per_sign\": 30}','traffic_signs_game.html',1,1,1,0),(2,'Kjøreregler Test','Test din kunnskap om kjøreregler','driving_rules',2,150,600,'{\"questions_count\": 15, \"time_per_question\": 40}','rules_game.html',1,2,1,0),(3,'Minnespill - Skilt','Husk sekvenser av trafikkskilt','memory',1,80,240,'{\"sequence_length\": 5, \"show_time\": 2}','memory_game.html',1,3,1,0),(4,'Tidsutfordring','Svar på flest mulig spørsmål på tid','time_challenge',3,200,180,'{\"difficulty\": \"mixed\", \"bonus_time\": 5}','time_challenge.html',1,4,5,1),(5,'Kjøresimulator','Virtuell kjøreøvelse','driving_sim',3,300,900,'{\"scenario\": \"city_driving\", \"weather\": \"normal\"}','driving_sim.html',1,5,10,1);
/*!40000 ALTER TABLE `game_scenarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_sessions`
--

DROP TABLE IF EXISTS `game_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `scenario_id` int NOT NULL,
  `score` int DEFAULT NULL,
  `time_played_seconds` int DEFAULT NULL,
  `mistakes_count` int DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `scenario_id` (`scenario_id`),
  CONSTRAINT `game_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `game_sessions_ibfk_2` FOREIGN KEY (`scenario_id`) REFERENCES `game_scenarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_sessions`
--

LOCK TABLES `game_sessions` WRITE;
/*!40000 ALTER TABLE `game_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leaderboard_entries`
--

DROP TABLE IF EXISTS `leaderboard_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leaderboard_entries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `leaderboard_type` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `score` int DEFAULT NULL,
  `rank_position` int DEFAULT NULL,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `leaderboard_entries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaderboard_entries`
--

LOCK TABLES `leaderboard_entries` WRITE;
/*!40000 ALTER TABLE `leaderboard_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `leaderboard_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learning_analytics`
--

DROP TABLE IF EXISTS `learning_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learning_analytics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `date` date NOT NULL,
  `total_study_time_minutes` int DEFAULT NULL,
  `questions_attempted` int DEFAULT NULL,
  `questions_correct` int DEFAULT NULL,
  `average_difficulty_attempted` float DEFAULT NULL,
  `avg_response_time` float DEFAULT NULL,
  `response_time_consistency` float DEFAULT NULL,
  `mistakes_per_session` float DEFAULT NULL,
  `learning_velocity` float DEFAULT NULL,
  `knowledge_retention` float DEFAULT NULL,
  `concept_mastery_score` float DEFAULT NULL,
  `preferred_study_duration` int DEFAULT NULL,
  `optimal_question_difficulty` float DEFAULT NULL,
  `learning_style_indicators` text,
  `weakest_categories` text,
  `strength_categories` text,
  `recommended_study_time` int DEFAULT NULL,
  `recommended_difficulty` float DEFAULT NULL,
  `priority_topics` text,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_date_analytics_uc` (`user_id`,`date`),
  KEY `idx_analytics_user_date` (`user_id`,`date`),
  KEY `idx_analytics_date` (`date`),
  CONSTRAINT `learning_analytics_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learning_analytics`
--

LOCK TABLES `learning_analytics` WRITE;
/*!40000 ALTER TABLE `learning_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `learning_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learning_path_items`
--

DROP TABLE IF EXISTS `learning_path_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learning_path_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `path_id` int NOT NULL,
  `item_type` varchar(50) DEFAULT NULL,
  `item_id` int DEFAULT NULL,
  `order_index` int DEFAULT NULL,
  `is_mandatory` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `path_id` (`path_id`),
  CONSTRAINT `learning_path_items_ibfk_1` FOREIGN KEY (`path_id`) REFERENCES `learning_paths` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learning_path_items`
--

LOCK TABLES `learning_path_items` WRITE;
/*!40000 ALTER TABLE `learning_path_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `learning_path_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learning_paths`
--

DROP TABLE IF EXISTS `learning_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learning_paths` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text,
  `estimated_hours` int DEFAULT NULL,
  `difficulty_level` int DEFAULT '1',
  `icon_filename` varchar(255) DEFAULT NULL,
  `is_recommended` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learning_paths`
--

LOCK TABLES `learning_paths` WRITE;
/*!40000 ALTER TABLE `learning_paths` DISABLE KEYS */;
INSERT INTO `learning_paths` VALUES (1,'Nybegynner Pakke','Alt du trenger for å starte',8,1,'beginner_path.png',1),(2,'Trafikkskilt Mester','Lær alle trafikkskilt',4,2,'signs_path.png',1),(3,'Kjøreregler Ekspert','Dyp forståelse av alle regler',6,2,'rules_path.png',0),(4,'Komplett Forberedelse','Full forberedelse til førerprøven',12,3,'complete_path.png',1);
/*!40000 ALTER TABLE `learning_paths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_email_logs`
--

DROP TABLE IF EXISTS `marketing_email_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_email_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `marketing_email_id` int NOT NULL,
  `user_id` int NOT NULL,
  `recipient_email` varchar(255) NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `error_message` text,
  `provider_response` text,
  `opened_at` datetime DEFAULT NULL,
  `clicked_at` datetime DEFAULT NULL,
  `unsubscribed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_marketing_email_user_uc` (`marketing_email_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `marketing_email_logs_ibfk_1` FOREIGN KEY (`marketing_email_id`) REFERENCES `marketing_emails` (`id`),
  CONSTRAINT `marketing_email_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_email_logs`
--

LOCK TABLES `marketing_email_logs` WRITE;
/*!40000 ALTER TABLE `marketing_email_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_email_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_emails`
--

DROP TABLE IF EXISTS `marketing_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_emails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `html_content` text NOT NULL,
  `target_all_opted_in` tinyint(1) DEFAULT NULL,
  `target_free_users` tinyint(1) DEFAULT NULL,
  `target_premium_users` tinyint(1) DEFAULT NULL,
  `target_pro_users` tinyint(1) DEFAULT NULL,
  `target_active_only` tinyint(1) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `recipients_count` int DEFAULT NULL,
  `sent_count` int DEFAULT NULL,
  `failed_count` int DEFAULT NULL,
  `created_by_user_id` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `marketing_emails_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_emails`
--

LOCK TABLES `marketing_emails` WRITE;
/*!40000 ALTER TABLE `marketing_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_templates`
--

DROP TABLE IF EXISTS `marketing_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `html_content` text NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `times_used` int DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `created_by_user_id` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `marketing_templates_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_templates`
--

LOCK TABLES `marketing_templates` WRITE;
/*!40000 ALTER TABLE `marketing_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_models`
--

DROP TABLE IF EXISTS `ml_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_models` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `version` varchar(50) NOT NULL,
  `description` text,
  `accuracy_score` float DEFAULT NULL,
  `precision_score` float DEFAULT NULL,
  `recall_score` float DEFAULT NULL,
  `f1_score` float DEFAULT NULL,
  `hyperparameters` text,
  `feature_importance` text,
  `is_active` tinyint(1) DEFAULT NULL,
  `total_predictions` int DEFAULT NULL,
  `last_retrained` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_model_version_uc` (`name`,`version`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `ml_models_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_models`
--

LOCK TABLES `ml_models` WRITE;
/*!40000 ALTER TABLE `ml_models` DISABLE KEYS */;
INSERT INTO `ml_models` VALUES (1,'skill_estimator','v1.0','Gradient Boosting model for estimating user skill levels',NULL,NULL,NULL,NULL,'{\"n_estimators\": 100, \"learning_rate\": 0.1, \"max_depth\": 6, \"random_state\": 42}',NULL,1,0,NULL,'2025-06-20 22:46:41',1),(2,'difficulty_predictor','v1.0','Random Forest model for predicting question difficulty',NULL,NULL,NULL,NULL,'{\"n_estimators\": 50, \"max_depth\": 8, \"random_state\": 42}',NULL,1,0,NULL,'2025-06-20 22:46:41',1);
/*!40000 ALTER TABLE `ml_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `options` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question_id` int NOT NULL,
  `option_letter` varchar(1) NOT NULL,
  `option_text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES (41,11,'a','30 km/t'),(42,11,'b','40 km/t'),(43,11,'c','50 km/t'),(44,11,'d','60 km/t'),(45,12,'a','Gir påbud'),(46,12,'b','Gir informasjon'),(47,12,'c','Forbyr noe'),(48,12,'d','Varsler om fare'),(49,13,'a','Stopp og gi forkjørsrett'),(50,13,'b','Kjør fort forbi'),(51,13,'c','Tut for å varsle'),(52,13,'d','Ignorer fotgjengere'),(53,14,'a','Du har alltid forkjørsrett'),(54,14,'b','Fotgjengere har forkjørsrett'),(55,14,'c','Trafikk inne har forkjørsrett'),(56,14,'d','Første bil inn har forkjørsrett'),(57,15,'a','1 sekund'),(58,15,'b','3 sekunder'),(59,15,'c','5 sekunder'),(60,15,'d','10 sekunder');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `subscription_id` int DEFAULT NULL,
  `plan_id` int NOT NULL,
  `amount_nok` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `stripe_payment_intent_id` varchar(255) DEFAULT NULL,
  `stripe_charge_id` varchar(255) DEFAULT NULL,
  `stripe_customer_id` varchar(255) DEFAULT NULL,
  `vipps_transaction_id` varchar(255) DEFAULT NULL,
  `bank_reference` varchar(100) DEFAULT NULL,
  `invoice_number` varchar(50) DEFAULT NULL,
  `invoice_pdf_path` varchar(255) DEFAULT NULL,
  `billing_name` varchar(255) DEFAULT NULL,
  `billing_email` varchar(255) DEFAULT NULL,
  `billing_address` text,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_postal_code` varchar(20) DEFAULT NULL,
  `billing_country` varchar(2) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `failure_reason` text,
  `refund_amount` decimal(10,2) DEFAULT NULL,
  `refund_reason` text,
  `refunded_at` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `metadata_json` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `subscription_id` (`subscription_id`),
  KEY `plan_id` (`plan_id`),
  KEY `idx_payment_date` (`payment_date`),
  KEY `idx_stripe_payment_intent` (`stripe_payment_intent_id`),
  KEY `idx_payment_user_status` (`user_id`,`status`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`subscription_id`) REFERENCES `user_subscriptions` (`id`),
  CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (3,3,NULL,2,149.00,'NOK','pending',NULL,NULL,NULL,NULL,NULL,NULL,'SERT-2025-000003',NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,NULL,NULL,NULL,NULL,'Upgrade to Premium Plan',NULL,'2025-06-21 00:13:16','2025-06-21 00:13:16'),(4,3,NULL,2,149.00,'NOK','completed','stripe_card','cs_test_a1AanjygZLO99Qt3yhqvwJByUkzWqdu4Wrh2YY5ZA372TTOLOmuQEyNSAt',NULL,'cus_SXJgHKymWbtm89',NULL,NULL,'SERT-2025-000004',NULL,NULL,NULL,NULL,NULL,NULL,'NO','2025-06-21 00:15:17',NULL,NULL,NULL,NULL,'Premium Plan subscription',NULL,'2025-06-21 00:13:16','2025-06-21 00:15:17');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist_items`
--

DROP TABLE IF EXISTS `playlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `playlist_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `playlist_id` int NOT NULL,
  `video_id` int NOT NULL,
  `order_index` int DEFAULT NULL,
  `added_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_playlist_video_uc` (`playlist_id`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `playlist_items_ibfk_1` FOREIGN KEY (`playlist_id`) REFERENCES `video_playlists` (`id`),
  CONSTRAINT `playlist_items_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist_items`
--

LOCK TABLES `playlist_items` WRITE;
/*!40000 ALTER TABLE `playlist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `playlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `power_ups`
--

DROP TABLE IF EXISTS `power_ups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `power_ups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `icon` varchar(100) DEFAULT NULL,
  `cost_xp` int NOT NULL,
  `effect_type` varchar(50) DEFAULT NULL,
  `effect_duration` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `power_ups`
--

LOCK TABLES `power_ups` WRITE;
/*!40000 ALTER TABLE `power_ups` DISABLE KEYS */;
/*!40000 ALTER TABLE `power_ups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_difficulty_profiles`
--

DROP TABLE IF EXISTS `question_difficulty_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_difficulty_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question_id` int NOT NULL,
  `computed_difficulty` float DEFAULT NULL,
  `discrimination_power` float DEFAULT NULL,
  `guess_factor` float DEFAULT NULL,
  `total_attempts` int DEFAULT NULL,
  `correct_attempts` int DEFAULT NULL,
  `avg_response_time` float DEFAULT NULL,
  `response_time_variance` float DEFAULT NULL,
  `skill_threshold` float DEFAULT NULL,
  `learning_value` float DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`),
  KEY `idx_question_difficulty` (`computed_difficulty`),
  KEY `idx_question_discrimination` (`discrimination_power`),
  CONSTRAINT `question_difficulty_profiles_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_difficulty_profiles`
--

LOCK TABLES `question_difficulty_profiles` WRITE;
/*!40000 ALTER TABLE `question_difficulty_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_difficulty_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_images`
--

DROP TABLE IF EXISTS `question_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_images` (
  `question_id` int NOT NULL,
  `image_id` int NOT NULL,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`question_id`,`image_id`,`role`),
  KEY `image_id` (`image_id`),
  CONSTRAINT `question_images_ibfk_1` FOREIGN KEY (`image_id`) REFERENCES `quiz_images` (`id`),
  CONSTRAINT `question_images_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_images`
--

LOCK TABLES `question_images` WRITE;
/*!40000 ALTER TABLE `question_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_import_temp`
--

DROP TABLE IF EXISTS `question_import_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_import_temp` (
  `question` text,
  `correct_option` char(1) DEFAULT NULL,
  `option_a` text,
  `option_b` text,
  `option_c` text,
  `option_d` text,
  `category` varchar(255) DEFAULT NULL,
  `image_filename` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_import_temp`
--

LOCK TABLES `question_import_temp` WRITE;
/*!40000 ALTER TABLE `question_import_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_import_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `correct_option` varchar(255) NOT NULL,
  `image_filename` varchar(255) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `difficulty_level` int DEFAULT '1',
  `explanation` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `question_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,'Hva betyr dette trafikkskiltet?','Trafikkskilt','c','sf20051007121937001_gif.gif',NULL,NULL,NULL,NULL,NULL,1,NULL),(2,'Hva er promillegrensen i Norge for vanlig bilførerkort?','Ukategorisert','a','promille.png',NULL,NULL,NULL,NULL,NULL,1,NULL),(11,'Hvilken fart er tillatt i boligområder?','Trafikkregler','a',NULL,'Fartsbegrensning',1,'I boligområder er fartsgrensen som regel 30 km/t med mindre annet er skiltet.','2025-06-20 23:36:14','2025-06-20 23:36:14',1,'multiple_choice'),(12,'Hva betyr dette opplysningsskilt?','Opplysningsskilt','b','opplysning_eksempel.png','Informasjon',1,'Opplysningsskilt gir viktig informasjon til trafikantene.','2025-06-20 23:36:14','2025-06-20 23:36:14',1,'multiple_choice'),(13,'Hvordan skal du oppføre deg ved fotgjengerfelt?','Trafikkregler','a','fotgjengerfelt.png','Fotgjengere',2,'Du må alltid gi fotgjengere som krysser eller skal krysse veien forkjørsrett.','2025-06-20 23:36:14','2025-06-20 23:36:14',1,'multiple_choice'),(14,'Hva er riktig om kjøring i rundkjøring?','Trafikkregler','c','rundkjoring.png','Rundkjøring',2,'I rundkjøring har trafikk inne i rundkjøringen alltid forkjørsrett.','2025-06-20 23:36:14','2025-06-20 23:36:14',1,'multiple_choice'),(15,'Hvilken avstand skal du holde til bilen foran?','Trafikkregler','b',NULL,'Avstand',2,'Følg 3-sekunders regelen - hold en avstand som tilsvarer 3 sekunders kjøring.','2025-06-20 23:36:14','2025-06-20 23:36:14',1,'multiple_choice');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_images`
--

DROP TABLE IF EXISTS `quiz_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `folder` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `uploader_id` int DEFAULT NULL,
  `tags` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_images`
--

LOCK TABLES `quiz_images` WRITE;
/*!40000 ALTER TABLE `quiz_images` DISABLE KEYS */;
INSERT INTO `quiz_images` VALUES (1,'promille.png','quiz','promille',NULL,'2025-06-10 21:41:01',NULL,NULL),(2,'promille.png','quiz','promille',NULL,'2025-06-10 21:43:19',NULL,NULL),(3,'promille.png','quiz','promille',NULL,'2025-06-10 21:47:03',NULL,NULL);
/*!40000 ALTER TABLE `quiz_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_responses`
--

DROP TABLE IF EXISTS `quiz_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_responses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` int NOT NULL,
  `question_id` int NOT NULL,
  `user_answer` varchar(1) DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT NULL,
  `time_spent_seconds` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `quiz_responses_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `quiz_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quiz_responses_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_responses`
--

LOCK TABLES `quiz_responses` WRITE;
/*!40000 ALTER TABLE `quiz_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_sessions`
--

DROP TABLE IF EXISTS `quiz_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `quiz_type` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `total_questions` int DEFAULT NULL,
  `correct_answers` int DEFAULT NULL,
  `time_spent_seconds` int DEFAULT NULL,
  `score` decimal(5,2) DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `quiz_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_sessions`
--

LOCK TABLES `quiz_sessions` WRITE;
/*!40000 ALTER TABLE `quiz_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refund_requests`
--

DROP TABLE IF EXISTS `refund_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refund_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_id` int NOT NULL,
  `user_id` int NOT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `description` text,
  `requested_amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `admin_notes` text,
  `processed_by_user_id` int DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `stripe_refund_id` varchar(255) DEFAULT NULL,
  `actual_refund_amount` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `user_id` (`user_id`),
  KEY `processed_by_user_id` (`processed_by_user_id`),
  CONSTRAINT `refund_requests_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `refund_requests_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `refund_requests_ibfk_3` FOREIGN KEY (`processed_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refund_requests`
--

LOCK TABLES `refund_requests` WRITE;
/*!40000 ALTER TABLE `refund_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `refund_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streak_rewards`
--

DROP TABLE IF EXISTS `streak_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `streak_rewards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `streak_days` int NOT NULL,
  `reward_name` varchar(100) NOT NULL,
  `xp_bonus` int DEFAULT NULL,
  `badge_id` int DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `streak_days` (`streak_days`),
  KEY `badge_id` (`badge_id`),
  CONSTRAINT `streak_rewards_ibfk_1` FOREIGN KEY (`badge_id`) REFERENCES `achievements` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streak_rewards`
--

LOCK TABLES `streak_rewards` WRITE;
/*!40000 ALTER TABLE `streak_rewards` DISABLE KEYS */;
/*!40000 ALTER TABLE `streak_rewards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plans`
--

DROP TABLE IF EXISTS `subscription_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `price_nok` decimal(10,2) NOT NULL DEFAULT '0.00',
  `billing_cycle` enum('monthly','yearly') NOT NULL DEFAULT 'monthly',
  `description` text,
  `features_json` text,
  `max_daily_quizzes` int DEFAULT NULL,
  `max_weekly_exams` int DEFAULT NULL,
  `has_ads` tinyint(1) NOT NULL DEFAULT '1',
  `has_detailed_stats` tinyint(1) NOT NULL DEFAULT '0',
  `has_ai_adaptive` tinyint(1) NOT NULL DEFAULT '0',
  `has_offline_mode` tinyint(1) NOT NULL DEFAULT '0',
  `has_personal_tutor` tinyint(1) NOT NULL DEFAULT '0',
  `has_video_access` tinyint(1) NOT NULL DEFAULT '0',
  `priority_support` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plans`
--

LOCK TABLES `subscription_plans` WRITE;
/*!40000 ALTER TABLE `subscription_plans` DISABLE KEYS */;
INSERT INTO `subscription_plans` VALUES (1,'free','Gratis Plan',0.00,'monthly','Gratis tilgang med begrensninger','[\"Grunnleggende quiz\", \"2 prøveeksamener per uke\", \"Grunnleggende statistikk\"]',5,2,1,0,0,0,0,0,0,1,'2025-06-20 22:34:01'),(2,'premium','Premium Plan',149.00,'monthly','Ubegrenset tilgang uten reklame','[\"Ubegrensede quiz\", \"Videoer\", \"Detaljert statistikk\", \"AI-tilpasset læring\"]',NULL,NULL,0,1,1,0,0,1,0,1,'2025-06-20 22:34:01'),(3,'pro','Pro Plan',249.00,'monthly','Alt i Premium plus offline og personlig tutor','[\"Alt i Premium\", \"Offline modus\", \"Personlig tutor\", \"Prioritert support\"]',NULL,NULL,0,1,1,1,1,1,1,1,'2025-06-20 22:34:01');
/*!40000 ALTER TABLE `subscription_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tournament_participants`
--

DROP TABLE IF EXISTS `tournament_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tournament_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `tournament_id` int NOT NULL,
  `score` int DEFAULT NULL,
  `rank` int DEFAULT NULL,
  `joined_at` datetime DEFAULT NULL,
  `last_participation` datetime DEFAULT NULL,
  `prize_earned` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_tournament_uc` (`user_id`,`tournament_id`),
  KEY `tournament_id` (`tournament_id`),
  CONSTRAINT `tournament_participants_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tournament_participants_ibfk_2` FOREIGN KEY (`tournament_id`) REFERENCES `weekly_tournaments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tournament_participants`
--

LOCK TABLES `tournament_participants` WRITE;
/*!40000 ALTER TABLE `tournament_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `tournament_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `traffic_signs`
--

DROP TABLE IF EXISTS `traffic_signs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `traffic_signs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sign_code` varchar(255) DEFAULT NULL,
  `description` text,
  `category` varchar(50) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `explanation` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `traffic_signs`
--

LOCK TABLES `traffic_signs` WRITE;
/*!40000 ALTER TABLE `traffic_signs` DISABLE KEYS */;
INSERT INTO `traffic_signs` VALUES (1,'151','Militer aktivitet','fare','fareskilt_militaer_aktivitet.gif','Dette skiltet varsler om at det kan foregå militær øvelse eller aktivitet i området. Vær forberedt på militære kjøretøy, soldater eller uventet aktivitet på veien.'),(2,'100.1','Farlig Sving Høyre','fare','sf200510071219100101_gif.gif','Varselet betyr at det kommer en skarp sving mot høyre. Senk farten og vær oppmerksom på veigrepet.'),(3,'100.2','Farlig Sving Venstre','fare','sf200510071219100201_gif.gif','Varselet betyr at det kommer en skarp sving mot Venstre. Senk farten og vær oppmerksom på veigrepet.'),(4,'102.1','Farlige Svinger Høgre','fare','sf200510071219102101_gif.gif','Her er det flere svinger etter hverandre, den første mot høyre. Konstruksjonen av veien kan være krevende, og du må ha lav fart og god kontroll.'),(5,'102.2','Farlige Svinger Venstre','fare','sf200510071219102201_gif.gif','Flere svinger i rekkefølge, med første mot venstre. Reduser farten og vær forberedt på uoversiktlige partier.'),(6,'104.1','Bratt Bakke Opp','fare','sf200510071219104101_gif.gif','Skiltet viser at det kommer en bratt stigning. Biler med svak motor må kanskje gå i lavt gir. Vær også oppmerksom på biler foran som kan miste fart.'),(7,'104.2','Bratt Bakke Ned','fare','sf200510071219104201_gif.gif','Skiltet varsler om en bratt nedoverbakke – vær forberedt på økt bremselengde.'),(8,'106.1','Smalere Veg Begge','fare','sf200510071219106101_gif.gif','Kjørebane blir smalere på begge sider – møtende trafikk må tas hensyn til.'),(9,'106.2','Smalere Veg Fra Høgre','fare','sf200510071219106201_gif.gif','Kjørebane blir smalere fra høyre side. Vær oppmerksom på møtende trafikk.'),(10,'106.3','Smalere Veg Fra Venstre','fare','sf200510071219106301_gif.gif','Kjørebane blir smalere fra venstre side. Vær forberedt på mindre plass.'),(11,'108','Ujevn Veg','fare','sf20051007121910801_gif.gif','Veibanen har ujevnheter som hull eller dumper. Kjør forsiktig.'),(12,'109','Fartshump','fare','sf20051007121910901_gif.gif','Skiltet varsler om fartshump – reduser hastigheten.'),(13,'110','Vegarbeid','fare','sf20051007121911001_gif.gif','Det pågår arbeid i eller nær veibanen – vis særlig aktsomhet.'),(14,'112','Steinsprut','fare','sf20051007121911201_gif.gif','Fare for steinsprut, ofte på grunn av løst dekke eller fjell.'),(15,'114','Rasfare','fare','sf20051007121911401_gif.gif','Område med fare for stein- eller jordras – vær ekstra varsom.'),(16,'116','Glatt Kjørebane','fare','sf20051007121911601_gif.gif','Fare for glatt kjørebane – kan skyldes is, olje eller annet underlag.'),(17,'117','Farlig Vegskulder','fare','sf20051007121911701_gif.gif','Skulderen på veien er svak eller lav – risiko ved utforkjøring eller møting.'),(18,'118','Bevegelig Bru','fare','sf20051007121911801_gif.gif','Varsler om bru som kan åpnes/løftes – stans og vent kan være nødvendig.'),(19,'120','Kai, Strand, Ferjeleie','fare','sf20051007121912001_gif.gif','Fare for å kjøre i vannet – området leder mot kai, strand eller ferje.'),(20,'122','Tunnel','fare','sf20051007121912201_gif.gif','Inngang til tunnel – vær oppmerksom på lysforhold og nødutganger.'),(21,'124','Farlig Vegkryss','fare','sf20051007121912401_gif.gif','Kryss med nedsatt sikt eller høy ulykkesrisiko – reduser farten.'),(22,'126','Rundkjøring','fare','sf20051007121912601_gif.gif','Du nærmer deg en rundkjøring – gi tegn og vikeplikt ved innkjøring.'),(23,'132','Trafikklyssignal','fare','sf20051007121913201_gif.gif','Kryss eller punkt regulert med trafikklys – vær klar for stans.'),(24,'134','Planovergang Med Bom','fare','sf20051007121913401_gif.gif','Jernbaneovergang med bom – stans ved rødt lys eller lukket bom.'),(25,'135','Planovergang Uten Bom','fare','sf20051007121913501_gif.gif','Jernbaneovergang uten bom – ekstra oppmerksomhet nødvendig.'),(26,'136.1','Avstandsskilt 300 meter','fare','sf200510071219136101_gif.gif','Skiltet varsler at det kommer et farlig punkt om 300 meter.'),(27,'136.2','Avstandsskilt 200 meter','fare','sf200510071219136201_gif.gif','Farlig punkt kommer om 200 meter – forberede deg på handling.'),(28,'136.3','Avstandsskilt 100 meter','fare','sf200510071219136301_gif.gif','Farlig punkt kommer om 100 meter – vær oppmerksom.'),(29,'138.1','Jernbarnespor Enkeltsporet','fare','sf200510071219138101_gif.gif','Enkelt jernbanespor krysser veien – stans ved behov.'),(30,'138.2','Jernbarnespor Flersporet','fare','sf200510071219138201_gif.gif','Flere jernbanespor krysser veien – vær ekstra oppmerksom.'),(31,'139','Sporvogn','fare','sf20051007121913901_gif.gif','Vei krysset eller delt med sporvogn – fare for kryssende trafikk.'),(32,'140','Avstand Til Gangfelt','fare','sf20051007121914001_gif.gif','Gangfelt nærmer seg – vis hensyn til fotgjengere.'),(33,'142','Barn','fare','sf20051007121914201_gif.gif','Barn kan komme plutselig ut i veien – typisk nær skole eller lekeområde.'),(34,'144','Syklende','fare','sf20051007121914401_gif.gif','Syklister i området – vær varsom ved forbikjøring.'),(35,'146.1','Elg','fare','sf200510071219146101_gif.gif','Fareskilt som varsler om elgfare – vanlig i skogsområder. Reduser farten og vær oppmerksom, spesielt ved skumring.'),(36,'146.2','Rein','fare','sf200510071219146201_gif.gif','Fareskilt for rein – ofte brukt på fjellet eller i nordlige strøk. Reinen går ofte i flokker.'),(37,'146.3','Hjort','fare','sf200510071219146301_gif.gif','Varsler om fare for hjortekollisjoner. Hjorten kan komme løpende brått ut fra skog eller skråning.'),(38,'146.4','Ku','fare','sf200510071219146401_gif.gif','Fare for at kyr kan være på eller ved veien – vanlig nær beitemark.'),(39,'146.5','sauer og Lam','fare','sf200510071219146501_gif.gif','Fare for lam og sau i veibanen – kjør forsiktig.'),(40,'148','Møtende Trafikk','fare','sf20051007121914801_gif.gif','Fareskilt for sau – typisk brukt i fjellområder eller beiteområder med løsdrift.'),(41,'149','Ko','fare','sf20051007121914901_gif.gif','Varsler om fare for stillestående eller saktegående trafikk – typisk ved stor trafikkmengde, rushtid eller ulykker.'),(42,'150','Fly','fare','sf20051007121915001_gif.gif','Lavtgående fly i området – særlig ved rullebaner nær veien.'),(43,'152','Sidevind','fare','sf20051007121915201_gif.gif','Fare for sterk sidevind – risiko for å miste kontroll over kjøretøyet.'),(44,'153','Trafikkulykke','fare','sf20051007121915301_gif.gif','Utsatt punkt for trafikkulykker – vær ekstra aktpågivende.'),(45,'154','Skiløpere','fare','sf20051007121915401_gif.gif','Kryssende skiløype – reduser farten og se etter skiløpere.'),(46,'155','Ridende','fare','sf20051007121915501_gif.gif','Kryssende ridesti – fare for hest og rytter i eller ved veien.'),(47,'156','Annen fare','fare','sf20051007121915601_gif.gif','Skiltet brukes når faren ikke dekkes av andre fareskilt – se etter supplerende informasjon.'),(48,'302','Innkjoring Forbudt','forbuds','sf20051007121930201_gif.gif','Det er ikke tillatt å kjøre inn i veien fra denne retningen.'),(49,'306.0','Forbudt for alle kjoretoy','forbuds','sf200510071219306001_gif.gif','Gjelder alle typer kjøretøy – ingen motorisert eller ikke-motorisert trafikk.'),(50,'306.1','Forbudt for motorvogn med unntak av liten elektrisk motorvogn','forbuds','sf200510071219306101_gif.gif','Forbud mot motorvogn, men små elektriske kjøretøy som el-sparkesykkel kan være unntatt.'),(51,'306.3','Forbudt for alle traktorer og for motorredskap konstruert for fart mindre enn 40 km/t.','forbuds','sf200510071219306301_gif.gif','Traktorer og motorredskap som anleggsmaskiner har ikke tillatelse.'),(52,'306.4','Forbudt for motorsykkel og moped','forbuds','sf200510071219306401_gif.gif','Gjelder tohjuls- eller trehjuls motoriserte kjøretøy.'),(53,'306.5','Forbudt for lastebil og trekkbil','forbuds','sf200510071219306501_gif.gif','Lastebiler og trekkbiler har ikke adgang.'),(54,'306.6','Forbudt for syklende og forer av liten elektrisk motorvogn','forbuds','sf200510071219306601_gif.gif','Gjelder syklister og små elektriske kjøretøy som el-sparkesykkel.'),(55,'306.7','Forbudt for gaende','forbuds','sf200510071219306701_gif.gif','Fotgjengere har ikke adgang.'),(56,'306.8','Forbudt for gaende, syklende og fører av liten elektrisk motorvogn','forbuds','sf200510071219306801_gif.gif','Totalforbud for disse trafikantgruppene – ofte brukt i tunneler.'),(57,'306.9','Forbudt for ridende','forbuds','sf200510071219306901_gif.gif','Gjelder personer som rir – vanlig ved høytrafikkerte veier eller motorvei.'),(58,'306.10','Forbudt for liten elektrisk motorvogn','forbuds','sf-20051007-1219-306-10-01_gif.png','Forbud mot små elektriske kjøretøy som el-sparkesykkel.'),(59,'308','Forbudt for transport av farlig gods','forbuds','sf20051007121930801_gif.gif','Ikke tillatt å transportere farlig gods – eksplosiver, gass, gift osv.'),(60,'310','Forbudt for motorvogn med flere enn to hjul og med tillatt totalvekt høyere enn angitt','forbuds','sf20051007121931001_gif.gif','Forbud mot større motorvogn – typisk busser og lastebiler med visse unntak.'),(61,'312','Breddegrense','forbuds','sf20051007121931201_gif.gif','Kjøretøy som er bredere enn angitt må ikke passere.'),(62,'314','Høydegrense','forbuds','sf20051007121931401_gif.gif','Kjøretøy som er høyere enn angitt må ikke passere.'),(63,'316','Lengdegrense','forbuds','sf20051007121931601_gif.gif','Kjøretøy som er lengre enn angitt må ikke kjøre inn.'),(64,'318.1','Totalvektgrense for kjoretoy','forbuds','sf200510071219318101_gif.gif','Kjøretøy over angitt totalvekt har ikke tillatelse til å passere.'),(65,'318.2','Totalvektgrense for for vogntog','forbuds','sf200510071219318201_gif.gif','Vogntog over angitt totalvekt har ikke tillatelse til å passere.'),(66,'320','Aksellastgrense','forbuds','sf20051007121932001_gif.gif','Begrenser aksellast – viktig for broers og vegers bæreevne.'),(67,'322','Boggilastgrense','forbuds','sf20051007121932201_gif.gif','Begrenser boggilast – gjelder for tunge kjøretøykombinasjoner.'),(68,'324','Stopp for angitt formal','forbuds','sf20051007121932401_gif.gif','Stopp for kontroll eller annen kontrollfunksjon – se undertekst eller symbol.'),(69,'326','Stopp for toll','forbuds','sf20051007121932601_gif.gif','Stopp for toll – brukes nær grenseoverganger eller tollstasjoner.'),(70,'330.1','Svingeforbud Høgre','forbuds','sf200510071219330101_gif.gif','Det er forbudt å svinge til høyre der dette skiltet er plassert.'),(71,'330.2','Svingeforbud Venstre','forbuds','sf200510071219330201_gif.gif','Det er forbudt å svinge til venstre der dette skiltet er plassert.'),(72,'332','Vendingsforbud','forbuds','sf20051007121933201_gif.gif','Det er ikke tillatt å snu – for eksempel i kryss eller U-sving.'),(73,'334','Forbikjøringsforbud','forbuds','sf20051007121933401_gif.gif','Forbikjøring av motorvogn på mer enn to hjul er forbudt.'),(74,'335','Forbikjoringsforbud for lastebil','forbuds','sf20051007121933501_gif.gif','Forbikjøring med lastebil er forbudt – gjelder tunge kjøretøy.'),(75,'336','Slutt på forbikjoringsforbud','forbuds','sf20051007121933601_gif.gif','Forbudet mot forbikjøring oppheves – gjelder alle kjøretøy.'),(76,'337','Slutt på forbikjoringsforbud for lastebil','forbuds','sf20051007121933701_gif.gif','Forbudet mot forbikjøring med lastebil oppheves.'),(77,'362','Fartsgrense','forbuds','sf20051007121936201_gif.gif','Viser hvilken fartsgrense som gjelder fra og med skiltets plassering.'),(78,'364','Slutt på serskilt fartsgrense','forbuds','sf20051007121936401_gif.gif','Fartsgrensen som tidligere gjaldt opphører – generelle regler gjelder videre.'),(79,'366','Fartsgrensesone','forbuds','sf20051007121936601_gif.gif','Område der angitt fartsgrense gjelder til sonen oppheves.'),(80,'367','Fartsgrensesone for liten elektrisk motorvogn','forbuds','sf-20051007-1219-367-01_gif.png','Fartsgrensesone spesifikt for liten elektrisk motorvogn, f.eks. el-sparkesykkel.'),(81,'368','Slutt pa fartsgrensesone','forbuds','sf20051007121936801_gif.gif','Slutt på fartsgrensesone – den angitte soneregelen oppheves.'),(82,'369','Slutt på fartsgrensesone for liten elektrisk motorvogn','forbuds','sf-20051007-1219-369-01_gif.png','Slutt på sone med fartsgrense for liten elektrisk motorvogn.'),(83,'370','Stans forbudt','forbuds','sf20051007121937001_gif.gif','Stans av kjøretøy er forbudt på området skiltet dekker.'),(84,'372','Parkering forbudt','forbuds','sf20051007121937201_gif.gif','Parkering er ikke tillatt – se eventuelle tilleggsskilt for tidsrom.'),(85,'376.1','Parkeringssone','forbuds','sf200510071219376101_gif.gif','Område der parkeringsregler gjelder som en sone – gjelder inntil opphevet.'),(86,'376.2','Parkeringssone','forbuds','sf200510071219376201_gif.gif','Område der parkeringsregler gjelder som en sone – gjelder inntil opphevet.'),(87,'377','Sone med parkeringsforbud for liten elektrisk motorvogn','forbuds','sf-20051007-1219-377-01_gif.png','Sone med parkeringsforbud for liten elektrisk motorvogn – f.eks. el-sparkesykkel.'),(88,'378.1','Slutt på parkeringssone','forbuds','sf200510071219378101_gif.gif','Slutt på område der parkeringssone-regler har vært gjeldende.'),(89,'378.2','Slutt på parkeringsforbud','forbuds','sf200510071219378201_gif.gif','Slutt på område med parkeringsforbud – normal parkering tillatt.'),(90,'379','Slutt på sone med parkeringsforbud for liten elektrisk motorvogn','forbuds','sf-20051007-1219-379-01_png.png','Slutt på sone med parkeringsforbud for liten elektrisk motorvogn.'),(91,'380','Sone med bruksforbud for liten elektrisk motorvogn','forbuds','sf-20051007-1219-380-01_PNG.png','Område der bruk av liten elektrisk motorvogn er forbudt.'),(92,'382','Slutt på sone med bruksforbud for liten elektrisk motorvogn','forbuds','sf-20051007-1219-382-01_PNG.png','Slutt på sone med bruksforbud for liten elektrisk motorvogn.'),(93,'1000','Kjørefeltlinje','linjer_og','sf200510071219100001_gif.gif','Angir deling mellom kjørefelt i samme retning – kan krysses med varsomhet.'),(94,'1002','Varsellinje','linjer_og','sf200510071219100201_gif_2.gif','Varsler overgang til sperrelinje – kryssing frarådes.'),(95,'1004','Sperrelinje','linjer_og','sf200510071219100401_gif.gif','Det er ikke tillatt å krysse denne linjen – forbudt passering.'),(96,'1006','Kombinerte linjer','linjer_og','sf200510071219100601_gif.gif','En blanding av sperrelinje og kjørefeltlinje – gjelder forskjellig for hver retning.'),(97,'1008','Skillelinje','linjer_og','sf200510071219100801_gif.gif','Skiller kjørefelt som går i ulike retninger – kryssing forbudt.'),(98,'1010','Ledelinje','linjer_og','sf200510071219101001_gif.gif','Brukes for å lede trafikk i kryss eller rundkjøring – gir retning.'),(99,'1012','Kantlinje','linjer_og','sf200510071219101201_gif.gif','Marker ytterkant av kjørebanen – hjelper med plassering i veibanen.'),(100,'1014','Sperreområde','linjer_og','sf200510071219101401_gif.gif','Område markert med heltrukne linjer – kjøring tillates ikke innenfor.'),(101,'1020','Stopplinje','linjer_og','sf200510071219102001_gif.gif','Linje hvor kjøretøy må stanse ved stoppskilt eller rødt lys.'),(102,'1022','Vikelinje','linjer_og','sf200510071219102201_gif_2.gif','Angir hvor vikeplikt skal utøves – stans er ikke påkrevd med mindre nødvendig.'),(103,'1024','Gangfelt','linjer_og','sf200510071219102401_gif.gif','Markerer gangfelt – gir fotgjengere rett til å krysse veien trygt.'),(104,'1026','Sykkelkryssing','linjer_og','sf200510071219102601_gif.gif','Markerer kryssing for syklister – gir informasjon om syklistens trase.'),(105,'1027','Fartshump','linjer_og','sf200510071219102701_gif.gif','Markering av fartshump – varsler sjåfører om å redusere hastigheten.'),(106,'1028','Parkeringsfelt','linjer_og','sf200510071219102801_gif.gif','Angir parkeringsfelt – veibanen er reservert for parkering.'),(107,'1034','Piler','linjer_og','sf200510071219103401_gif.gif','Piler angir kjørefeltets retning eller tillatt bevegelse.'),(108,'1036','Vikesymbol','linjer_og','sf200510071219103601_gif.gif','Symbol som markerer vikeplikt i veikryss.'),(109,'1037','Gangsymbol','linjer_og','sf200510071219103701_gif.gif','Symbol som viser hvor fotgjengere forventes å krysse.'),(110,'1038','Delesymbol','linjer_og','sf200510071219103901_gif.gif','Delesymbol for gang- og sykkelvei – skiller soner for gående og syklende.'),(111,'1040','Parkeringssymbol','linjer_og','sf200510071219104001_gif.gif','Symbol for parkering – ofte brukt i kombinasjon med parkeringsfelt.'),(112,'1041','Liten elektrisk motorvogn','linjer_og','sf-20051007-1219-1041-01-02.png','Markering for område eller felt for liten elektrisk motorvogn (f.eks. el-sparkesykkel).'),(113,'1042','Symbol for forflytningshemmede','linjer_og','sf200510071219104201_gif_2.gif','Markerer plass eller område reservert for forflytningshemmede.'),(114,'1044','Skinnekjøretøy','linjer_og','sf200510071219104401_gif.gif','Symbol for trikk/sporvogn – markerer felt der disse kjører.'),(115,'1050','Tekst','linjer_og','sf200510071219105001_gif.gif','Inngravert eller malt tekst i veibanen – gir ekstra informasjon, f.eks. «BUSS».'),(116,'1052','Sambruksfelt','linjer_og','sf200510071219105201_gif.gif','Felt reservert for felles bruk, f.eks. buss, taxi og elbil.'),(117,'1054','Fartsgrense','linjer_og','sf200510071219105401_gif.gif','Fartsgrensen angitt med tall i kjørebanen.'),(118,'1053','Tungtrafikkfelt','linjer_og','vegoppmerkingsskilt_som_viser_75_tonn__grafikk.gif','Felt reservert for tunge kjøretøy som lastebil og buss.'),(119,'761','Motorveg','opplysnings','sf20051007121950201_gif.gif','Vei reservert for motorvogn med høy standard – avkjørsler kun i planfrie kryss.'),(120,'763','Motortrafikkveg','opplysnings','sf20051007121950301_gif.gif','Hovedvei for motorisert trafikk med visse restriksjoner for gående og syklende.'),(121,'504','Slutt på motorveg','opplysnings','sf20051007121950401_gif.gif','Motorveien opphører – normale trafikkregler gjelder videre.'),(122,'505','Slutt på motortrafikkveg','opplysnings','sf20051007121950501_gif.gif','Motortrafikkveien opphører – vær oppmerksom på mulig redusert standard.'),(123,'506','Tungtrafikkfelt','opplysnings','sf20051007121950601_gif.gif','Felt forbeholdt tunge kjøretøy, som lastebil og buss.'),(124,'507','Slutt på tungtrafikkfelt','opplysnings','sf20051007121950701_gif.gif','Avslutning på særskilt felt for tungtrafikk.'),(125,'508.1','Kollektivfelt for buss','opplysnings','sf200510071219508101_gif.gif','Felt reservert for busser – andre kjøretøy må ikke bruke dette.'),(126,'508.2','Kollektivfelt for buss og drosje','opplysnings','sf200510071219508201_gif.gif','Felt reservert for busser og drosjer (taxi).'),(127,'509','Sambruksfelt','opplysnings','sf20051007121950901_gif.gif','Felt for felles bruk, f.eks. elbil, taxi, kollektiv m.m. – se skilt.'),(128,'510.1','Slutt på kollektivfelt','opplysnings','sf200510071219510101_gif.gif','Slutt på område med kollektivfelt – vanlige regler gjelder.'),(129,'510.2','Slutt på kollektivfelt for buss og drosje','opplysnings','sf200510071219510201_gif.gif','Kollektivfelt for buss og drosje opphører – normale regler gjelder.'),(130,'511','Slutt på sambruksfelt','opplysnings','sf20051007121951101_gif.gif','Felt for elbil, taxi m.m. opphører – vanlig trafikkfelt følger.'),(131,'512','Holdeplass for buss','opplysnings','sf20051007121951201_gif.gif','Marker område der buss stopper for av- og påstigning.'),(132,'513','Holdeplass for sporvogn','opplysnings','sf20051007121951301_gif.gif','Marker område der trikk/sporvogn stopper – se opp for passasjerer.'),(133,'514','Holdeplass for drosje','opplysnings','sf20051007121951401_gif.gif','Reservert plass for taxi – ventende og kjørende drosjer.'),(134,'516','Gangfelt','opplysnings','sf20051007121951601_gif.gif','Opplyser om fotgjengerovergang – vis hensyn og vikeplikt.'),(135,'518','Gangveg','opplysnings','sf20051007121951801_gif.gif','Opplyser om veg kun for gående – sykling forbudt.'),(136,'520','Sykkelveg','opplysnings','sf20051007121952001_gif.gif','Opplyser om veg kun for syklister – andre trafikanter forbudt.'),(137,'521.1','Sykkelfelt – sideplassert','opplysnings','sf20051007121952101_gif.gif','Oppmerksomhet på sykkelfelt langs veikant – kun for syklister.'),(138,'521.2','Sykkelfelt – Midtstilt','opplysnings','sf200510071219521201_gif.gif','Sykkelfelt plassert i midten av kjørefelt – kun for syklister.'),(139,'522','Gang- og sykkelveg','opplysnings','sf20051007121952201_gif.gif','Veg delt mellom gående og syklende – vis hensyn og hold deg til riktig side.'),(140,'524','Møteplass','opplysnings','sf20051007121952401_gif.gif','Utvidet område der kjøretøy kan møtes og passere hverandre.'),(141,'526.1','Envegskjøring frem','opplysnings','sf200510071219526101_gif.gif','Kun én kjøreretning tillatt – fremover i pilens retning.'),(142,'526.2','Envegskjøring venstre','opplysnings','sf200510071219526201_gif.gif','Enveisveg med kjøreretning til venstre.'),(143,'527.1','Blindveg','opplysnings','sf200510071219527101_gif.gif','Veg som ikke har gjennomkjøring – ender blindt.'),(144,'527.2','Skiltet viser at vegen er fysisk stengt.','opplysnings','sf200510071219527201_gif.gif','Veg sperret med fysisk hindring, f.eks. bom, mur eller annet.'),(145,'527.3','Skiltet viser at kryssende veg er fysisk stengt','opplysnings','sf200510071219527301_gif.gif','Kryssende veg er fysisk sperret – gjennomkjøring umulig.'),(146,'527.4','Skiltet viser at vegen er stengt for biltrafikk, men åpen for gående og syklende','opplysnings','sf200510071219527401_gif.gif','Biltrafikk forhindres – men annen ferdsel kan være tillatt.'),(147,'528','Valgfritt kjørefelt','opplysnings','sf20051007121952801_gif.gif','Trafikanter kan velge fritt mellom kjørefeltene i angitt område.'),(148,'530','Sammenfletting','opplysnings','sf200510071219530a01_gif.gif','Kjørefelt flettes sammen – veksle på å slippe frem kjøretøy.'),(149,'531.1','Felt for fartsøkning','opplysnings','sf200510071219531101_gif.gif','Kjørefelt for akselerasjon – benyttes ved innkjøring på hovedvei.'),(150,'532','Kjørefelt slutter','opplysnings','sf200510071219532a01_gif.gif','Et kjørefelt opphører – vær oppmerksom og flett inn i tide.'),(151,'534','Kjørefelt begynner','opplysnings','sf200510071219534a01_gif.gif','Et nytt kjørefelt starter – benytt ved behov.'),(152,'536.1','Påkjøring fortsetter i eget kjørefelt','opplysnings','sf200510071219536101_gif.gif','Feltet du kommer fra fortsetter – ingen fletting nødvendig.'),(153,'538','Kjørefeltinndeling','opplysnings','sf20051007121953801_gif.gif','Viser hvordan kjørefeltene er delt – planlegg kjøring deretter.'),(154,'539','Endret kjøremønster','opplysnings','sf20051007121953901_gif.gif','Kjør forsiktig – uvanlig eller midlertidig kjøremønster i området.'),(155,'540','Gatetun','opplysnings','sf20051007121954001_gif.gif','Område der gående har prioritet – lav hastighet påbudt.'),(156,'542','Slutt på gatetun','opplysnings','sf20051007121954201_gif.gif','Vanlige trafikkregler gjelder igjen – vis hensyn.'),(157,'548','Gågate','opplysnings','sf20051007121954801_gif.gif','Veg kun for gående – kjøring vanligvis forbudt.'),(158,'550','Slutt på gågate','opplysnings','sf20051007121955001_gif.gif','Kjøring kan gjenopptas – følg gjeldende regler.'),(159,'552','Parkering','opplysnings','sf20051007121955201_gif.gif','Område der det er tillatt å parkere – følg eventuelle tilleggsskilt.'),(160,'555','Havarilomme','opplysnings','sf20051007121955501_gif.gif','Lomme i veien for nødstopp – ikke ment for vanlig parkering.'),(161,'556.1','Automatisk trafikkontroll – punktmåling','opplysnings','sf200510071219556101_gif.gif','Fotoboks måler kjøretøyets hastighet på et bestemt punkt.'),(162,'556.2','Automatisk trafikkontroll – strekningsmåling','opplysnings','sf200510071219556201_gif.gif','Gjennomsnittshastighet måles over en strekning.'),(163,'558','Videokontroll/-overvåking','opplysnings','sf20051007121955801_gif.gif','Området er videoovervåket – ofte brukt ved bomstasjoner eller tunneler.'),(164,'560','Opplysningstavle','opplysnings','sf20051007121956001_gif.gif','Gir generell informasjon – kan brukes sammen med symbol eller tekst.'),(165,'565','Feil kjøreretning','opplysnings','sf20051007121956501_gif.gif','Varsel om at du kjører mot kjøreretningen – snu umiddelbart.'),(166,'570.1','Nødutgangsskilt for tunnel','opplysnings','sf2005100712195701h01_gif.gif','Viser plassering av nødutgang i tunnel.'),(167,'570.2','Retning og avstand til nødutgang','opplysnings','sf2005100712195702h01_gif.gif','Angir retningen og avstanden til nærmeste nødutgang.'),(168,'650.22','Sykkelloype','service','serviceskilt_som_viser_sykkelløype__grafikk.gif','Vei eller rute tilrettelagt for syklister – del av nasjonalt eller lokalt nettverk.'),(169,'602','Førstehjelp','service','sf20051007121960201_gif.gif','Sted der førstehjelpsutstyr er tilgjengelig – f.eks. hjertestarter.'),(170,'605','Nødtelefon','service','sf20051007121960501_gif.gif','Plassering av telefon for nødsituasjoner – ofte i tunneler eller langs motorvei.'),(171,'606','Brannslokningsapparat','service','sf20051007121960601_gif.gif','Viser hvor brannslukker er plassert – viktig ved brannfare.'),(172,'608','Kjøretøyverksted','service','sf20051007121960801_gif.gif','Verksted der kjøretøy kan repareres – dekker både små og store kjøretøy.'),(173,'609','Hurtiglading av motorvogn','service','sf20051007121960901_gif.gif','Tilgang til hurtigladestasjon for elbil eller annet elektrisk kjøretøy.'),(174,'610.1 ','Drivstoff','service','sf200510071219610101_gif.gif','Tilgang på bensin, diesel eller annen type drivstoff – bensinstasjon.'),(175,'611','Toalettømmeanlegg','service','sf20051007121961101_gif.gif','Tømmestasjon for campingvogner eller bobiler – sanitæranlegg.'),(176,'612','Toalett','service','sf20051007121961201_gif.gif','Offentlig toalett tilgjengelig på stedet.'),(177,'613.1','Rasteplass','service','sf200510071219613101_gif.gif','Tilrettelagt stoppested med sitteplasser, ofte med toalett og informasjon.'),(178,'613.2','Rasteplass med toalett','service','sf200510071219613201_gif.gif','Rast med både sitteplass og toalett – egnet for lengre stopp.'),(179,'614','Enklere servering','service','sf20051007121961401_gif.gif','Kiosk, kafé eller annen enkel matservering.'),(180,'616','Spisested','service','sf20051007121961601_gif.gif','Restaurant eller større serveringssted med varm mat.'),(181,'618','Campingplass','service','sf20051007121961801_gif.gif','Område tilrettelagt for telt og campingvogner.'),(182,'621','Bobilplass','service','sf20051007121962101_gif.gif','Oppstillingsplass spesifikt for bobiler – ofte med strøm og vann.'),(183,'622','Campinghytter','service','sf20051007121962201_gif.gif','Enkle overnattingshytter ofte tilknyttet campingplass.'),(184,'624','Vandrerhjem','service','sf20051007121962401_gif.gif','Rimelig overnatting med fellesrom og selvbetjening.'),(185,'625','Rom og frokost','service','sf20051007121962501_gif.gif','Privat overnatting med frokost inkludert – «bed and breakfast».'),(186,'626','Overnattingssted','service','sf20051007121962601_gif.gif','Generell overnatting – hotell, motell, pensjonat osv.'),(187,'635','Informasjon','service','sf20051007121963501_gif.gif','Generell informasjonstavle for reisende – f.eks. kart, regler eller tilbud.'),(188,'637','Turistkontor','service','sf20051007121963701_gif.gif','Offentlig kontor med informasjon for turister – kart, brosjyrer, tips.'),(189,'638','Døgnhvileplass','service','sf-20051007-1219-638-01-01.png','Parkeringsplass for langtransport med fasiliteter for hvile og overnatting.'),(190,'640.10','Severdighet','service','sf2005100712196401001_gif.gif','Viser vei til kulturelt eller naturlig interessant sted.'),(191,'640.12','Museum/galleri','service','sf2005100712196401201_gif.gif','Tilgang til kunstutstilling eller museum.'),(192,'640.20 ','Utsiktspunkt','service','sf2005100712196402001_gif.gif','Sted med utsikt over landskap, by eller severdighet.'),(193,'650.10','Badeplass','service','sf2005100712196501001_gif.gif','Offentlig tilrettelagt badeområde.'),(194,'650.11','Fiskeplass','service','sf2005100712196501101_gif.gif','Tilrettelagt område for sportsfiske eller fritidsfiske.'),(195,'650.20','Tursti','service','sf2005100712196502001_gif.gif','Merket rute for fotturer i naturen.'),(196,'650.21','Skiløype','service','sf2005100712196502101_gif.gif','Preparert løype for langrenn eller annen skigåing.'),(197,'650.40','Gardsmat/bygdeturisme','service','sf2005100712196504001_gif.gif','Tilbud om lokal mat, gårdsopplevelser eller overnatting i landlige omgivelser.'),(198,'1080','Hovedsignal','signaler','sf200510071219108001_gif.gif','Vanlig trafikklys for motorvogner – regulerer kjøring med rødt, gult og grønt.'),(199,'1082.1','Pilsignal Venstre','signaler','sf2005100712191082101_gif.gif','Trafikklys med pil til venstre – gjelder kun for venstresvingende trafikk.'),(200,'1082.2','Pilsignal Opp','signaler','sf2005100712191082201_gif.gif','Pilsignal rett frem – gjelder bare for trafikk rett frem.'),(201,'1082.3','Pilsignal Høgre','signaler','sf2005100712191082301_gif.gif','Pil til høyre – signalet gjelder bare for høyresvingende trafikk.'),(202,'1084','Sykkelsignal','signaler','sf200510071219108402_gif.gif','Eget lys for syklister – styrer når det er trygt å krysse eller kjøre.'),(203,'1086','Fotgjengersignal','signaler','sf200510071219108601_gif.gif','Signal for fotgjengere – grønn mann = gå, rød mann = stans.'),(204,'1088','Signal for kollektivtrafikk','signaler','sf200510071219108802_gif.gif','Trafikklys for buss og trikk – egne signaler som ikke gjelder andre trafikanter.'),(205,'1090','Kjørefeltsignal','signaler','sf200510071219109001_gif.gif','Lyssignal over kjørefelt – viser om feltet er åpent eller stengt.'),(206,'1092','Tolyssignal','signaler','sf200510071219109201_gif.gif','Rødt og grønt lys brukt der gult ikke er nødvendig – f.eks. bommer.'),(207,'1094','Rødt stoppblinksignal','signaler','sf200510071219109401_gif.gif','Blinkende rødt lys – stans umiddelbart og følg anvisninger eller bommer.'),(208,'1096','Blinkende signal foran jernbane','signaler','sf200510071219109601_gif.gif','Varsellys før planovergang – stans ved blinkende rødt, jernbane nærmer seg.'),(209,'1098','Gult blinksignal','signaler','sf200510071219109801_gif.gif','Varsellys som ber trafikanter være ekstra oppmerksomme – ingen stans plikt.'),(210,'1100.1','Blinkende lyspil','signaler','sf2005100712191100101_gif.gif','Pil som blinker for å vise anbefalt kjøreretning – ofte ved hinder eller veiarbeid.'),(211,'902.1','Bakgrunnsmarkering Høgre','markering','sf200510071219902h01_gif.gif','Refleksmarkering som viser hindringer eller objekter på høyre side.'),(212,'902.2','Bakgrunnsmarkering Venstre','markering','sf200510071219902v01_gif.gif','Refleksmarkering som viser hindringer eller objekter på venstre side.'),(213,'904 .1','Retningsmarkering Høgre','markering','sf200510071219904h01_gif.gif','Viser skarp sving eller kurve til høyre – gir tidlig visuell varsling.'),(214,'904.2','Retningsmarkering Venstre','markering','sf200510071219904v01_gif.gif','Viser skarp sving eller kurve til venstre – gir tidlig visuell varsling.'),(215,'906.1','Hindermarkering Høgre','markering','sf200510071219906h01_gif.gif','Markerer hindring – passer på høyre side.'),(216,'906.2','Hindermarkering Venstre','markering','sf200510071219906v01_gif.gif','Markerer hindring – passer på venstre side.'),(217,'906.3','Hindermarkering Frem','markering','sf200510071219906vh01_gif.gif','Hindring skal passeres rett frem – typisk midt i veien.'),(218,'908','Hindermarkering','markering','sf20051007121990801_gif.gif','Generell markering av hindringer i eller ved veibanen.'),(219,'912','Avkjøringsmarkering','markering','sf20051007121991201_gif.gif','Marker avkjøring – ofte brukt før utfartsramper.'),(220,'914','Tunnelmarkering','markering','sf200510071219914h01_gif.gif','Brukes i tunneler for å vise vegkanter eller retning.'),(221,'916','Avstandsmarkering i tunnel','markering','sf20051007121991601_gif.gif','Viser avstand i meter til nærmeste nødutgang – plassert jevnlig i tunnelvegger.'),(222,'920','Kantstolpe','markering','sf200510071219920h01_gif.gif','Marker kant av veien – reflekser gir veiledning i mørke.'),(223,'940','Trafikkjegle','markering','sf20051007121994001_gif.gif','Midlertidig markering ved arbeid, ulykker eller hindringer – lett flyttbar.'),(224,'942','Trafikksylinder','markering','sf20051007121994201_gif.gif','Høy, sylindrisk markør for å lede trafikk eller sperre av område midlertidig.'),(225,'802','Avstand','under','sf20051007121980201_gif.gif','Viser hvor langt restriksjon eller informasjon gjelder fremover.'),(226,'804','Utstrekning','under','sf20051007121980401_gif.gif','Angir total lengde eller område som restriksjonen gjelder.'),(227,'806','Tid','under','sf20051007121980601_gif.gif','Viser når skiltet gjelder – f.eks. ukedager, klokkeslett.'),(228,'807.1 ','Personbil','under','sf200510071219807101_gif.gif','Skiltet gjelder kun for personbiler.'),(229,'807.2','Varebil, lastebil og trekkbil','under','sf200510071219807201_gif.gif','Gjelder kjøretøy med varer, gods eller tilhenger – som lastebil og trekkbil.'),(230,'807.3','Buss','under','sf200510071219807301_gif.gif','Skiltet gjelder for busser i rutetrafikk eller turtrafikk.'),(231,'807.4','Vogntog','under','sf200510071219807401_gif.gif','Gjelder kjøretøykombinasjoner – f.eks. lastebil med tilhenger.'),(232,'807.5','Tilhenger særskilt innredet til campingbruk, samt eventuell trekkvogn','under','sf200510071219807501_gif.gif','Gjelder tilhengere innredet til campingbruk.'),(233,'807.6','Sykkel og liten elektrisk motorvogn','under','sf200510071219807601_gif.gif','Skiltet gjelder for sykler, el-sykler og små elektriske kjøretøy.'),(234,'807.7','Tohjuls motorsykkel med og uten sidevogn og tohjuls moped','under','sf200510071219807701_gif.gif','Gjelder tohjuls motorsykkel og moped, med eller uten sidevogn.'),(235,'807.8','Forflytningshemmede med parkeringstillatelse','under','sf200510071219807801_gif.gif','Gjelder kun for personer med gyldig parkeringsbevis for forflytningshemmede.'),(236,'807.9','Kjøretøy særskilt innredet til campingbruk (bobil)','under','sf200510071219807901_gif.gif','Gjelder for bobiler og større kjøretøy spesielt tilpasset camping.'),(237,'808','Tekst','under','sf20051007121980801_gif.gif','Tilleggsskilt med informasjon i form av tekst.'),(238,'810','Svingpil','under','sf20051007121981001_gif.gif','Angir hvilken retning skiltet gjelder for – f.eks. høyresving.'),(239,'812','Anbefalt fart','under','sf20051007121981201_gif.gif','Viser anbefalt hastighet under spesielle forhold – ikke bindende.'),(240,'813.1','Stigningsgrad','under','sf200510071219813101_gif.gif','Angir stigning eller helling på veien i prosent.'),(241,'814','Virkelig fri vegbredde','under','sf20051007121981401_gif.gif','Viser faktisk tilgjengelig bredde på veien – nyttig for større kjøretøy.'),(242,'816','Kryssende tømmertransport','under','sf20051007121981601_gif.gif','Informasjon om at veien krysses av tømmertransport – vis forsiktighet.'),(243,'817','Særlig ulykkesfare','under','sf20051007121981701_gif.gif','Varsel om høy ulykkesrisiko – kjør ekstra forsiktig.'),(244,'822','Forløp av forkjørsveg','under','sf20051007121982201_gif.gif','Viser hvordan forkjørsveien fortsetter gjennom kryss – viktig for vikeplikt.'),(245,'824','Forvarsling av stopp','under','sf20051007121982401_gif.gif','Informerer om at det kommer et stopp-skilt lenger fremme.'),(246,'826','Sykkeltrafikk i begge kjøreretninger','under','sf20051007121982601_gif.gif','Angir at syklister kan kjøre begge retninger i enveiskjørt gate.'),(247,'828.1','Utstrekning av stans- og parkeringsregulering','under','sf200510071219828101_gif.gif','Viser hvor langt parkeringsforbud eller stansforbud gjelder.'),(248,'829','Oppstilling av parkert kjøretøy','under','sf20051007121982901_gif.gif','Viser hvordan kjøretøy skal plasseres på parkeringsplass.'),(249,'831','Parkeringsskive/gratisbillett','under','sf20051007121983101_gif.gif','Informasjon om at parkeringsskive eller gratisbillett må brukes.'),(250,'834','Kombinert regulering','under','sf20051007121983401_gif.gif','Flere parkeringsregler gjelder samtidig – les nøye tilleggsskilt.'),(251,'701','Tabellorienteringstavle','vegvisnings','sf20051007121970101_gif.gif','Stor oversiktstavle som viser flere reisemål og avstander – plassert i god avstand fra veikryss.'),(252,'703','Diagramorienteringstavle','vegvisnings','sf20051007121970301_gif.gif','Viser veikryss med kjøremønster – forbereder fører på veivalg.'),(253,'705','Avkjøringstavle','vegvisnings','sf20051007121970501_gif.gif','Informerer om avkjøring fra hovedvei – viser destinasjon og avstand.'),(254,'707','Kjørefeltorienteringstavle','vegvisnings','sf20051007121970701_gif.gif','Viser hvilke felt som leder til ulike reisemål – hjelper ved feltskifte.'),(255,'709','Portalorienteringstavle','vegvisnings','sf20051007121970901_gif.gif','Oversiktsskilt plassert over veibanen – viser felt og destinasjoner.'),(256,'711','Tabellvegviser','vegvisnings','sf20051007121971101_gif.gif','Standard vegviserskilt med tekst og eventuelt symboler – viser retning og reisemål.'),(257,'713','Vanlig vegviser','vegvisnings','sf20051007121971301_gif.gif','Enklere retningsskilt med ett eller få reisemål.'),(258,'715','Avkjøringsvegviser','vegvisnings','sf20051007121971501_gif.gif','Skilt ved selve avkjøringen – angir reisemål for den aktuelle avkjøringen.'),(259,'717','Kjørefeltvegviser','vegvisnings','sf20051007121971701_gif.gif','Viser hvilke felt som leder til spesifikke reisemål – plassert langs veien.'),(260,'719','Portalvegviser','vegvisnings','sf20051007121971901_gif.gif','Skilt over kjørebanen som viser retning og felt for ulike reisemål.'),(261,'723.11','Vegnummer for europaveg','vegvisnings','sf2005100712197231101_gif.gif','Viser nummer på europaveg – E-veier med grønn bakgrunn og hvit tekst.'),(262,'723.13','Vegnummer for riksveg som ikke er europaveg','vegvisnings','sf2005100712197231301_gif.gif','Viser nummer på nasjonal hovedvei – hvit bakgrunn, sort tekst.'),(263,'723.15','Vegnummer for nummerert fylkesveg','vegvisnings','sf2005100712197231501_gif.gif','Nummerert fylkesvei – skilt med blå bakgrunn og hvit tekst.'),(264,'723.21','Ringveg/ringrute','vegvisnings','sf2005100712197232101_gif.gif','Viser rutenummer for ringvei – brukes i større byområder.'),(265,'723.31','Nasjonal turistveg','vegvisnings','sf2005100712197233101_gif.gif','Spesielt utvalgte veier med naturopplevelser – brun bakgrunn.'),(266,'723.41','Omkjøringsrute for store kjøretøy','vegvisnings','sf2005100712197234101_gif.gif','Anbefalt omkjøringsvei for store kjøretøy som ikke kommer gjennom vanlig rute.'),(267,'723.51','Rute for transport av farlig gods','vegvisnings','sf2005100712197235101_gif.gif','Skilt for anbefalt rute for kjøretøy med farlig last.'),(268,'723.61','Andre omkjøringsruter','vegvisnings','sf2005100712197236101_gif.gif','Midlertidige eller faste ruter brukt ved stengte veier eller veiarbeid.'),(269,'723.62','Andre omkjøringsruter','vegvisnings','sf2005100712197236201_gif.gif','Midlertidige eller faste ruter brukt ved stengte veier eller veiarbeid.'),(270,'723.63','Andre omkjøringsruter','vegvisnings','sf2005100712197236301_gif.gif','Midlertidige eller faste ruter brukt ved stengte veier eller veiarbeid.'),(271,'723.64','Andre omkjøringsruter','vegvisnings','sf2005100712197236401_gif.gif','Midlertidige eller faste omkjøringsruter – gjerne nummererte og fargede symboler.'),(272,'723.65','Andre omkjøringsruter','vegvisnings','sf2005100712197236501_gif.gif','Midlertidige eller faste omkjøringsruter – gjerne nummererte og fargede symboler.'),(273,'723.66','Andre omkjøringsruter','vegvisnings','sf2005100712197236601_gif.gif','Midlertidige eller faste omkjøringsruter – gjerne nummererte og fargede symboler.'),(274,'723.71','Kryssnummer på flerfeltsveg','vegvisnings','sf2005100712197237101_gif.gif','Angir nummer på kryss langs motorvei – hjelper fører med orientering.'),(275,'723.73','Kryssnummer på tofeltsveg','vegvisnings','sf2005100712197237301_gif.gif','Viser nummer på kryss langs tofelts hovedvei.'),(276,'725','Avstandsskilt','vegvisnings','sf20051007121972501_gif.gif','Viser avstand til ulike reisemål langs ruten – vanligvis i kilometer.'),(277,'727','Stedsnavnskilt','vegvisnings','sf20051007121972701_gif.gif','Angir hvilket sted du nå kjører inn i.'),(278,'729','Gate-/vegnavnskilt','vegvisnings','sf20051007121972901_gif.gif','Viser navn på gaten eller veien – orienteringshjelp i tettbygde strøk.'),(279,'731','Samleskilt for vegvisning','vegvisnings','sf20051007121973101_gif.gif','Flere vegvisere samlet på én tavle – gir oversikt over retninger.'),(280,'741','Omkjøring for bestemte kjøretøygrupper','vegvisnings','sf20051007121974101_gif.gif','Viser omkjøring spesielt for f.eks. tunge kjøretøy, farlig gods osv.'),(281,'743','Midlertidig omkjøring','vegvisnings','sf20051007121974301_gif.gif','Midlertidig rute grunnet f.eks. veiarbeid eller hendelser.'),(282,'745','Slutt på midlertidig omkjøring','vegvisnings','sf20051007121974501_gif.gif','Informerer om at midlertidig rute nå avsluttes.'),(283,'749','Vegviser for gangtrafikk','vegvisnings','sf20051007121974901_gif.gif','Skilt som viser retning for gående trafikanter.'),(284,'751','Vegviser for sykkelrute','vegvisnings','sf20051007121975101_gif.gif','Viser retning og nummer for sykkelrute – nasjonale eller lokale.'),(285,'753','Tabellvegviser for sykkelrute','vegvisnings','sf20051007121975301_gif.gif','Oversikt over flere sykkelruter med destinasjoner og avstand.'),(286,'755','Sykkelruteskilt','vegvisnings','sf20051007121975501_gif.gif','Symbolskilt som viser hvilken sykkelrute du befinner deg på.'),(287,'757','Avstandsskilt for sykkelrute','vegvisnings','sf20051007121975701_gif.gif','Viser avstand til mål for sykkelruten.'),(288,'761','Motorveg','vegvisnings','sf20051007121976101_gif.gif','Vei reservert for motorvogn med høy standard – avkjørsler kun i planfrie kryss.'),(289,'763','Motortrafikkveg','vegvisnings','sf20051007121976301_gif.gif','Hovedvei for motorisert trafikk med visse restriksjoner for gående og syklende.'),(290,'765','Bomveg/brukerbetaling på veg','vegvisnings','sf20051007121976501_gif.gif','Informerer om at veien er avgiftsbelagt.'),(291,'767','Parkering','vegvisnings','sf20051007121976701_gif.gif','Skilt som viser hvor det finnes parkeringsplass.'),(292,'769','Parkeringshus','vegvisnings','sf20051007121976901_gif.gif','Viser vei til innendørs parkeringsanlegg.'),(293,'771','Lufthavn/flyplass','vegvisnings','sf20051007121977101_gif.gif','Viser vei til flyplass.'),(294,'772','Helikopterplass','vegvisnings','sf20051007121977201_gif.gif','Skilt for helikopterlandingsplass.'),(295,'773','Busstasjon/bussterminal','vegvisnings','sf20051007121977301_gif.gif','Viser plassering av bussterminal eller stasjon.'),(296,'774','Jernbanestasjon/togterminal','vegvisnings','sf20051007121977401_gif.gif','Sted der tog ankommer og går – skiltet viser retning til nærmeste jernbanestasjon.'),(297,'775','Bilferje','vegvisnings','sf20051007121977501_gif.gif','Viser vei til ferjeleie for kjøretøy – skiltet benyttes der bilferje er del av transportnettet.'),(298,'776','Godshavn','vegvisnings','sf20051007121977601_gif.gif','Angir plassering av havn for gods – brukes til å lede tungtrafikk eller frakttransport.'),(299,'780','Kjetting','vegvisnings','sf20051007121978001_gif.gif','Skiltet angir plass for pålegging eller kontroll av kjettinger ved vinterføre.'),(300,'790.10','Kirke','vegvisnings','sf2005100712197901001_gif.gif','Viser vei til kirke – både for religiøse formål og som severdighet.'),(301,'790.15','Næringsområde','vegvisnings','sf2005100712197901501_gif.gif','Angir plassering av industri- eller næringsområde.'),(302,'790.20','Svømmehall','vegvisnings','sf2005100712197902001_gif.gif','Skilt for offentlig svømmeanlegg – viser hvor man finner bademulighet.'),(303,'790.30','Alpinanlegg','vegvisnings','sf2005100712197903001_gif.gif','Brukes for å vise vei til anlegg for alpint eller skisport.'),(304,'790.31','Hoppbakke','vegvisnings','sf2005100712197903101_gif.gif','Viser plassering av skihoppanlegg.'),(305,'790.32 ','Skistadion','vegvisnings','sf2005100712197903201_gif.gif','Skilt for anlegg med langrennsløyper, skiskytterarena eller lignende.'),(306,'790.40','Golfbane','vegvisnings','sf2005100712197904001_gif.gif','Angir vei til golfbane eller golfanlegg.'),(307,'792.11','Betaling med elektronisk brikke','vegvisnings','sf2005100712197921101_gif.gif','Bompassering der betaling skjer automatisk med elektronisk brikke, f.eks. AutoPASS.'),(308,'792.12','Betaling til betjent','vegvisnings','sf2005100712197921201_gif.gif','Bomstasjon hvor betaling gjøres manuelt til betjent.'),(309,'792.13','Betaling med mynter til automat','vegvisnings','sf2005100712197921301_gif.gif','Bom der man betaler med mynter i automat.'),(310,'792.14','Betaling med kort til automat','vegvisnings','sf2005100712197921401_gif.gif','Bom der man betaler med bankkort/kredittkort i automat.'),(311,'792.15','Betaling med sedler til automat','vegvisnings','sf2005100712197921501_gif.gif','Bomstasjon der man kan betale med kontantsedler i automat.'),(312,'792.16','Ta billett i et lukket betalingssystem','vegvisnings','sf2005100712197921601_gif.gif','Du må ta en billett ved innkjøringen – brukes ved parkeringsanlegg.'),(313,'792.17','Lever billett i et lukket betalingssystem','vegvisnings','sf2005100712197921701_gif.gif','Du må levere billett ved utkjøring for å betale korrekt beløp.'),(314,'792.30','Helautomatisk bomstasjon som passeres uten å stanse','vegvisnings','sf2005100712197923001_gif.gif','Passering skjer automatisk – ingen manuell betaling på stedet.'),(315,'792.31','Betaling med AutoPASS','vegvisnings','sf2005100712197923101_gif.gif','Skiltet viser at bompengene betales automatisk via AutoPASS-avtale.'),(316,'790.16','Kjøpesenter','vegvisnings','vegvisningsskilt_som_viser_en_handlevogn_for_kjøpesenter__grafikk.gif','Viser retning til større kjøpesenter eller handlesenter.');
/*!40000 ALTER TABLE `traffic_signs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_limits`
--

DROP TABLE IF EXISTS `usage_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_limits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `daily_quizzes_taken` int DEFAULT NULL,
  `daily_limit_date` date DEFAULT NULL,
  `weekly_exams_taken` int DEFAULT NULL,
  `weekly_limit_start` date DEFAULT NULL,
  `monthly_videos_watched` int DEFAULT NULL,
  `monthly_limit_start` date DEFAULT NULL,
  `last_daily_reset` datetime DEFAULT NULL,
  `last_weekly_reset` datetime DEFAULT NULL,
  `last_monthly_reset` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usage_user_date` (`user_id`,`daily_limit_date`),
  CONSTRAINT `usage_limits_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_limits`
--

LOCK TABLES `usage_limits` WRITE;
/*!40000 ALTER TABLE `usage_limits` DISABLE KEYS */;
INSERT INTO `usage_limits` VALUES (1,1,0,'2025-06-21',0,'2025-06-16',0,NULL,'2025-06-21 00:12:33',NULL,NULL,'2025-06-20 22:39:58','2025-06-21 00:12:33'),(3,3,0,'2025-06-21',0,'2025-06-16',0,NULL,NULL,NULL,NULL,'2025-06-21 00:13:01','2025-06-21 00:13:01');
/*!40000 ALTER TABLE `usage_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_achievements`
--

DROP TABLE IF EXISTS `user_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_achievements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `achievement_id` int NOT NULL,
  `earned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_achievement` (`user_id`,`achievement_id`),
  KEY `achievement_id` (`achievement_id`),
  CONSTRAINT `user_achievements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_achievements_ibfk_2` FOREIGN KEY (`achievement_id`) REFERENCES `achievements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_achievements`
--

LOCK TABLES `user_achievements` WRITE;
/*!40000 ALTER TABLE `user_achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_daily_challenges`
--

DROP TABLE IF EXISTS `user_daily_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_daily_challenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `challenge_id` int NOT NULL,
  `progress` int DEFAULT NULL,
  `completed` tinyint(1) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `xp_earned` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_daily_challenge_uc` (`user_id`,`challenge_id`),
  KEY `challenge_id` (`challenge_id`),
  CONSTRAINT `user_daily_challenges_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_daily_challenges_ibfk_2` FOREIGN KEY (`challenge_id`) REFERENCES `daily_challenges` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_daily_challenges`
--

LOCK TABLES `user_daily_challenges` WRITE;
/*!40000 ALTER TABLE `user_daily_challenges` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_daily_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_feedback`
--

DROP TABLE IF EXISTS `user_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `feedback_type` varchar(50) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `status` varchar(50) DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_feedback`
--

LOCK TABLES `user_feedback` WRITE;
/*!40000 ALTER TABLE `user_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learning_paths`
--

DROP TABLE IF EXISTS `user_learning_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learning_paths` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `path_id` int NOT NULL,
  `progress_percentage` int DEFAULT '0',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_path` (`user_id`,`path_id`),
  KEY `path_id` (`path_id`),
  CONSTRAINT `user_learning_paths_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_learning_paths_ibfk_2` FOREIGN KEY (`path_id`) REFERENCES `learning_paths` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learning_paths`
--

LOCK TABLES `user_learning_paths` WRITE;
/*!40000 ALTER TABLE `user_learning_paths` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learning_paths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_levels`
--

DROP TABLE IF EXISTS `user_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_levels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `current_level` int DEFAULT NULL,
  `current_xp` int DEFAULT NULL,
  `total_xp` int DEFAULT NULL,
  `next_level_xp` int DEFAULT NULL,
  `last_level_up` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `user_levels_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_levels`
--

LOCK TABLES `user_levels` WRITE;
/*!40000 ALTER TABLE `user_levels` DISABLE KEYS */;
INSERT INTO `user_levels` VALUES (1,1,1,0,0,100,NULL),(2,3,1,0,0,100,NULL);
/*!40000 ALTER TABLE `user_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notification_preferences`
--

DROP TABLE IF EXISTS `user_notification_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_notification_preferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `daily_reminders` tinyint(1) DEFAULT '1',
  `weekly_summary` tinyint(1) DEFAULT '1',
  `achievement_notifications` tinyint(1) DEFAULT '1',
  `streak_lost_reminders` tinyint(1) DEFAULT '1',
  `study_tips` tinyint(1) DEFAULT '1',
  `new_features` tinyint(1) DEFAULT '1',
  `progress_milestones` tinyint(1) DEFAULT '1',
  `quiz_reminder_frequency` varchar(20) DEFAULT 'daily',
  `marketing_emails` tinyint(1) DEFAULT '0',
  `partner_offers` tinyint(1) DEFAULT '0',
  `reminder_time` time DEFAULT '18:00:00',
  `timezone` varchar(50) DEFAULT 'Europe/Oslo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_notification_preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notification_preferences`
--

LOCK TABLES `user_notification_preferences` WRITE;
/*!40000 ALTER TABLE `user_notification_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_notification_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_power_ups`
--

DROP TABLE IF EXISTS `user_power_ups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_power_ups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `power_up_id` int NOT NULL,
  `quantity` int DEFAULT NULL,
  `purchased_at` datetime DEFAULT NULL,
  `used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `power_up_id` (`power_up_id`),
  CONSTRAINT `user_power_ups_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_power_ups_ibfk_2` FOREIGN KEY (`power_up_id`) REFERENCES `power_ups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_power_ups`
--

LOCK TABLES `user_power_ups` WRITE;
/*!40000 ALTER TABLE `user_power_ups` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_power_ups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_progress`
--

DROP TABLE IF EXISTS `user_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `total_quizzes_taken` int DEFAULT '0',
  `total_questions_answered` int DEFAULT '0',
  `correct_answers` int DEFAULT '0',
  `total_game_sessions` int DEFAULT '0',
  `total_game_score` int DEFAULT '0',
  `total_videos_watched` int DEFAULT '0',
  `videos_completed` int DEFAULT '0',
  `current_streak_days` int DEFAULT '0',
  `longest_streak_days` int DEFAULT '0',
  `last_activity_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_progress`
--

LOCK TABLES `user_progress` WRITE;
/*!40000 ALTER TABLE `user_progress` DISABLE KEYS */;
INSERT INTO `user_progress` VALUES (1,1,0,0,0,0,0,0,0,0,0,'2025-06-20'),(3,3,0,0,0,0,0,0,0,0,0,NULL);
/*!40000 ALTER TABLE `user_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_skill_profiles`
--

DROP TABLE IF EXISTS `user_skill_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_skill_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `category` varchar(100) NOT NULL,
  `subcategory` varchar(100) DEFAULT NULL,
  `accuracy_score` float DEFAULT NULL,
  `confidence_score` float DEFAULT NULL,
  `learning_rate` float DEFAULT NULL,
  `difficulty_preference` float DEFAULT NULL,
  `avg_response_time` float DEFAULT NULL,
  `response_time_variance` float DEFAULT NULL,
  `questions_attempted` int DEFAULT NULL,
  `questions_correct` int DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_skill_uc` (`user_id`,`category`,`subcategory`),
  KEY `idx_user_skill_category` (`user_id`,`category`),
  CONSTRAINT `user_skill_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_skill_profiles`
--

LOCK TABLES `user_skill_profiles` WRITE;
/*!40000 ALTER TABLE `user_skill_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_skill_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_subscriptions`
--

DROP TABLE IF EXISTS `user_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `plan_id` int NOT NULL,
  `status` enum('active','cancelled','expired','pending') DEFAULT 'active',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `auto_renew` tinyint(1) DEFAULT '1',
  `next_billing_date` date DEFAULT NULL,
  `stripe_subscription_id` varchar(255) DEFAULT NULL,
  `payment_method_id` varchar(255) DEFAULT NULL,
  `is_trial` tinyint(1) DEFAULT '0',
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `cancelled_reason` text,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `plan_id` (`plan_id`),
  CONSTRAINT `user_subscriptions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_subscriptions_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_subscriptions`
--

LOCK TABLES `user_subscriptions` WRITE;
/*!40000 ALTER TABLE `user_subscriptions` DISABLE KEYS */;
INSERT INTO `user_subscriptions` VALUES (1,1,3,'active','2025-06-05 22:10:04','2025-07-05 22:10:04',NULL,1,'2025-07-05',NULL,NULL,0,NULL,NULL,NULL,'2025-06-20 22:10:04','2025-06-20 22:10:04'),(2,3,2,'active','2025-06-20 23:15:17','2025-07-20 23:15:17',NULL,1,'2025-07-21',NULL,NULL,0,NULL,NULL,NULL,'2025-06-20 23:15:17','2025-06-20 23:15:17');
/*!40000 ALTER TABLE `user_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `profile_picture` varchar(255) DEFAULT NULL,
  `preferred_language` varchar(10) DEFAULT 'no',
  `total_xp` int NOT NULL DEFAULT '0',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `subscription_tier` varchar(20) DEFAULT 'free',
  `current_plan_id` int NOT NULL DEFAULT '1',
  `subscription_status` enum('active','cancelled','expired','trial') DEFAULT 'active',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `current_plan_id` (`current_plan_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`current_plan_id`) REFERENCES `subscription_plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'viktor','viktorandreas@hotmail.com','pbkdf2:sha256:600000$1zg4PLmiqrrB7Mh8$67aac70d24556700e90b222045d1cf59c5be3cf95bca1f4c4ef9a6aa9f383916','Administrator','1997-08-06','2025-06-20 22:34:01','2025-06-20 21:45:36',1,NULL,'no',0,1,'free',3,'active',1),(3,'test','viktor@iberiangreenline.com','pbkdf2:sha256:600000$kGWwIFMBVawJAKp4$f98e2c9ffefd2f10d1b587de9fe276b03c799e6c6400e964a08e68dd49c95637','test',NULL,'2025-06-20 23:03:06','2025-06-20 23:12:52',1,NULL,'no',0,1,'free',2,'active',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_bookmarks`
--

DROP TABLE IF EXISTS `video_bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_bookmarks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `video_id` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_video_bookmark_uc` (`user_id`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `video_bookmarks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `video_bookmarks_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_bookmarks`
--

LOCK TABLES `video_bookmarks` WRITE;
/*!40000 ALTER TABLE `video_bookmarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_bookmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_categories`
--

DROP TABLE IF EXISTS `video_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(100) DEFAULT NULL,
  `order_index` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_categories`
--

LOCK TABLES `video_categories` WRITE;
/*!40000 ALTER TABLE `video_categories` DISABLE KEYS */;
INSERT INTO `video_categories` VALUES (1,'Grunnleggende Trafikkregler','Lær de viktigste trafikkreglene','fa-traffic-light',1),(2,'Trafikkskilt','Forstå alle typer trafikkskilt','fa-sign',2),(3,'Kjøreteknikk','Praktiske kjøretips og teknikker','fa-car',3),(4,'Sikkerhet','Trafikksikkerhet og risikovurdering','fa-shield-alt',4),(5,'Førstehjelp','Grunnleggende førstehjelp ved ulykker','fa-first-aid',5);
/*!40000 ALTER TABLE `video_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_checkpoints`
--

DROP TABLE IF EXISTS `video_checkpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_checkpoints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `video_id` int NOT NULL,
  `timestamp_seconds` int NOT NULL,
  `question_id` int DEFAULT NULL,
  `is_mandatory` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `video_id` (`video_id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `video_checkpoints_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `video_checkpoints_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_checkpoints`
--

LOCK TABLES `video_checkpoints` WRITE;
/*!40000 ALTER TABLE `video_checkpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_checkpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_notes`
--

DROP TABLE IF EXISTS `video_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `video_id` int NOT NULL,
  `timestamp_seconds` int NOT NULL,
  `note_text` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `video_notes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `video_notes_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_notes`
--

LOCK TABLES `video_notes` WRITE;
/*!40000 ALTER TABLE `video_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_playlists`
--

DROP TABLE IF EXISTS `video_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_playlists` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text,
  `thumbnail_url` varchar(500) DEFAULT NULL,
  `is_official` tinyint(1) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `video_playlists_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_playlists`
--

LOCK TABLES `video_playlists` WRITE;
/*!40000 ALTER TABLE `video_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_progress`
--

DROP TABLE IF EXISTS `video_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `video_id` int NOT NULL,
  `last_position_seconds` int DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `checkpoints_passed` int DEFAULT '0',
  `total_checkpoints` int DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_video` (`user_id`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `video_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `video_progress_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_progress`
--

LOCK TABLES `video_progress` WRITE;
/*!40000 ALTER TABLE `video_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_ratings`
--

DROP TABLE IF EXISTS `video_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_ratings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `video_id` int NOT NULL,
  `rating` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_user_video_rating_uc` (`user_id`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `video_ratings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `video_ratings_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`),
  CONSTRAINT `_rating_range_check` CHECK (((`rating` >= 1) and (`rating` <= 5)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_ratings`
--

LOCK TABLES `video_ratings` WRITE;
/*!40000 ALTER TABLE `video_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_subtitles`
--

DROP TABLE IF EXISTS `video_subtitles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_subtitles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `video_id` int NOT NULL,
  `language_code` varchar(10) NOT NULL,
  `subtitle_file` varchar(255) DEFAULT NULL,
  `is_auto_generated` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_video_language_uc` (`video_id`,`language_code`),
  CONSTRAINT `video_subtitles_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_subtitles`
--

LOCK TABLES `video_subtitles` WRITE;
/*!40000 ALTER TABLE `video_subtitles` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_subtitles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `filename` varchar(255) DEFAULT NULL,
  `youtube_url` varchar(255) DEFAULT NULL,
  `duration_seconds` int DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `difficulty_level` int DEFAULT '1',
  `order_index` int DEFAULT NULL,
  `thumbnail_filename` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) DEFAULT '1',
  `view_count` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `videos_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `video_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
INSERT INTO `videos` VALUES (1,'Grunnleggende Trafikkregler','Introduksjon til de viktigste trafikkreglene i Norge',NULL,'https://youtube.com/watch?v=example1',480,'Trafikkregler',1,1,1,'thumb_trafikkregler.jpg','2025-06-20 22:36:14',1,0),(2,'Trafikkskilt - Del 1','Lær de mest vanlige trafikkskiltene',NULL,'https://youtube.com/watch?v=example2',360,'Trafikkskilt',2,1,1,'thumb_skilt1.jpg','2025-06-20 22:36:14',1,0),(3,'Sikker Kjøring i By','Tips for trygg kjøring i tettbebygde områder',NULL,'https://youtube.com/watch?v=example3',600,'Kjøreteknikk',3,2,1,'thumb_by_kjoring.jpg','2025-06-20 22:36:14',1,0),(4,'Førstehjelp ved Trafikkulykker','Grunnleggende førstehjelp du bør kunne',NULL,'https://youtube.com/watch?v=example4',720,'Førstehjelp',5,2,1,'thumb_forstehjelp.jpg','2025-06-20 22:36:14',1,0),(5,'Avanserte Kjøreteknikker','Teknikker for erfarne sjåfører',NULL,'https://youtube.com/watch?v=example5',900,'Kjøreteknikk',3,3,2,'thumb_avansert.jpg','2025-06-20 22:36:14',1,0);
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekly_tournaments`
--

DROP TABLE IF EXISTS `weekly_tournaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weekly_tournaments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text,
  `tournament_type` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `entry_fee_xp` int DEFAULT NULL,
  `prize_pool_xp` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekly_tournaments`
--

LOCK TABLES `weekly_tournaments` WRITE;
/*!40000 ALTER TABLE `weekly_tournaments` DISABLE KEYS */;
/*!40000 ALTER TABLE `weekly_tournaments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xp_transactions`
--

DROP TABLE IF EXISTS `xp_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xp_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `amount` int NOT NULL,
  `transaction_type` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `reference_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `xp_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xp_transactions`
--

LOCK TABLES `xp_transactions` WRITE;
/*!40000 ALTER TABLE `xp_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `xp_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sertifikatet'
--

--
-- Dumping routines for database 'sertifikatet'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-22 14:00:22
